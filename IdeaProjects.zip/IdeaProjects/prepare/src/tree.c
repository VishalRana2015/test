#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main(){
	clock_t start ,end;
	start = clock();
	int n;
	
	scanf("%d",&n);
	int temp;
	for ( int i =0; i < n; i++){
		scanf("%d",&temp);
	}
	end = 0;
	double time_taken = (double)(end-start)/(double)(CLOCKS_PER_SEC);
	printf("time_taken : %lf",time_taken);
	return 0;
}
