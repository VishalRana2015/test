
import java.util.*;

public class Solution2 {
    private static void mergesort( int[][] harvestTime , int left ,int right){
        if( left ==right){
            // no need to sort there is only one element
            return;
        }
        int mid;
        mid = (left+ right)/2;
        mergesort( harvestTime,left,mid);
        mergesort(harvestTime,mid+1,right);
        merge(harvestTime,left,right);
    }

    private  static void merge( int[][] harvestTime, int left,  int right){
        int mid  = (left+right)/2;
        // this merges two sorted array
        // First array from left to mid and second array from (mid+1) to right
        int size = (right-left)+1;
        int[][] aux = new int[2][size];
        int aindex, findex, sindex ;
        aindex =0;
        findex = left;
        sindex = mid+1;
        while( findex <= mid && sindex <= right){
            // while there are more elements left in the array. I don't want to increase constant multiplier.

            if ( harvestTime[0][findex] < harvestTime[0][sindex]){
                aux[0][aindex] = harvestTime[0][findex];
                aux[1][aindex] =  harvestTime[1][findex];
                findex++;
                aindex++;
            }
            else{
                aux[0][aindex] = harvestTime[0][sindex];
                aux[1][aindex] = harvestTime[1][sindex];
                sindex++;
                aindex++;
            }
        }

        while( findex <= mid){
            aux[0][aindex] = harvestTime[0][findex];
            aux[1][aindex] =harvestTime[1][findex];
            findex++;
            aindex++;
        }
        while( sindex <= right){
            aux[0][aindex] = harvestTime[0][sindex];
            aux[1][aindex] = harvestTime[1][sindex];
            aindex++;
            sindex++;
        }
        // copy them to original array
        for ( int i=0; i < aux[0].length; i++){
            harvestTime[0][left+i] = aux[0][i];
            harvestTime[1][left+i] = aux[1][i];
        }// copied
    }
    public static class Time{
        int start_time;
        int end_time;
        public Time(int start_time,int end_time){
            this.start_time= start_time;
            this.end_time = end_time;
        }
    }
    public static void main(String[] args){
        int T;
        int N, K ;
        int[][] harvestTime ;
        Time[] time;
        Scanner sc = new Scanner(System.in);
        T = sc.nextInt();
        for ( int test= 1; test <= T ;test++){
            N = sc.nextInt();
            K = sc.nextInt();
            //harvestTime= new int[2][N];
            time= new Time[N];
            for ( int j = 0; j < N ; j++){
                int start_time = sc.nextInt();
                int end_time  = sc.nextInt();
                time[j] = new Time(start_time,end_time);
                //harvestTime[0][j] = sc.nextInt();
                //harvestTime[1][j] = sc.nextInt();
            }
            // sort the harvest time based on starting time
            Arrays.sort( time, (Time t1 , Time t2 )-> {
                if (t1.start_time <= t2.start_time){
                    return -1;
                }
                else
                    return 1;
            });
            //mergesort(harvestTime, 0, harvestTime[0].length-1);
            /*System.out.println("After sorting : ");
            for ( int j =0; j < N; j++){
                System.out.println(harvestTime[0][j] + " , " + harvestTime[1][j]);
            }*/
            // all the inputs have been readed
            int atime , temptime , count , c , st , et , re; //
            String s = "";

            Stack<Integer> stack =new Stack<Integer>();
            count = 0;
            re =0;
            for ( int j =0 ; j < N ; j++){
                st = time[j].start_time; //harvestTime[0][j];
                et = time[j].end_time ; //harvestTime[1][j];
                st = ( st > re)?st:re;
                temptime = et -st; // harvesting time
                if ( temptime > 0 ){
                    c = (temptime-1)/K +1;
                    count = count +c;
                    re = st + K *c;
                }
            }
            System.out.println("Case #"+test+": "+ count);
        }
    }
}
