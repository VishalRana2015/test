
import java.util.*;
import java.io.*;
public class Solution {
    public static void main(String[] args) {
        int T, N , W;
        FastReader fr = new FastReader(System.in);
        T = fr.nextInt();
        int[] x;
        int radius = 100000000;
        for ( int test = 1; test<= T; test++) {
            W = fr.nextInt();
            N = fr.nextInt();
            x = new int[W];
            for (int i = 0; i < W; i++) {
                x[i] = fr.nextInt()-1;
            }
            double[] angles = new double[W];
            for ( int i =0; i < W ; i++){
                angles[i] = 359.9999999*x[i]/(N);
                //System.out.print(angles[i] + "   ");
            }
            Queue<Integer> q = new LinkedList<>();
            ArrayList<Integer> list = new ArrayList<Integer>();
            list.add(2);

            System.out.println(list.get(3));
            System.out.println("After printing");
            HashMap<Integer,Integer> map = new HashMap<>();
            ArrayList<ArrayList<Integer>> nodes= new ArrayList<>();
            nodes.add(new ArrayList<Integer>());
            
           // System.out.println();
            Integer[] arr = new Integer[10];
            int[] aa = new int[10];
            Arrays.sort( arr, (Integer a, Integer b) ->{
                if ( a < b){
                    return -1;
                }
                if ( a==b)
                    return 0;
                return 1;
            });
            double sin, cos;
            sin = cos = 0;
            for ( int i =0; i < W; i++){
                double xx =  radius*Math.cos( (Math.PI*angles[i])/180.0);
                double yy =  radius*Math.sin( (Math.PI*angles[i])/180.0);
                //System.out.println("x,y : "+ xx + "  ,  " + yy);
                cos = cos + xx;
                sin = sin + yy;
            }
            sin = sin/W;
            cos = cos/W;
            //System.out.println("sin,cos : "+ sin+ "  ,  "+ cos);
            double angle = 180*Math.atan2(sin,cos)/Math.PI;
            //System.out.println("angle : "+ angle);
            if( angle < 0){
                angle = 360+angle;
            }
            int avg = (int)Math.round(((double)(N)*angle/359.999999999));
            // may be hello brother from the depth of my heart.
            long count = 0;
            for ( int i =0; i < W ; i++){
                if ( avg > x[i]){
                    count =count + Math.min(avg-x[i],N-avg+x[i]);
                }
                else{
                    count = count + Math.min(x[i]-avg,N-x[i]+avg);
                }
            }
            System.out.println("Case #"+ test+ ": "+ count);
            //System.out.println("avg : "+ avg);
        }
    }
    int min( int a, int b){
        if ( a < b){
            return a;
        }
        return b;
    }

    static class FastReader {
        private InputStream stream;
        private byte[] buf = new byte[8192];
        private int curChar;
        private int pnumChars;
        private FastReader.SpaceCharFilter filter;

        public FastReader(InputStream stream) {
            this.stream = stream;
        }

        private int pread() {
            if (pnumChars == -1) {
                throw new InputMismatchException();
            }
            if (curChar >= pnumChars) {
                curChar = 0;
                try {
                    pnumChars = stream.read(buf);
                }
                catch (IOException e) {
                    throw new InputMismatchException();
                }
                if (pnumChars <= 0) {
                    return -1;
                }
            }
            return buf[curChar++];
        }

        public int nextInt() {
            int c = pread();
            while (isSpaceChar(c))
                c = pread();
            int sgn = 1;
            if (c == '-') {
                sgn = -1;
                c = pread();
            }
            int res = 0;
            do {
                if (c == ',') {
                    c = pread();
                }
                if (c < '0' || c > '9') {
                    throw new InputMismatchException();
                }
                res *= 10;
                res += c - '0';
                c = pread();
            } while (!isSpaceChar(c));
            return res * sgn;
        }

        private boolean isSpaceChar(int c) {
            if (filter != null) {
                return filter.isSpaceChar(c);
            }
            return isWhitespace(c);
        }

        private static boolean isWhitespace(int c) {
            return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
        }

        private interface SpaceCharFilter {
            public boolean isSpaceChar(int ch);

        }

    }

}

