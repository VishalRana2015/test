import com.sun.javafx.binding.StringFormatter;

import java.awt.image.FilteredImageSource;
import java.util.*;
import java.io.*;
class tree {
    private static class Node{
        Node(int val){
            this.val = val;
        }
        int val;
    }
    public static void main(String[] args) {
        PriorityQueue<Integer> queue= new PriorityQueue<>();
        queue.add(2);
        queue.add(4);
        queue.add(3);
        queue.add(10);
        Node[] node = new Node[10];
        for (int i =9 ; i >= 0;i --)
            node[i] = new Node(i);

        Arrays.sort(node,(Node n1, Node n2 ) -> {
            if ( n1.val < n2.val)
                return -1;
            if ( n1.val == n2.val){
                return 0;
            }
            return 1;
        });
        for ( int i =0; i < node.length; i++){
            System.out.println(node[i].val);
        }


    }

    static class FastReader {
        private InputStream stream;
        private byte[] buf = new byte[8192];
        private int curChar;
        private int pnumChars;
        private FastReader.SpaceCharFilter filter;

        public FastReader(InputStream stream) {
            this.stream = stream;
        }

        private int pread() {
            if (pnumChars == -1) {
                throw new InputMismatchException();
            }
            if (curChar >= pnumChars) {
                curChar = 0;
                try {
                    pnumChars = stream.read(buf);
                }
                catch (IOException e) {
                    throw new InputMismatchException();
                }
                if (pnumChars <= 0) {
                    return -1;
                }
            }
            return buf[curChar++];
        }

        public int nextInt() {
            int c = pread();
            while (isSpaceChar(c))
                c = pread();
            int sgn = 1;
            if (c == '-') {
                sgn = -1;
                c = pread();
            }
            int res = 0;
            do {
                if (c == ',') {
                    c = pread();
                }
                if (c < '0' || c > '9') {
                    throw new InputMismatchException();
                }
                res *= 10;
                res += c - '0';
                c = pread();
            } while (!isSpaceChar(c));
            return res * sgn;
        }

        private boolean isSpaceChar(int c) {
            if (filter != null) {
                return filter.isSpaceChar(c);
            }
            return isWhitespace(c);
        }

        private static boolean isWhitespace(int c) {
            return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
        }

        private interface SpaceCharFilter {
            public boolean isSpaceChar(int ch);

        }

    }
}

