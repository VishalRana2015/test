import java.sql.*;
import java.math.*;
import oracle.jdbc.driver.*;
public class DatabaseConnectionExample {
    public static void main(String[] args) {
        try {
            Class c =Class.forName("oracle.jdbc.driver.OracleDriver");
            System.out.println("Class Loaded successfully");
            // XE is the oracle database name ( instance name  as there is only one database's instance in oracle database so we use term database and instance interchangebly)
            // XE can also be called as ORACLE SID ( unique identifier for the oracle database instance
            // Service_name ( alias given to oracle database by the TNSNAMES.ORA file
            // jdbc:oracle:thin:@//<host>:<port>/<service_name or Oracle_SID>

            Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/XE","system","manager");
            if ( conn == null){
                System.out.println("conn is null");
            }
            else {
                System.out.println("Conn is not null");
                System.out.println("conn.isClosed()= " + conn.isClosed());
            }
             Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
            ResultSet set= st.executeQuery("select * from emp");
            set.absolute(1);
            System.out.println("EMPID        NAME        GENDER");
            while ( set.next()){
                System.out.println(set.getInt(1) + "   "+ set.getString(2) + "     " + set.getString(3));

            }


        }
        catch(Exception e){
            System.out.println("Exception thrown : "+e.getMessage());
        }
    }
}
