import com.sun.deploy.security.SelectableSecurityManager;

import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;

public class Graph {
    int v;
    Vector[] adj ;
    Graph ( int v){
        this.v = v;
        adj = new Vector[v];
        for ( int i =0; i < v; i++){
            adj[i] = new Vector();
        }
    }
    void addEdge( int a, int b){
        adj[a].add(b);
        // directed graph
    }
    int countPath( int s, int e){
        int count =0;
        ListIterator itr= adj[s].listIterator();
        while( itr.hasNext()){
            int n =  (int)itr.next();
            if ( n == e)
                count = count +1;
            else
                count = count + countPath(n,e);
        }
        return count;
    }
    public int  countUsingStack( int s, int e){
        int count =0;

        StackNode node = new StackNode( s,e);
        Stack stack = new Stack();
        stack.push(node);
        int ne;
        while( !stack.empty()) {
             node = (StackNode)stack.peek();
             if (  ( ne = (int)node.nextElement()) != -1){
                 if ( ne == e)
                     count = count +1;
                 else
                     stack.push( new StackNode(ne,e));
             }
             else
                 stack.pop();
        }
        return count;
    }
    class StackNode{
        int a, b;
        int length;
        int ne;
        StackNode( int a, int b){
            this.a =a;
            this.b = b;
            length = adj[a].size();
            ne = 0;
        }

        public Object nextElement(){
            if ( ne < length){
                ne = ne +1;
                return adj[a].elementAt(ne-1);
            }
            return -1;
        }
    }
    public static void main(String[] args) {
            Tree t= new Tree(7);
            t.addEdge(0,1);
            t.addEdge(0,2);
            t.addEdge(1,3);
            t.addEdge(1,4);
            t.addEdge(1,5);
            t.addEdge(2,6);
            System.out.println("Node at level 2 : " + t.nodeAtLevel(1));

    }


}

class Graph2{
    Vector [] adj;
    int v;
    static class Node{
        int x,y, level;
        Node( int x, int y, int level){
            this.x = x;
            this.y = y;
            this.level =level;
        }
        public boolean answerNode(){
            if ( x== y ){
                return true;
            }
            return false;
        }
    }

    public Graph2(int v){
        this.v = v;
        adj = new Vector[v];
        for ( int i =0; i < v; i++)
            adj[i] = new Vector();
    }

    public static  int countMinimumOperation(int x,int y){
        // This function returs the minimum no of operatios needed to convert x to y. The two valid operations are (x,y)-> (2x,y) and (x,y)->(x-1,y)

        int count =0;
        int level = 0;
        Node newNode, node;
        newNode = new Node(x,y,level);
        return 0;

    }
}

class Tree{
    Vector[] adj;
    int v;
    int[] color;
    Set A, B;
    int edges;
    Tree(int v){
        edges = 0;
        adj = new Vector[v];
        color  = new int[v];
        for (int i =0; i < v; i++){
            adj[i]  = new Vector();
            color[i] = 0;
        }
        A = new TreeSet();
        B = new TreeSet();
        this.v = v;
    }
    class Node{
        int v , l;// vertex v at level l
        Node( int v, int l){
            this.v = v;
            this.l =l;
        }

    }
    public int nodeAtLevel ( int x){
        int count =0;
        if ( x== 0)
            return 1;
        Queue q = new LinkedList();
        q.add(new Node(0,0));
        Node newNode , node;
        ListIterator itr;
        int vertex;
        while( !q.isEmpty()){
            node = (Node)q.remove();
            vertex = node.v;
            itr = adj[vertex].listIterator();
            while (itr.hasNext()){
                newNode = new Node((int)itr.next(),node.l + 1);
                if ( node.l + 1 == x){
                    count = count + 1;
                }
                else
                    q.add(newNode);
            }
        }
        return count;
    }
    public void addEdge( int u, int v){
        adj[u].add(v);
        //adj[v-1].add(u-1);
        edges = edges + 1;
    }
    public int countMaxEdgeThatCanBeAdded( ){
        colorTheTree();
        int r = (A.size() * B.size()) - edges;
        System.out.println( " r = : "+ r);
        return r;
    }
    public void colorTheTree(){
        if ( color (0, 2)) {
            for ( int i=0; i < v; i++){
                System.out.println("x["+i+"] = "+ color[i]);
                if ( color[i] == 1)
                    A.add(i+1);
                else
                    B.add(i+1);
            }

            System.out.println("Colored Successfully");
        }
    }
    private boolean color( int k , int m){
        while ( true){
            color[k] = nextColor(k, m);
            if ( color[k] == 0){
                return false;
            }
            if ( k == v-1)
                return true;
            else
                return color( k+1, m);
        }
    }

    private int nextColor( int k , int m){
        int c,i;
        boolean finded;
        int ele;
        while (true) {
            finded = true;
            color[k] = (color[k] + 1) % (m + 1);
            System.out.println(" c= "+color[k]
            );
            if (color[k] == 0) {
                return color[k];
            }
            ListIterator itr = adj[k].listIterator();
            while( itr.hasNext()){
                ele = (int) itr.next();
                System.out.println( " k  = " + k+ " ele = "+ ele);
                if ( color[ele] == color[k]){
                    finded = false;
                    break;
                }
            }
            if (finded)
                return color[k];
        }
    }
}