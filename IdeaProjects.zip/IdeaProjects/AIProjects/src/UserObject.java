import javax.crypto.SecretKey;
import java.security.KeyPair;

public class UserObject {
    //what are you doing from the specidfic fpooint fo view
    private static final long serialVersionUID = 4L;
    private String userID, userName;
    private SecretKey dbkey;
    private KeyPair commkey;

    // constructor
    public UserObject(String userID , String userName, SecretKey dbkey, KeyPair commkey){
        this.userID = userID;
        this.userName = userName;
        this.dbkey = dbkey;
        this.commkey = commkey;
    }

    public String getUserID() {
        return userID;
    }

    public String getUserName() {
        return userName;
    }

    public KeyPair getCommkey() {
        return commkey;
    }

    public SecretKey getDbkey() {
        return dbkey;
    }

}
