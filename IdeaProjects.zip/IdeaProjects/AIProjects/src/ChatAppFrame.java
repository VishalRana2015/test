import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;

public class ChatAppFrame extends JFrame {
    private static int count =0;
    
    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        count = count -1;
        System.out.println("Object destroyed");
    }
}
