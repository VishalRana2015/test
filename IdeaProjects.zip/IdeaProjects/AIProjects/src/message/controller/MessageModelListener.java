package message.controller;
// This interface provides the basic method for listening for the events
public interface MessageModelListener {
    public void updateMessage(MessageEvent e);
}

