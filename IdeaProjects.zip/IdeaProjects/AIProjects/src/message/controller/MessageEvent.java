package message.controller;

public class MessageEvent {
    Object source;
    public MessageEvent(Object source){
        this.source = source;
    }
}
