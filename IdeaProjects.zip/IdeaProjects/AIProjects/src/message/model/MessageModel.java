package message.model;
import javax.swing.text.DefaultCaret;
import java.awt.*;
import java.security.InvalidAlgorithmParameterException;
import java.time.LocalDateTime;
import java.util.*;
import java.io.*;

import com.sun.javaws.exceptions.InvalidArgumentException;
import message.controller.*;
public class MessageModel {
    static public int TEXTMESSAGE = 1;
    static public int FILEMESSAGE = 2;
    // static fields for labels
    public static int NOTVALID = -1;
    public static int PROGRESS = 7;
    public static int NOTSENT = 1;
    public static int SENT = 2;
    public static int DELIVERED = 3;
    public static int NOTSEEN = 4;
    public static int UNSEEN = 5;

    static int N;
    // object variables
    String senderID, receiverID; // receiver id , sender id
    int messageID; // message Id
    int messageType; // Type of message file message , text message
    String messageText; // contains text message
    String fileloc; // Location of the file on the local computer (or the name of the file on the server if it is not downloaded).
    int sentStatus; // The sent status will tell whether is message is sent or not , or has been delivered to receiver. This status will only will be valid if the message has been sent from this user.
    Date sentTime; // The sent time will tell when the message was set ( either by user or sender whoever it is)
    int receivedStatus;  // This will time received status of the message either seen or not seen. This field is only valid if the message is received from someone else.
    Date receivedTime; // The time when the message was received by the receiver. If the message is delivered to me then this tells the time that when I have received the message otherwise  when the message is received by the receiver to whom it was sent.
    boolean isDownloaded; // This will tell whether the file is downloaded or not.
    boolean isSent;// A boolean field just to help layout manager to make sure if the message is sent or received.
    Vector<MessageModelListener> listeners;

    static {
        // initializing N at the loading of the class
        N = 1024;
    }
    private MessageModel(){
    }
    private MessageModel ( String senderID, String receiverID , int messageID , int messageType , String messageText, String fileloc , int sentStatus, Date sentTime, int receivedStatus, Date receivedTime, boolean downloaded, boolean sent){
        this.senderID = senderID;
        this.receiverID = receiverID;
        this.messageID = messageID;
        this.messageType = messageType;
        this.messageText= messageText;
        this.fileloc = fileloc;
        this.sentStatus = sentStatus;
        this.sentTime = sentTime;
        this.receivedStatus  = receivedStatus;
        this.receivedTime = receivedTime;
        this.isDownloaded = downloaded;
        this.isSent = sent;

    }
    // message will be created by static member function of the class
    // These message are created for newly created messages.
    public static MessageModel createFileMessageForSender( String senderID , String receiverID , int messageID ,String fileloc, Date sentTime) throws IllegalArgumentException{
        if ( senderID == null || receiverID == null || fileloc == null || sentTime == null)
            throw new IllegalArgumentException("one of the argument is null");
        MessageModel model = new MessageModel(senderID , receiverID, messageID, MessageModel.FILEMESSAGE ,null, fileloc, MessageModel.NOTSENT , sentTime,  MessageModel.NOTVALID, null, false, true);
        return model;
    }
    public static MessageModel createFileMessageForReceiver(String senderID , String receiverID , int messageID , String fileloc, Date sentTime  , Date receivedTime  , boolean downloaded) throws IllegalArgumentException{
        if ( senderID == null || receiverID == null || fileloc == null || receivedTime == null || sentTime == null)
            throw new IllegalArgumentException("one of the argument is null");
        MessageModel model = new MessageModel ( senderID , receiverID , messageID , MessageModel.FILEMESSAGE,null, fileloc, MessageModel.NOTVALID ,sentTime,MessageModel.NOTSEEN, receivedTime, downloaded, false);
        return model;
    }
    public static MessageModel createTextMessageForSender(String senderID , String receiverID, int messageID , String message, Date sentTime ) throws  IllegalArgumentException{
        if ( senderID == null || receiverID == null || message == null || sentTime == null)
            throw new IllegalArgumentException("one of the argument is null");
        MessageModel model = new MessageModel( senderID, receiverID , messageID , MessageModel.TEXTMESSAGE, message,null, MessageModel.NOTSENT,sentTime,MessageModel.NOTVALID,null,false, true);
        return model;
    }
    public static MessageModel createTextMessageForReceiver(String senderID , String receiverID , int messageID , String message, Date sentTime , Date receivedTime ) throws  IllegalArgumentException{
        if ( senderID == null || receiverID == null || message == null || sentTime == null)
            throw new IllegalArgumentException("one of the argument is null");
        MessageModel model = new MessageModel(senderID , receiverID,messageID,MessageModel.TEXTMESSAGE, message, null, MessageModel.NOTSENT,sentTime,MessageModel.NOTSEEN,receivedTime,false,false);
        return model;
    }
    // The following message is created for reading messages from the database
    public static MessageModel createMessageModel( String senderID , String receiverID, int messageID,int messageType, String messageText, String fileloc, int sentStatus, Date sentTime, int receivedStatus, Date receivedTime, boolean isDownloaded, boolean sent) throws IllegalArgumentException{
        if ( senderID == null || receiverID == null )
            throw new IllegalArgumentException("senderID and receiverID must not be empty");
        if ( messageType == MessageModel.FILEMESSAGE && fileloc == null)
            throw new IllegalArgumentException("fileloc is null");
        if ( messageType == MessageModel.TEXTMESSAGE && messageText == null)
            throw new IllegalArgumentException("message is null");
        if ( sent && sentStatus == NOTVALID )
            throw new IllegalArgumentException("sentStatus is invalid");
        if ( sentTime == null)
            throw new IllegalArgumentException("sentTime is null");
        if( !sent && receivedTime == null)
            throw new IllegalArgumentException("receivedTime is null");
        MessageModel model = new MessageModel ( senderID , receiverID, messageID, messageType, messageText, fileloc, sentStatus, sentTime,receivedStatus, receivedTime,isDownloaded, sent);
        return model;
    }
    public String getSenderID() {
        return senderID;
    }
    public String getReceiverID() {
        return receiverID;
    }
    public int getMessageID() {
        return messageID;
    }
    public int getMessageType() {
        return messageType;
    }
    public String getMessageText() {
        return messageText;
    }
    public String getFileloc() {
        return fileloc;
    }
    public int getSentStatus() {
        return sentStatus;
    }
    public int getReceivedStatus() {
        return receivedStatus;
    }
    public Date getSentTime() {
        return sentTime;
    }
    public Date getReceivedTime() {
        return receivedTime;
    }
    public boolean isDownloaded() {
        return isDownloaded;
    }
    public boolean isSent() {
        return isSent;
    }
    // All the get methods represents what are the fields that are immutable
    public void setSentStatus(int sentStatus) {
        this.sentStatus = sentStatus;
        MessageEvent e = new MessageEvent(this);
        invokeListeners(e);
    }

    public void setReceivedStatus(int receivedStatus) {
        this.receivedStatus = receivedStatus;
        MessageEvent e = new MessageEvent(this);
        invokeListeners(e);
    }

    public void setReceivedTime(Date receivedTime) {
        this.receivedTime = receivedTime;
        MessageEvent e = new MessageEvent(this);
        invokeListeners(e);
    }

    public void setDownloaded(boolean downloaded) {
        isDownloaded = downloaded;
        MessageEvent e = new MessageEvent(this);
        invokeListeners(e);
    }

    public String SentTimeStringStatus(){
        long millis =sentTime.getTime();
        Calendar c = Calendar.getInstance();
        Date curr  = c.getTime();
        int ch, cm , sh ,sm , dh, dm , tsm ;
        long diff;
        ch = curr.getHours();
        cm =curr.getMinutes();
        dh = sentTime.getHours();
        dm = sentTime.getMinutes();
        diff = curr.getTime() - sentTime.getTime();
        System.out.println(curr);
        System.out.println(sentTime);
        if ( diff < 0 )
            return "Future";
        tsm = (int)(diff/60000);
        sm  = tsm % 60;
        sh = (int)(tsm/60);
        System.out.println(tsm +","+ sm + "," + sh);
        String s;
        if(  ( sh < ch)  | ( ( sh == ch) & (sm <= cm)) )
            return "Today";
        if ( (sh < (ch + 24)  )| (sh == (ch + 24)  & ( sm <= cm)))
            return "Yesterday";
        s = dh + ":"+ dm ;
        return s;
    }
    public  String ReceivedTimeStringStatus(){
        if ( receivedTime == null)
            return "";
        long millis = receivedTime.getTime();
        Calendar c = Calendar.getInstance();
        Date curr  = c.getTime();
        int ch, cm , sh ,sm , dh, dm , tsm ;
        long diff;
        ch = curr.getHours();
        cm =curr.getMinutes();
        dh = receivedTime.getHours();
        dm = receivedTime.getMinutes();
        diff = curr.getTime() - receivedTime.getTime();
        System.out.println(curr);
        System.out.println(receivedTime);
        if ( diff < 0 )
            return "Future";
        tsm = (int)(diff/60000);
        sm  = tsm % 60;
        sh = (int)(tsm/60);
        System.out.println(tsm +","+ sm + "," + sh);
        String s;
        if(  ( sh < ch)  | ( ( sh == ch) & (sm <= cm)) )
            return "Today";
        if ( (sh < (ch + 24)  )| (sh == (ch + 24)  & ( sm <= cm)))
            return "Yesterday";
        s = dh + ":"+ dm ;
        return s;
    }


    // This class is a source for events if in case of message updated.
    public void addMessageModelListener( MessageModelListener listener){
        if ( ! (listeners.contains(listener))) {
            listeners.add(listener);
            System.out.println("Object added to listeners");
        }
        else
            System.out.println("Object already exists int eh listeners");
    }
    public void removeMessageModelListener( MessageModelListener listener){
        if ( listeners.contains(listener)) {
            listeners.remove(listener);
            System.out.println("Object removed from listeners.");
        }
        else
            System.out.println("Object was not in the listener list");
    }
    private void invokeListeners( MessageEvent e){
        // This method is responsible for invoking all the listeners associated with it.
        // This invocation should done in separate thread i.e not in the main thread but in the separate thread ( in event-dispatching thread).
        // what should we do now
        MessageModelListener listener;
        Iterator itr = listeners.listIterator();
        while ( itr.hasNext()){
            listener = (MessageModelListener)itr.next();
            listener.updateMessage(e);
        }
    }
}

