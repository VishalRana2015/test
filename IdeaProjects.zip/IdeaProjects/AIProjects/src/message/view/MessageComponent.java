package message.view;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.*;
import message.controller.*;
import message.model.*;
public class MessageComponent extends JTextArea{
    MessageModel model;
    ModelListener listener ;
    char separator;
    int w, h; // stands for width and height respectively
    static Font borderFont; // this is related to label for the time on the border width
    public MessageComponent(MessageModel model){
        this.setEditable(false);
        this.setOpaque(false);
        this.setLineWrap(true);
        this.setWrapStyleWord(true);
        this.setPreferredWidth(100);//default value
        this.separator = ' ';
        listener = new ModelListener();
        model.addMessageModelListener(listener);
    }
    static {
        // This block is responsible to initiazing the common charactertics to this component
        borderFont = new Font(Font.SANS_SERIF,Font.ITALIC,6);
    }
    // What the hell are you talking about
    public int getPreferredWidth() {
        return w;
    }

    public int getPreferredLines(String text, int width){
        // This method is responsible for returning no of lines that this JTextArea instance must have to completely display it's contents.
        if ( width < 100)
            return 0;
        int aw, ww, sw , line ;
        sw = this.getFontMetrics(this.getFont()).stringWidth(this.separator + "");
        aw = width;

        line = 1;
        String[] s= text.split(this.separator + "",0);
        for ( int i =0; i < s.length ; i++){
            if ( s[i].length() == 0){
                ww =sw;
            }
            else
                ww = this.getFontMetrics(this.getFont()).stringWidth(s[i]);
            if ( ww > width){
                // If the word width is greater than the width that can be displayed at a single line
                if ( aw < width){
                    line = line + 1;
                }
                while ( ww > 0){
                    if ( ww -width > 0){
                        ww = ww - width;
                        System.out.println("Changing line for :"+ s[i]);
                        line = line + 1;
                    }
                    else{
                        ww = 0;
                        aw = width -ww;
                    }
                }
            }
            else{
                if ( ww <= aw){
                    aw = aw - ww;
                }
                else {
                    System.out.println("Changing line :"+ s[i]);
                    line =line + 1;
                    aw = width - ww;
                }
            }
            // adding space for separator
            if ( sw <= aw){
                aw = aw - sw;
            }
            else{
                line  = line + 1;
                System.out.println("Changing line for separator:");
                aw = width - sw;
            }
        }

        return line;
    }

    public void setPreferredWidth(int w) {
        // Using this method the user can set it fixed width
        this.w = w;
        if ( this.w < 100)
            this.w = 100; // Minimum Width that user can set is 100;
        h = getPreferredLines(this.getText() , w) * this.getRowHeight();
        this.setSize(new Dimension(w,h));
    }

    @Override
    protected void paintComponent(Graphics g) {

        int x, y , w, h;
        x = (int)g.getClipBounds().getX();
        y = (int)g.getClipBounds().getY();
        w = (int)g.getClipBounds().getWidth();
        h = (int)g.getClipBounds().getHeight();
        Graphics2D gg = (Graphics2D)g.create();
        gg.setColor(new Color(255,255,0));
        gg.fillRoundRect(x,y,w,h,10,10);
        gg.dispose();
        super.paintComponent(g);
    }

    @Override
    public Dimension getMaximumSize() {
        int width , height;
        width = this.w + ( this.getInsets().left + this.getInsets().right);
        height = this.h + (this.getInsets().top + this.getInsets().bottom);
        return new Dimension(width,height);
    }

    @Override
    public Dimension getMinimumSize() {
        int width , height;
        width = this.w + ( this.getInsets().left + this.getInsets().right);
        height = this.h + (this.getInsets().top + this.getInsets().bottom);
        return new Dimension(width,height);
    }

    @Override
    public Dimension getPreferredSize() {
        int width , height;
        width = this.w + ( this.getInsets().left + this.getInsets().right);
        height = this.h + (this.getInsets().top + this.getInsets().bottom);
        return new Dimension(width,height);
    }

    class ModelListener implements MessageModelListener{
        @Override
        public void updateMessage(MessageEvent e) {
            System.out.println("update message invoked .");
            revalidate(); // revalidating the component
        }
    }
    static class MessageBorder extends EmptyBorder {
        public static String LEFT = "LEFT";
        public static String RIGHT = "RIGHT";
        public static String BOTTOM = "BOTTOM";
        public static String TOP = "TOP";
        String paintAt ;
        boolean isFromUser;
        public MessageBorder(String paintAt, boolean isFromUser, int top ,int left, int bottom , int right){
            super(top,left,bottom,right); // creating an empty border
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            super.paintBorder(c, g, x, y, width, height);
            // This method is responsible for painting the border around the component
        }
    }
}
