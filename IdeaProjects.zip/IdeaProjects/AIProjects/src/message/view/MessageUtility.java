package message.view;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.*;
import message.model.*;
public class MessageUtility {
    public static class  MessageBorder  extends EmptyBorder {
        public static String LEFT  = "LEFT";
        public static String RIGHT = "RIGhT";
        public static String TOP  = "TOP";
        public static String BOTTOM = "BOTTOM";

        public MessageBorder(int top , int left , int bottom , int right){
            super(top,left, bottom , right);

        }
        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            super.paintBorder(c, g, x, y, width, height);
            // This method is responsible for painting the border around the MessageComponent ( just like as in whatsapp) only if c is
            // instance of MessageComponent
            if ( !(c instanceof  MessageComponent))
                return;
            MessageComponent comp = (MessageComponent)c;
            int lines ;
            // drew the things just drew them
            Insets inset = this.getBorderInsets();
            System.out.println("Insets :"+ inset);
        }
    }
    public abstract static class MessageComp extends JComponent{
        MessageModel model;
        private static Font font ;
        static {
            font = new Font(Font.SERIF,Font.PLAIN,12);
        }
        MessageComp(MessageModel model){
            this.model =model ;
        }

    }



}
