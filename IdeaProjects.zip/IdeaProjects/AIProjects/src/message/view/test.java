package message.view;


import java.time.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.util.*;
import java.io.*;
import message.model.*;
public class test {
    public static void main(String[] args) throws IOException {
        compTest();
    }
    public static void compTest() throws IOException{
        JFrame frame = new JFrame("MessageComponent test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel = new JPanel();
        File file = new File("C:\\Users\\Rana1947\\Desktop\\audio.mp3");
        //FileMessage comp = new FileMessage(file);
        File file2 = new File("C:\\Uses\\Rana1947\\Desktop\\3");
        //panel.add(comp);
        Calendar c  = Calendar.getInstance();
        Date date = c.getTime();
        MessageModel model = MessageModel.createFileMessageForSender( "ranavishal2015@gmail.com","ranaabhishek1947@gmail.com",1,file2.getAbsolutePath(),date);
        FileMessage comp2 = new FileMessage(model);
        JPanel panel2 = new JPanel();
        comp2.setBorder( BorderFactory.createLineBorder(Color.BLACK));
        panel2.add(comp2);
        TickComponent comp= new TickComponent(TickComponent.PROGRESS);
        comp.setPreferredSize(new Dimension(150,100));
        comp.setSize( 150, 100);
        comp.setBorder( BorderFactory.createLineBorder(Color.GREEN));
        ImageMessage im = new ImageMessage(new File("C:\\Users\\Rana1947\\Desktop\\family.jpg"));
        im.setW(300);
        im.setH(200);
        ImageMessageComp im2= new ImageMessageComp(new ImageIcon("C:\\Users\\Rana1947\\Desktop\\family.jpg"),300,200);
        MessageModel model3 = MessageModel.createFileMessageForSender("ranavisahl2015@gmail.com","b",3,"C:\\Users\\Rana1947\\Desktop\\family.jpg",Calendar.getInstance().getTime());

        ImageMessageComp im3= new ImageMessageComp (model3);
        panel.add(im3);
        System.out.println("im3 preferredsize :"+ im3.getPreferredSize());
        im3.setBorder( BorderFactory.createLineBorder(Color.BLACK));
        //panel2.add(im2);
        panel2.add(comp);
        frame.setContentPane(panel2);
        timeStatus(Calendar.getInstance().getTime());
        frame.setVisible(true);
    }
    public static String timeStatus(Date date){
        long millis = date.getTime();
        Calendar c = Calendar.getInstance();
        Date curr  = c.getTime();
        int ch, cm , sh ,sm , dh, dm , tsm ;
        long diff;
        ch = curr.getHours();
        cm =curr.getMinutes();
        dh = date.getHours();
        dm = date.getMinutes();
        diff = curr.getTime() - date.getTime();
        System.out.println(curr);
        System.out.println(date);
        System.out.println(date.getMonth());
        if ( diff < 0 )
            return "Future";
        tsm = (int)(diff/60000);
        sm  = tsm % 60;
        sh = (int)(tsm/60);
        System.out.println(tsm +","+ sm + "," + sh);
        String s;
        if(  ( sh < ch)  | ( ( sh == ch) & (sm <= cm)) )
            return "Today";
        if ( (sh < (ch + 24)  )| (sh == (ch + 24)  & ( sm <= cm)))
            return "Yesterday";
        s = dh + ":"+ dm ;
        return s;
    }
    public static class MyComponent extends JComponent{
        @Override
        public void paint(Graphics g) {
            super.paint(g);
            int x, y ,w , h;
            x = (int)g.getClipBounds().getX();
            y  = (int)g.getClipBounds().getY();
            w = (int)g.getClipBounds().getWidth();
             h = (int)g.getClipBounds().getHeight();
             Graphics2D gg = (Graphics2D)g.create();
             gg.setColor(new Color(255,0,0));
             gg.fillRoundRect(x,y,w,h,20,20);
             gg.dispose();
        }

        @Override
        protected void paintBorder(Graphics g) {
            super.paintBorder(g);
            System.out.println("Border Painted");
            System.out.println("insets :"+ this.getInsets());
        }
    }
}
