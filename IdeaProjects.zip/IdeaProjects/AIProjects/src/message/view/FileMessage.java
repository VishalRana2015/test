package message.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.GeneralPath;
import java.io.File;
import java.util.HashMap;
import message.model.*;

public class FileMessage extends JComponent {
    static private int staticHeight , staticGap ;
    static private HashMap<String, ImageIcon> extmap;
    static ClickListener listener;
    static FileMessageLayoutManager layoutManager ;
    static {
        staticHeight = 50;
        staticGap = 2;
        listener = new ClickListener();
        extmap = new HashMap();
        extmap.put("default",new ImageIcon("C:\\Users\\RANA1947\\IdeaProjects\\ImageEditor\\Images\\file.jpg"));
        layoutManager = new FileMessageLayoutManager();
    }

    private static class  FileMessageLayoutManager implements LayoutManager2 {
        public FileMessageLayoutManager(){
            super();
        }
        @Override
        public void invalidateLayout(Container target) {
            // do nothing
        }

        @Override
        public float getLayoutAlignmentX(Container target) {
            return 0;
        }

        @Override
        public float getLayoutAlignmentY(Container target) {
            return 0;
        }

        @Override
        public void addLayoutComponent(Component comp, Object constraints) {

        }

        @Override
        public void addLayoutComponent(String name, Component comp) {

        }

        @Override
        public void removeLayoutComponent(Component comp) {

        }

        @Override
        public void layoutContainer(Container parent) {
            // This method is responsible for setting the boudns and location for the container 'parent'
            FileMessage message = (FileMessage)parent;
            int sh = message.getStaticHeight();
            int gap = message.getStaticGap();
            Dimension size = message.getSize();
            int width , height;
            int x, y;
            int ncomps = message.getComponentCount();
            Component comp;
            if ( ncomps > 0) {
                comp = message.getComponent(0);
                x = 2*gap + ( sh - 2*gap);
                y = 4*gap;
                width = ((int)size.getWidth() - message.getInsets().left - message.getInsets().right) - x - gap;
                height = (int)comp.getPreferredSize().getHeight();
                comp.setBounds(x, y, width, height);
            }
            //System.out.println("layout done");
        }

        @Override
        public Dimension minimumLayoutSize(Container parent) {
            FileMessage message = (FileMessage)parent;
            Class c = parent.getClass();
            int h =message.getStaticHeight();
            return new Dimension(h*3,h);
        }

        @Override
        public Dimension maximumLayoutSize(Container target) {
            return preferredLayoutSize(target);
        }

        @Override
        public Dimension preferredLayoutSize(Container parent) {
            FileMessage message = (FileMessage)parent;
            int h = message.getStaticHeight();
            int ncomps = message.getComponentCount();
            int w =0;
            System.out.println("ncomps :"+ ncomps);
            for ( int i =0; i <ncomps ; i++){
                Dimension d =  message.getComponent(i).getPreferredSize();
                System.out.println("d :"+ d);
                w =w +  (int)d.getWidth();
            }
            int gap = message.getStaticGap();
            w = w + h;
            w = w + message.getInsets().left + message.getInsets().right + gap;
            h= h + message.getInsets().top + message.getInsets().bottom;
            Font font = parent.getFont();
            if (font ==null)
                font = new Font(Font.SERIF,Font.PLAIN,12);
            int mw = parent.getFontMetrics(font).stringWidth("m");
            int ww= 0; // status width
            if ( message.getModel().isSent())
                ww = message.getFontMetrics(message.getFont()).stringWidth(message.getModel().SentTimeStringStatus()) + 2 + mw*3;
            else
                ww = message.getFontMetrics(message.getFont()).stringWidth(message.getModel().ReceivedTimeStringStatus()) + 1;
            h = h + message.getFont().getSize();
            System.out.println("ww :"+ ww );
            System.out.println("isSent :"+ message.getModel().isSent());
            if ( ww > w )
                return new Dimension(ww,h);
            return new Dimension(w,h);
        }
    }
    static public void setIconFor(String extension , ImageIcon icon)  throws NullPointerException, IllegalArgumentException {
        if ( extension == null || icon == null)
            throw new NullPointerException("One of the arguments is null");
        char ch = extension.charAt(0);
        if ( ch  != '.')
            throw new IllegalArgumentException("Not a valid extension format (Hint: It must start with .)");
        extmap.put(extension,icon);
    }

    static public ImageIcon getIconFor(String extension){
        ImageIcon icon = extmap.get(extension);
        if ( icon == null){
            System.out.println("icon is null");
            icon = extmap.get("default");
        }
        return icon;
    }
    static public int getStaticHeight(){
        return staticHeight;
    }
    static public int getStaticGap(){
        return staticGap;
    }

    public static void setStaticHeight(int height){
        if ( staticHeight < 50)
            staticHeight = 50;
        else
            staticHeight = height;
    }
    public static void setStaticGap(int gap){
        if ( gap < 0)
            staticGap = 0;
        else
            staticGap = gap;
    }
    static class ClickListener implements MouseListener {
        public ClickListener(){
            System.out.println("Listener created");
        }
        @Override
        public void mouseClicked(MouseEvent e) {
            System.out.println("Mouse Clicked");
            Component comp = (Component)e.getSource();
            Container container = comp.getParent();
            if ( container instanceof FileMessage){
                System.out.println("container is an instance of FileMessage Class");
                FileMessage message = (FileMessage)container;
                File file = message.getFile();
                if ( Desktop.isDesktopSupported() ){
                    Desktop desktop = Desktop.getDesktop();
                    if ( file.exists())
                        try {
                            desktop.open(file);
                        }catch( Exception exp){
                            System.out.println("Exception caught :"+ exp.getMessage());
                        }
                    else{
                        JOptionPane.showMessageDialog(message,"File Does not exists","Error Message", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }

        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }

        @Override
        public void mousePressed(MouseEvent e) {

        }

        @Override
        public void mouseReleased(MouseEvent e) {

        }
    }

    File file;
    JLabel filenameLabel ;
    String filename;
    String extension;
    MessageModel model;

    public MessageModel getModel() {
        return model;
    }

    public FileMessage(File file){
        this.file = file;
        this.filename = file.getName();
        super.setLayout( layoutManager);
        filenameLabel = new JLabel(filename);
        int index = filename.lastIndexOf('.');
        extension = filename.substring(index);
        this.add(filenameLabel);
        filenameLabel.addMouseListener(listener);
    }
    public FileMessage( MessageModel model){
        this.file  = new File(model.getFileloc());
        this.filename = file.getName();
        this.model =model;
        super.setLayout(layoutManager);
        filenameLabel = new JLabel(filename);
        int index = filename.lastIndexOf( '.');
        if ( index != -1)
            extension = filename.substring(index);
        else
            extension = "default";
        this.add(filenameLabel);
        filenameLabel.addMouseListener( listener);
    }

    @Override
    public void setLayout(LayoutManager mgr) {
        //super.setLayout(mgr);
    }

    public File getFile() {
        return file;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D gg = (Graphics2D)g.create();
        int x, y, w,h;
        x = this.getInsets().left;
        y = this.getInsets().top;
        w = this.getWidth() - ( this.getInsets().left + this.getInsets().right);
        h = this.getHeight() - ( this.getInsets().top + this.getInsets().bottom);
        ImageIcon icon = getIconFor(this.extension);
        gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        gg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        gg.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        int ix, iy , iw, ih;
        ix = staticGap;
        iy= staticGap;
        iw = (staticHeight - 2*staticGap);
        ih = iw;
        gg.setColor(this.getBackground());
        gg.drawRect(x,y,w,h);
        gg.drawImage(icon.getImage(),ix,iy,iw,ih,null);
        System.out.println("Image Drawned");
        paintStatus ( gg);
        gg.dispose();
    }
    public void paintStatus( Graphics2D gg){
        int x, y , w, h;
        x = this.getInsets().left;
        y = this.getInsets().top;
        w = this.getWidth() - (this.getInsets().left  + this.getInsets().right);
        h = this.getHeight() - ( this.getInsets().top + this.getInsets().bottom);
        String timestatus;
        int sh = gg.getFont().getSize();
        int as, ds;// stands for ascent and descent
        as = gg.getFontMetrics(gg.getFont()).getAscent();
        ds = gg.getFontMetrics(gg.getFont()).getDescent();
        if ( this.getModel().isSent()){
            timestatus = this.getModel().SentTimeStringStatus();
            int sw = gg.getFontMetrics(gg.getFont()).stringWidth( timestatus);
            // creating a graphics object to paintStatusIcon
            int tw = gg.getFontMetrics(gg.getFont()).stringWidth("mm");
            Graphics2D pg = (Graphics2D)gg.create();
            pg.setClip(x+w-tw,y+h-sh,tw,sh);
            paintStatusIcon(pg);
            pg.dispose();
            // Now painting the string
            gg.setColor( Color.BLACK);
            System.out.println("tw :"+ tw);
            System.out.println("x,y " + (x+w-tw -1)+ ","+ (y+h-sh/2 + as/2 - ds/2));
            gg.drawString(timestatus , x + w -tw -sw-1 , y + h - sh/2 + as/2 -ds/2 );
            System.out.println("String drawned for sent message");

        }
        else{
            timestatus = this.getModel().SentTimeStringStatus();
            int sw = gg.getFontMetrics(gg.getFont()).stringWidth( timestatus);
            gg.drawString(timestatus ,  x+w -1 -sw , y + h - sh/2 + as/2 - ds/2);
            System.out.println("status drawned for received message");
        }
    }
    protected void paintStatusIcon(Graphics2D  g) {
        //System.out.println("g clip area :"+ g.getClipBounds());
        Graphics2D gg = (Graphics2D)g.create();
        gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING , RenderingHints.VALUE_ANTIALIAS_ON);
        gg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING , RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int bo , to, lo, ro, gap; // stands for bottom offset , top offset , left offset, right offset, and gap.\
        int x, y, w , h;
        x = (int)gg.getClipBounds().getX();
        y =(int)gg.getClipBounds().getY();
        w = (int)gg.getClipBounds().getWidth();
        h = (int)gg.getClipBounds().getHeight();
        gg.setColor(Color.YELLOW);
        gg.fillRect(x,y,w,h);
        lo = (int)( w*0.04);
        ro = (int)(w*0.15);
        bo = (int)(h*0.1);
        to = (int)(h*0.1);
        gap = (int)(w*0.1);
        //gg.drawRect(x,y,w,h);
        int lineWidth = Math.max(1,(int)(w*0.04));
        gg.setStroke(new BasicStroke(lineWidth,BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER));
        GeneralPath tick1 = new GeneralPath(GeneralPath.WIND_NON_ZERO);
        gg.setColor( Color.BLACK);
        if ( this.getModel().getSentStatus() == MessageModel.DELIVERED || this.getModel().getSentStatus() == MessageModel.SENT) {
            if (false)
                gg.setColor(new Color(0, 200, 200));
            else
                gg.setColor(Color.GRAY);
            tick1.moveTo(x + lo, y + h / 2);
            tick1.lineTo(x + w / 3, y + h - bo);
            tick1.lineTo(x + w - ro, y + to);
            gg.draw(tick1);
            System.out.println("Something is drawned");
            GeneralPath tick2 = new GeneralPath(GeneralPath.WIND_EVEN_ODD);
            if (this.getModel().getSentStatus() == MessageModel.SENT) {

                tick2.moveTo(x + lo + gap, y + h / 2);
                tick2.lineTo(x + w / 3 + gap, y + h - bo);

                tick2.lineTo(x + w - ro + gap, y + to);
                gg.draw(tick2);
                System.out.println("Second tick is drawned");
            }
        }
        if ( this.getModel().getSentStatus() == MessageModel.NOTSENT){
            gg.setColor( Color.RED);
            System.out.println("lo,to,w-ro,h-bo : "+ lo + ","+ ro + ","+ (w-ro) + ","+ (h-bo));
            gg.drawLine(x+lo,y+to,x+w-ro,y+h-bo);
            gg.drawLine(x+w-ro,y+to,x+lo,y+h-bo);
            System.out.println("NOt send is drawned");
        }
        if ( this.getModel().getSentStatus() == MessageModel.PROGRESS){
            gg.setColor( Color.GRAY);
            int mx ,my;
            my = to + h/2;
            gg.drawString("...",x+lo,y+my);
            System.out.println("Progress is drawned");
        }
        gg.dispose();
    }

}