package message.view;
import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
public class CustomProgressBar extends JProgressBar{

}
