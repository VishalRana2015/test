package message.view;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.GeneralPath;
import java.awt.geom.Path2D;

public class TickComponent extends JComponent {
    public static int SINGLETICK = 1;
    public static int DOUBLETICK = 2;
    public static int DOUBLESEENTICK = 3;
    public static int CROSS = 4;
    public static int PROGRESS = 5;
    int tickType;
    public TickComponent(int tickType)throws IllegalArgumentException{
        if ( tickType == SINGLETICK || tickType == DOUBLETICK || tickType == DOUBLESEENTICK || tickType == CROSS || tickType== PROGRESS )
            this.tickType = tickType;
        else
            throw new IllegalArgumentException("Not a valid tick Type");
    }

    public int getTickType() {
        return tickType;
    }

    @Override
    public Dimension getPreferredSize() {
        int w ,h;
        w = this.getFontMetrics(this.getFont()).stringWidth("ABC");
        h = this.getFont().getSize()+4;
        return new Dimension(w,h);
    }

    @Override
    public Dimension getMinimumSize() {
        int w ,h;
        w = this.getFontMetrics(this.getFont()).stringWidth("ABC");
        h = this.getFont().getSize()+4;
        return new Dimension(w,h);
    }

    @Override
    public Dimension getMaximumSize() {
        int w,h;
        w = this.getFontMetrics(this.getFont()).stringWidth("ABC");
        h = this.getFont().getSize() + 4;
        return new Dimension(w,h);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        //System.out.println("g clip area :"+ g.getClipBounds());
        Graphics2D gg = (Graphics2D)g.create();
        gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING , RenderingHints.VALUE_ANTIALIAS_ON);
        gg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING , RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int bo , to, lo, ro, gap; // stands for bottom offset , top offset , left offset, right offset, and gap.\
        int x, y, w , h;
        x = (int)gg.getClipBounds().getX();
        y =(int)gg.getClipBounds().getY();
        w = (int)gg.getClipBounds().getWidth();
        h = (int)gg.getClipBounds().getHeight();
        lo = (int)( w*0.04);
        ro = (int)(w*0.15);
        bo = (int)(h*0.1);
        to = (int)(h*0.1);
        gap = (int)(w*0.1);
        //gg.drawRect(x,y,w,h);
        int lineWidth = Math.max(1,(int)(w*0.04));
        gg.setStroke(new BasicStroke(lineWidth,BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER));
        GeneralPath tick1 = new GeneralPath(GeneralPath.WIND_NON_ZERO);
        if ( this.getTickType() == DOUBLESEENTICK || this.getTickType() == SINGLETICK || this.getTickType() == DOUBLETICK) {
            if (this.getTickType() == DOUBLESEENTICK)
                gg.setColor(new Color(0, 200, 200));
            else
                gg.setColor(Color.GRAY);
            tick1.moveTo(x + lo, y + h / 2);
            tick1.lineTo(x + w / 3, y + h - bo);
            tick1.lineTo(x + w - ro, y + to);
            gg.draw(tick1);
            GeneralPath tick2 = new GeneralPath(GeneralPath.WIND_EVEN_ODD);
            if (this.getTickType() != SINGLETICK) {

                tick2.moveTo(x + lo + gap, y + h / 2);
                tick2.lineTo(x + w / 3 + gap, y + h - bo);

                tick2.lineTo(x + w - ro + gap, y + to);
                gg.draw(tick2);
            }
        }
        if ( this.getTickType() == CROSS ){
            gg.setColor( Color.RED);
            gg.drawLine(lo,to,w-ro,h-bo);
            gg.drawLine(w-ro,to,lo,h-bo);
        }
        if ( this.getTickType() == PROGRESS){
            gg.setColor( Color.GRAY);
            int mx ,my;
            my = to + h/2;
            gg.drawString("...",lo,my);
        }
        gg.dispose();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("TickComponent Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        TickComponent comp = new TickComponent(TickComponent.DOUBLESEENTICK);
        comp.setFont(new Font(Font.SANS_SERIF,Font.BOLD,50));
        panel.add(comp);
        frame.setContentPane(panel);
        frame.setVisible(true);
    }
}
