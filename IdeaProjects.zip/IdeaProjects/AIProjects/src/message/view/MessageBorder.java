package message.view;
import message.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.*;
import java.awt.*;
import javax.swing.event.*;
public class MessageBorder  extends EmptyBorder {
    public static String LEFT  = "LEFT";
    public static String RIGHT = "RIGhT";
    public static String TOP  = "TOP";
    public static String BOTTOM = "BOTTOM";

    public MessageBorder(int top , int left , int bottom , int right){
        super(top,left, bottom , right);

    }
    @Override
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        super.paintBorder(c, g, x, y, width, height);
        // This method is responsible for painting the border around the MessageComponent ( just like as in whatsapp) only if c is
        // instance of MessageComponent
        if ( !(c instanceof  MessageComponent))
            return;
        MessageComponent comp = (MessageComponent)c;
        int lines ;
        // drew the things just drew them
        Insets inset = this.getBorderInsets();
        System.out.println("Insets :"+ inset);
    }
}
