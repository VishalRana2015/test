package message.view;
import message.model.MessageModel;

import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.geom.GeneralPath;
import java.util.*;
import java.awt.image.*;
public class ImageMessageComp extends JComponent {
    Image image;
    static int iw = 200;
    static int ih= 150;
    int cw, ch;
    Color shadeColor;
    int expandTo;
    MyImageObserver observer;
    MessageModel model;
    ImageMessageComp(ImageIcon icon , int cw, int ch){
        super();
        this.setWidthAndHeight(cw,ch);
        observer = new MyImageObserver();
        this.shadeColor = Color.ORANGE;
        expandTo = 10;
        this.setImage(icon.getImage());
    }
    ImageMessageComp ( MessageModel model){
        this.model = model;
        this.setWidthAndHeight(iw,ih);
        observer = new MyImageObserver();
        this.shadeColor = Color.ORANGE;
        expandTo = 10;
        ImageIcon icon = new ImageIcon(model.getFileloc());
        if ( icon != null)
            this.setImage(icon.getImage());

    }

    public MessageModel getModel() {
        return model;
    }

    public void setWidthAndHeight(int cw, int ch){
        this.cw = cw;
        this.ch = ch;
        this.setSize(cw,ch);
        this.setPreferredSize(new Dimension(cw,ch));
        this.setMinimumSize(new Dimension(cw,ch));
        this.setMaximumSize( new Dimension(cw,ch));
    }
    public void setImage(Image image){
        int savedWidth, savedHeight;
        savedWidth = image.getWidth(null);
        savedHeight = image.getHeight(null);
        System.out.println("savedWidth :" + savedWidth + " savedHeigth :"+ savedHeight);
        double ratio = (double)savedWidth / (double)savedHeight;
        int dw, dh; // stands for displayableWidth and displayableHeight
        dw = (int)(ch/ratio);
        dh = (int)( cw/ratio);
        int iw, ih;
        if ( dh < ch){
            iw = cw;
            ih = dh;
        }
        else{
            ih= ch;
            iw= (int)(ih*ratio);
        }

        BufferedImage bimage = new BufferedImage(cw, ch, BufferedImage.TYPE_INT_RGB);

        Graphics2D gg = (Graphics2D)bimage.getGraphics();
        gg.setClip(0,0,cw,ch); // I was getting empty clip bounds I don't know why
        int x , y ,w , h;

        x = (int)gg.getClipBounds().getX();

        y = (int)gg.getClipBounds().getY();
        w = (int)gg.getClipBounds().getWidth();
        h = (int)gg.getClipBounds().getHeight();
        gg.setColor(Color.BLACK);
        gg.fillRect(x,y,w,h);
        int ix, iy;
        Color color;
        int red , green, blue;
        red = shadeColor.getRed();
        green = shadeColor.getGreen();
        blue = shadeColor.getBlue();
        ix = x + cw/2 -iw/2;
        iy = y + ch/2  -ih/2;
        gg.drawImage(image,ix,iy,iw,ih,observer);
        int alpha=255;
        double alphaDecay = 256.0 / (( this.expandTo/100.0 ) * ch);
        for ( int r = ch-2; r >=0; r--){
            color = new Color( red, green , blue , alpha);
            gg.setColor( color);
            gg.fillRect(0,r,cw,1);
            alpha = (int)(alpha - alphaDecay);
            if ( alpha <=0 )
                break;
        }
        gg.dispose();

        this.image = (Image)bimage;

    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D gg = (Graphics2D)g.create();
        int x , y , w, h;
        x = this.getInsets().left;
        y = this.getInsets().top;
        w = this.getWidth() - ( this.getInsets().left + this.getInsets().right);
        h = this.getHeight() - ( this.getInsets().top + this.getInsets().bottom);
        gg.drawImage(this.image, x,y,w,h,null);
        gg.dispose();
    }
    public void paintStatus( Graphics2D gg){
        int x, y , w, h;
        x = this.getInsets().left;
        y = this.getInsets().top;
        w = this.getWidth() - (this.getInsets().left  + this.getInsets().right);
        h = this.getHeight() - ( this.getInsets().top + this.getInsets().bottom);
        String timestatus;
        int sh = gg.getFont().getSize();
        int as, ds;// stands for ascent and descent
        as = gg.getFontMetrics(gg.getFont()).getAscent();
        ds = gg.getFontMetrics(gg.getFont()).getDescent();
        if ( this.getModel().isSent()){
            timestatus = this.getModel().SentTimeStringStatus();
            int sw = gg.getFontMetrics(gg.getFont()).stringWidth( timestatus);
            // creating a graphics object to paintStatusIcon
            int tw = gg.getFontMetrics(gg.getFont()).stringWidth("mm");
            Graphics2D pg = (Graphics2D)gg.create();
            pg.setClip(x+w-tw,y+h-sh,tw,sh);
            paintStatusIcon(pg);
            pg.dispose();
            // Now painting the string
            gg.setColor( Color.BLACK);
            System.out.println("tw :"+ tw);
            System.out.println("x,y " + (x+w-tw -1)+ ","+ (y+h-sh/2 + as/2 - ds/2));
            gg.drawString(timestatus , x + w -tw -sw-1 , y + h - sh/2 + as/2 -ds/2 );
            System.out.println("String drawned for sent message");

        }
        else{
            timestatus = this.getModel().SentTimeStringStatus();
            int sw = gg.getFontMetrics(gg.getFont()).stringWidth( timestatus);
            gg.drawString(timestatus ,  x+w -1 -sw , y + h - sh/2 + as/2 - ds/2);
            System.out.println("status drawned for received message");
        }
    }
    protected void paintStatusIcon(Graphics2D  g) {
        //System.out.println("g clip area :"+ g.getClipBounds());
        Graphics2D gg = (Graphics2D)g.create();
        gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING , RenderingHints.VALUE_ANTIALIAS_ON);
        gg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING , RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int bo , to, lo, ro, gap; // stands for bottom offset , top offset , left offset, right offset, and gap.\
        int x, y, w , h;
        x = (int)gg.getClipBounds().getX();
        y =(int)gg.getClipBounds().getY();
        w = (int)gg.getClipBounds().getWidth();
        h = (int)gg.getClipBounds().getHeight();
        gg.setColor(Color.YELLOW);
        gg.fillRect(x,y,w,h);
        lo = (int)( w*0.04);
        ro = (int)(w*0.15);
        bo = (int)(h*0.1);
        to = (int)(h*0.1);
        gap = (int)(w*0.1);
        //gg.drawRect(x,y,w,h);
        int lineWidth = Math.max(1,(int)(w*0.04));
        gg.setStroke(new BasicStroke(lineWidth,BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER));
        GeneralPath tick1 = new GeneralPath(GeneralPath.WIND_NON_ZERO);
        gg.setColor( Color.BLACK);
        if ( this.getModel().getSentStatus() == MessageModel.DELIVERED || this.getModel().getSentStatus() == MessageModel.SENT) {
            if (false)
                gg.setColor(new Color(0, 200, 200));
            else
                gg.setColor(Color.GRAY);
            tick1.moveTo(x + lo, y + h / 2);
            tick1.lineTo(x + w / 3, y + h - bo);
            tick1.lineTo(x + w - ro, y + to);
            gg.draw(tick1);
            System.out.println("Something is drawned");
            GeneralPath tick2 = new GeneralPath(GeneralPath.WIND_EVEN_ODD);
            if (this.getModel().getSentStatus() == MessageModel.SENT) {

                tick2.moveTo(x + lo + gap, y + h / 2);
                tick2.lineTo(x + w / 3 + gap, y + h - bo);

                tick2.lineTo(x + w - ro + gap, y + to);
                gg.draw(tick2);
                System.out.println("Second tick is drawned");
            }
        }
        if ( this.getModel().getSentStatus() == MessageModel.NOTSENT){
            gg.setColor( Color.RED);
            System.out.println("lo,to,w-ro,h-bo : "+ lo + ","+ ro + ","+ (w-ro) + ","+ (h-bo));
            gg.drawLine(x+lo,y+to,x+w-ro,y+h-bo);
            gg.drawLine(x+w-ro,y+to,x+lo,y+h-bo);
            System.out.println("NOt send is drawned");
        }
        if ( this.getModel().getSentStatus() == MessageModel.PROGRESS){
            gg.setColor( Color.GRAY);
            int mx ,my;
            my = to + h/2;
            gg.drawString("...",x+lo,y+my);
            System.out.println("Progress is drawned");
        }
        gg.dispose();
    }

    private class MyImageObserver implements ImageObserver{

        @Override
        public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {
            System.out.println("Image Observer called");
            if ( (infoflags & ImageObserver.FRAMEBITS) != 0)
                System.out.println("FrameBits are available");
            if ( (infoflags & ImageObserver.ALLBITS ) != 0)
                System.out.println("static image is done");
            if ( (infoflags & ImageObserver.WIDTH) != 0)
                System.out.println("Now width is available");
            if ( (infoflags & ImageObserver.HEIGHT ) != 0)
                System.out.println("Now Height is available");
            if ( (infoflags & ImageObserver.SOMEBITS) != 0)
                System.out.println("called for some bits");
            if ( (infoflags & ImageObserver.ABORT) != 0 )
                System.out.println("Abort");
            if ( (infoflags & ImageObserver.ERROR) != 0)
                System.out.println("Error");
            if (  ( (infoflags & ImageObserver.ALLBITS ) | ( infoflags & ImageObserver.FRAMEBITS) ) != 0)
                repaint();
            return true;
        }
    }
  /*  static private class CustomFilter extends ImageFilter{
        int savedWidth ,savedHeight;
        int filterWidth, filterHeight; // stands for filterWidth and filterHeight
        int[] savedPixels;
        ColorModel model;
        int hints;
        @Override
        public void setDimensions(int width, int height) {
            savedWidth = width;
            savedHeight = height;
            savedPixels = new int[ savedHeight * savedWidth];
        }

        @Override
        public void setColorModel(ColorModel model) {
            this.model = model;
        }

        @Override
        public void setHints(int hints) {
            this.hints = hints;
        }

        @Override
        public void setProperties(Hashtable<?, ?> props) {
            consumer.setProperties(props);
        }

        @Override
        public void setPixels(int x, int y, int w, int h, ColorModel model, int[] pixels, int off, int scansize) {
            //super.setPixels(x, y, w, h, model, pixels, off, scansize);
            int row, column;
            for ( int r = 0; r < h; r++){
                row = r + x;
                for ( int c = 0;  c< w; c++) {
                    column = c + y;
                    savedPixels[row* savedWidth + column] = pixels[r*scansize + c];
                }
            }

        }

        @Override
        public void setPixels(int x, int y, int w, int h, ColorModel model, byte[] pixels, int off, int scansize) {
            //super.setPixels(x, y, w, h, model, pixels, off, scansize);
            // We are ignoring for the moment the setPixels byte version of the method
        }

        @Override
        public void imageComplete(int status) {
            // This is the method where actual is taking place
            if (( ( status & ImageConsumer.IMAGEABORTED ) | ( status & ImageConsumer.IMAGEERROR) ) != 0)
                consumer.imageComplete(status);
            else{
                double ratio = savedWidth / savedHeight;
                int dw, dh; // stands for displayableWidth and displayableHeight
                dw = (int)(filterHeight/ratio);
                dh = (int)( filterWidth/ratio);
                int iw, ih;
                if ( dh < filterHeight){
                    ih = dh;
                    iw= filterWidth;
                }
                else{
                    ih= filterHeight;
                    iw= dw;
                }
                BufferedImage bimage = new BufferedImage(filterWidth, filterHeight, BufferedImage.TYPE_INT_RGB);
                Graphics2D gg = (Graphics2D)bimage.getGraphics();
                int x, y ,w , h;
                x = (int)gg.getClipBounds().getX();
                y = (int)gg.getClipBounds().getY();
                w = (int)gg.getClipBounds().getWidth();
                h = (int)gg.getClipBounds().getHeight();
                gg.setColor(Color.BLACK);
                gg.fillRect(x,y,w,h);
                int ix,iy;
                ix = x + w/2 -iw/2;
                iy= y + h/2 - ih/2;
                MemoryImageSource mis = new MemoryImageSource(savedWidth,savedHeight,savedPixels,0,savedWidth);
               // There seems to be too many problems with java
                Image image = Toolkit.getDefaultToolkit().createImage(mis);



            }
        }
    }
*/}
