package message.view;


import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.time.*;
import javax.imageio.*;
public class ImageMessage extends JComponent{
    private int w, h;
    File file ;
    BufferedImage image;
    LocalDateTime time;
    Font metaFont = new Font(Font.SANS_SERIF,Font.ITALIC,6);

    public ImageMessage(File file ) throws IOException {
        setW(100);
        setH(100);
        this.file = file;
        image = ImageIO.read(file);
        if ( image == null)
            throw new IOException("Not a valid image type");
        this.time = LocalDateTime.now();
    }
    // This specifies width and height of the component

    @Override
    public Dimension getMinimumSize() {
        return new Dimension(w,h);
    }

    @Override
    public Dimension getMaximumSize() {
        return new Dimension(w,h);
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(w,h);
    }

    public void setMetaFont(Font metaFont) {
        this.metaFont = metaFont;
    }

    public Font getMetaFont() {
        return metaFont;
    }

    public void setW(int w) {
        this.w = w;
        if ( this.w < 100)
            this.w = 100;
    }

    public void setH(int h) {
        this.h = h;
        if ( this.h < 100)
            this.h = 100;
    }

    public int getW() {
        return w;
    }

    public int getH() {
        return h;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // This method is responsible for painting the image in the specified dimension ( w,h).
       Graphics2D gg = (Graphics2D)g.create();
       int x, y , w, h;
       x = (int)gg.getClipBounds().getX();
       y = (int)gg.getClipBounds().getY();
       w = (int)gg.getClipBounds().getWidth();
       h = (int)gg.getClipBounds().getHeight();
       gg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
       gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
       gg.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BICUBIC);
       // there properties insure smooth painting at the cost of computing power.
       gg.drawImage(image,x,y,x+w,y+h,0,0,image.getWidth(),image.getHeight(),null);
       //After drawing image to the given area we would have to draw it's meta info at the end
        System.out.println("painted image");
        String size = getSize(file);
        gg.setColor(Color.GRAY);
        int sx , sy;
        sx= x+ 10 ;
        int  descent , gap ;
        gap = 1;
        descent = gg.getFontMetrics(metaFont).getDescent();
        sy = y + h  - descent - gap;
        gg.drawString(size,sx,sy);


    }
    private static String getSize(File file){
        double size = file.length();
        String sizein = "kb";
        size = size/1024;
        if ( size > 1024 ){
            size = size / 1024;
            sizein = "mb";
        }
        if ( size > 1024){
            size = size /1024;
            sizein = "gb";
        }
        String s = (int)size + sizein;
        return s;
    }
    public static void main(String[] args) {
        JFrame frame = new JFrame("Image Message Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocation(50,0);
        frame.setSize(500,500);
        JPanel panel = new JPanel();
        File file = new File("C:\\Users\\RANA1947\\icon.jpg");
        ImageMessage msg = null;
        try{
            msg = new ImageMessage(file);
            panel.add(msg);
        }
        catch(Exception e){
            System.out.println("Exception caught :"+ e.getMessage());
            panel.add(new JLabel("panel is empty"));
        }
        frame.setContentPane(panel);
        frame.setVisible(true);
    }
}
