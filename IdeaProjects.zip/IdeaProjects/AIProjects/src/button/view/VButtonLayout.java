package button.view;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
// This class is responsible for laying out the components of the JButton
public class VButtonLayout  implements  LayoutManager2{
    @Override
    public void layoutContainer(Container parent) {
        // Hello brother from the best of my heart
        int x,y, gap ,aw, ah, userNameWidth, timestampWidth, lastMessageWidth;
        int messagedw, messagedh , pendingw;
        int bw, bh;
        Dimension mindim , predim;
        VButton button = (VButton)parent;
        mindim = button.getMinimumSize();
        bw = button.getButtonWidth();
        bh = button.getButtonHeight();
        aw = button.getWidth();
        ah = button.getButtonHeight();
        x = (int)(0.27*bw);
        y = (int)(0.25*bh);
        userNameWidth = button.getUserNameLabel().getFontMetrics(button.getUserNameLabel().getFont()).stringWidth(button.model.getUserName());
        timestampWidth = button.getTimestampLabel().getFontMetrics(button.getTimestampLabel().getFont()).stringWidth(button.getTimestampLabelString());
        lastMessageWidth = button.getLastMessageLabel().getFontMetrics(button.getLastMessageLabel().getFont()).stringWidth(button.model.getLastMessage());
        gap = (int)Math.min(5,0.01*bw);
        // Setting bounds for usernameLabel
        int userNamedw, userNamedh;
        if ( aw >  mindim.getWidth()){
            bw = aw;
        }
        else
            bw = bw;

        userNamedw = Math.min(bw  -x  - timestampWidth - 2*gap,userNameWidth);
        userNamedh= (int)(bh * 0.2);
        button.getUserNameLabel().setLocation(x,y);
        button.getUserNameLabel().setSize(new Dimension(userNamedw, userNamedh));
        System.out.println("bw :" +bw);
        // Setting bounds for timestamp label
        int tx;
        tx = bw - timestampWidth - gap ;
        int timestampdw, timestampdh;
        timestampdw = timestampWidth;
        timestampdh = userNamedh;
        button.getTimestampLabel().setLocation(tx,y);
        button.getTimestampLabel().setSize(new Dimension(timestampdw, timestampdh));
        // Setting bounds for last message
        y += (int)(bh*0.3);

        pendingw = (int)Math.min(0.1*button.getButtonWidth(),10);
        messagedw = Math.min(bw-x-2*gap-pendingw,lastMessageWidth);
        messagedh = (int)(button.getButtonHeight()*0.2);
        button.getLastMessageLabel().setLocation(x,y);
        button.getLastMessageLabel().setSize(messagedw,messagedh);
    }

    @Override
    public void invalidateLayout(Container target) {

    }

    @Override
    public void removeLayoutComponent(Component comp) {

    }

    @Override
    public void addLayoutComponent(String name, Component comp) {

    }

    @Override
    public void addLayoutComponent(Component comp, Object constraints) {

    }

    @Override
    public float getLayoutAlignmentY(Container target) {
        return 0;
    }

    @Override
    public float getLayoutAlignmentX(Container target) {
        return 0;
    }

    @Override
    public Dimension preferredLayoutSize(Container parent) {
        if ( !(parent instanceof VButton))
            return null;
        int pw,ph;
        VButton button = (VButton)parent;
        pw = button.getButtonWidth();
        int userNameWidth , timestampWidth , gap ;
        userNameWidth = button.getUserNameLabel().getFontMetrics(button.getUserNameLabel().getFont()).stringWidth(button.model.getUserName());
        timestampWidth = button.getTimestampLabel().getFontMetrics(button.getTimestampLabel().getFont()).stringWidth(button.getTimestampLabelString());
        gap = (int)Math.min(5,button.getButtonWidth()*0.01);
        pw = (int)(button.getButtonWidth()*0.4) + userNameWidth + timestampWidth + 2*gap;
        ph= button.getButtonHeight();
        return new Dimension(pw,ph);  // stands for preferredWidth and preferredHeight
    }

    @Override
    public Dimension minimumLayoutSize(Container parent) {
        if(  !(parent instanceof  VButton))
            return null;
        int w, h;
        VButton button = (VButton)parent;
        w = button.getButtonWidth();
        h = button.getButtonHeight();
        return new Dimension(w,h);
    }

    @Override
    public Dimension maximumLayoutSize(Container target) {
        if ( !( target instanceof VButton))
            return null;
        int w,h;
        w = Integer.MAX_VALUE;
        VButton button = (VButton)target;
        h= button.getButtonHeight();
        return new Dimension(w,h);
    }
}
