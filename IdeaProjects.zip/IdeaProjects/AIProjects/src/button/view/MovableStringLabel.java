package button.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class MovableStringLabel extends JComponent{
    String text;
    String dtext;
    int sbx,sby;
    boolean hover;
    MovableMouseListener listener ;
    public void setHover(boolean hover) {
        this.hover = hover;
    }

    public boolean isHover() {
        return hover;
    }

    public MovableStringLabel(){
        text = "";
        hover = false;
        listener = new MovableMouseListener(this);
        this.addMouseListener(listener);
    }
    public MovableStringLabel(String text){

        this.text = text;
        listener = new MovableMouseListener(this);
        this.addMouseListener(listener);
        this.invalidate();
    }

    @Override
    public void setSize(Dimension d) {
        System.out.println("set Bounds called ( Dimension d)");
        super.setSize(d);
        sby= (int) (d.getHeight()/2) + this.getFontMetrics(this.getFont()).getDescent();
        sbx = 1;
    }

    @Override
    public void setBounds(int x, int y, int width, int height) {
       // System.out.println("setBounds(x,y,width,height) called" + x+","+y+","+width+","+height);
        int sw ;
        sw= this.getFontMetrics(this.getFont()).stringWidth(this.getText());
        if ( width < sw ){
            // remove some characters from the last of the string";
            dtext = text;
            int subsw = sw;
            for ( int i = 1; i < text.length();  i++){
                dtext = text.substring(0,text.length()-i);
                subsw = this.getFontMetrics(this.getFont()).stringWidth(dtext);
                if ( subsw <= width){
                    break;
                }
            }
            dtext = dtext.substring(0,Math.max(0,dtext.length()-3));
            dtext = dtext.concat("...");
        }
        else{
            dtext =text;
        }
        super.setBounds(x, y, width, height);
        sby = (int) (height/2) + this.getFontMetrics(this.getFont()).getDescent();
        sbx = 1;
    }

    @Override
    public void setBounds(Rectangle r) {
        super.setBounds(r);
        sby = (int) (r.getHeight()/2)+ this.getFontMetrics(this.getFont()).getDescent();
        sbx = 1;
    }

    @Override
    public Dimension getMinimumSize() {
        Dimension  d = new Dimension(0,0);
        d.setSize(10,this.getFont().getSize()+2);
        //System.out.println("minimum Size returning :"+ d);
        return d;
    }
    @Override
    public Dimension getPreferredSize(){
        Dimension d = new Dimension (0,0);
        d.setSize(this.getFontMetrics(this.getFont()).stringWidth(this.getText()), this.getFont().getSize()+ 2);
       // System.out.println("preferred Size returning :"+ d);
        return d;

    }
    @Override
    public Dimension getMaximumSize(){
        Dimension d = new Dimension(0,0);
        d.setSize( this.getFontMetrics(this.getFont()).stringWidth(this.getText()) + 100 , this.getFont().getSize() + 10);
        //System.out.println("im maximum Size :"+ d);
        return d;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D gg = (Graphics2D)g.create();
        gg.setColor(new Color(255,255,128));
        int x , y , gw, gh;
        x = (int)g.getClipBounds().getX();
        y = (int)g.getClipBounds().getY();
        gw = (int)g.getClipBounds().getWidth();
        gh = (int)g.getClipBounds().getHeight();
        int w, h;

        w = this.getWidth();
        h = this.getHeight();
        gg.fillRect(x,y,gw,gh);
        System.out.println("gw :"+ gw + " gh:"+ gh);
        gg.setColor(new Color(0,0,0));
        gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        gg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        if ( this.isHover()){
            gg.drawString(this.text,sbx,sby);
        }
        else {
            gg.drawString(this.dtext, sbx, sby);
        }
        gg.dispose();
    }

    public String getText() {
        return text;
    }

    static class MoveStringThread extends Thread{
        MovableStringLabel boundedComp;
        public MoveStringThread(MovableStringLabel boundedComp){
            super();
            this.boundedComp = boundedComp;
        }

        @Override
        public void run() {
            while( boundedComp.isHover()){
                int sw, w;
                w = boundedComp.getWidth();
                sw = boundedComp.getFontMetrics(boundedComp.getFont()).stringWidth(boundedComp.getText());
                if ( sw > w) {
                    if (boundedComp.sbx + sw > w) {
                        boundedComp.sbx -= boundedComp.getFont().getSize() / 2;
                    }
                    else
                        boundedComp.sbx = 1;
                    boundedComp.repaint();
                }
                else
                    break;
                try {
                    Thread.sleep(300);
                }
                catch(Exception e){
                    System.out.println("Exception caught :"+ e.getMessage());
                }
            }
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Movalble String Label Deom");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(new Dimension(500,500));
        frame.setLocation(50,0);
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel,BoxLayout.PAGE_AXIS));
        MovableStringLabel msl = new MovableStringLabel("Hello world what are you doing write now.");
        panel.add(msl);
        msl.setAlignmentX(0.0f);
        JButton button = new JButton("Hello world");
        JButton button2= new JButton("Hello world2");
        //panel.add(new JButton("hello world");
        panel.add(button);
        panel.add(button2);
        System.out.println(" is msl visible " + msl.isVisible());
        frame.setContentPane(panel);
        frame.setVisible(true);
    }
    static class MovableMouseListener implements MouseListener{
        MovableStringLabel boundedComp;
        MovableMouseListener(MovableStringLabel boundedComp){
            this.boundedComp = boundedComp;
        }

        @Override
        public void mouseReleased(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {
            boundedComp.setHover(false);
            boundedComp.sbx = 1;
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            boundedComp.setHover(true);
            MoveStringThread thread = new MoveStringThread(boundedComp);
        //    System.out.println("Thread is being started");
            thread.start();
          //  System.out.println("thread has been started");
        }

        @Override
        public void mousePressed(MouseEvent e) {

        }

        @Override
        public void mouseClicked(MouseEvent e) {

        }
    }
}
