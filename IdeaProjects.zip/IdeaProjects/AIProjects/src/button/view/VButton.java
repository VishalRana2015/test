package button.view;
import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;
import button.model.*;

public class VButton extends JComponent{

    VButtonModel model;
    int buttonWidth;
    int buttonHeight;
    Color bgColor = new Color(2,255,255);
    MovableStringLabel userNameLabel ;
    JLabel lastMessageLabel ;
    JLabel timestampLabel;
    VButton(String userName, String userID, ImageIcon icon){
        super();
        model = new  VButtonModel(userName, userID, icon, this);
        this.setLayout(new VButtonLayout());
        actionListeners = new Vector<ActionListener>();
        userNameLabel = new MovableStringLabel(model.getUserName());
        lastMessageLabel = new JLabel("What the fuck");
        timestampLabel = new JLabel(this.getTimestampLabelString());
        this.add(userNameLabel);
        this.add(timestampLabel);
        this.add(lastMessageLabel);
        this.setButtonWidth(300);
    }

    public VButtonModel getModel() {
        return model;
    }

    public JLabel getLastMessageLabel() {
        return lastMessageLabel;
    }

    public MovableStringLabel getUserNameLabel() {
        return userNameLabel;
    }

    public JLabel getTimestampLabel() {
        return timestampLabel;
    }

    public int getButtonHeight() {
        return buttonHeight;
    }

    public void setButtonHeight(int buttonHeight) {
        this.buttonHeight = buttonHeight;
        Font font = new Font(Font.SANS_SERIF,Font.BOLD,(int)(buttonHeight*0.15));
        this.getUserNameLabel().setFont(font);
        font  = new Font(Font.SANS_SERIF,Font.PLAIN,(int)(buttonHeight*0.1));
        this.getTimestampLabel().setFont(font);
    }

    public int getButtonWidth() {
        return buttonWidth;
    }

    Vector<ActionListener> actionListeners;
    public void setButtonWidth(int buttonWidth) {
        this.buttonWidth = buttonWidth;
        this.setButtonHeight((int)((0.3)*buttonWidth));
    }

    @Override
    public Dimension getMinimumSize() {
        if ( this.getLayout() != null && this.getLayout() instanceof VButtonLayout){
            return this.getLayout().minimumLayoutSize(this);
        }
        return super.getMinimumSize();
    }

    @Override
    public Dimension getMaximumSize() {
        if ( this.getLayout() != null && this.getLayout() instanceof  VButtonLayout){
            return ((VButtonLayout) this.getLayout()).maximumLayoutSize(this);
        }
        return super.getMaximumSize();
    }

    @Override
    public Dimension getPreferredSize() {
        if ( this.getLayout() != null && this.getLayout() instanceof VButtonLayout) {
            System.out.println("returning preferredLayoutSize(this)");
            return this.getLayout().preferredLayoutSize(this);
        }
        return super.getPreferredSize();
    }

    public void addActionListener(ActionListener listener){
        if ( !actionListeners.contains(listener))
            actionListeners.add(listener);
        else
            System.out.println("Listener is already in the list.");
    }
    public void removeActionListener(ActionListener listener){
        if ( actionListeners.contains(listener))
            actionListeners.remove(listener);
        else
            System.out.println("Action Listener was not in the list");
    }
    public String getTimestampLabelString(){
        String s ;

        LocalDateTime timestamp , now = LocalDateTime.now();
        timestamp = model.getTimestamp();
        if ( timestamp == null)
            return s= "NO INFO";
        long diff;
        diff = now.toEpochSecond(ZoneOffset.UTC)- timestamp.toEpochSecond(ZoneOffset.UTC);
        if (diff/3600 < 1){
            s = (int)diff/60 +"m ago";
        }
        else if( diff/3600 < 24){
            s = timestamp.getHour() + ":"+ timestamp.getMinute() ;
        }
        else if ( diff/3600 < 48)
            s= "Yesterday";
        else
            s = timestamp.getDayOfMonth()+"/"+timestamp.getMonth()+"/"+timestamp.getYear();
        return s;
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        //System.out.println("Paintting background");
        Graphics2D gg = (Graphics2D)g.create();
        gg.setColor(bgColor);
        int x, y , aw, ah , bw, bh;
        x = (int)(gg.getClipBounds().getX());
        y = (int)(gg.getClipBounds().getY());
        aw = (int)(gg.getClipBounds().getWidth());
        ah = (int)(gg.getClipBounds().getHeight());
        bw = this.getButtonWidth();
        bh = this.getButtonHeight();
        System.out.println(g.getClipBounds());
        gg.fillRect(x,y,aw,ah);
        RoundedIcon ricon = new RoundedIcon(this.model.getIcon());
        ricon.setLength((int)(0.70 * this.getButtonHeight()));
        ricon.paintIcon(this,gg,x+ (int)(0.1*bh),y+ (int)(0.15*bh));
        gg.dispose();
    }

    @Override
    protected void paintChildren(Graphics g) {
        Graphics gg = g.create();
        int x, y , w, h;
        x = (int)g.getClipBounds().getX() + this.getInsets().left;
        y = (int)g.getClipBounds().getY() + this.getInsets().top;
        w = (int)g.getClipBounds().getWidth() - ( this.getInsets().left + this.getInsets().right);
        h = (int)g.getClipBounds().getHeight() - (this.getInsets().top + this.getInsets().bottom);
        gg.setClip(x,y,w,h);
        // Drawing MovableStringLabel
        System.out.println("drawing Movalble string label");
        super.paintChildren(gg);
        //userNameLabel.paint(gg);
    }
}
