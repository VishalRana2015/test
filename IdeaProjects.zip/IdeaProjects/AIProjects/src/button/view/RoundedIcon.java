package button.view;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;


public class RoundedIcon extends ImageIcon{
    int length , roundedArcLength;
    static ImageIcon defaultIcon ;
    static {
        defaultIcon = new ImageIcon("C:\\Users\\RANA1947\\IdeaProjects\\AIProjects\\Images\\dui.png");
    }
    ImageIcon icon;
    public RoundedIcon(ImageIcon icon){
        super();
        this.icon = icon;
        this.roundedArcLength = 10;
    }

    public void setRoundedArcLength(int roundedArcLength) {
        this.roundedArcLength = roundedArcLength;
    }

    public int getRoundedArcLength() {
        return roundedArcLength;
    }

    public ImageIcon getIcon() {
        if ( icon == null)
            return defaultIcon;
        return icon;
    }

    public void setIcon(ImageIcon icon) {
        this.icon = icon;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public int getLength() {
        return length;
    }

    @Override
    public synchronized void paintIcon(Component c, Graphics g, int x, int y) {
        Graphics2D gg = (Graphics2D)g.create();
        System.out.println("this.getRoundedArcLength :"+ this.getRoundedArcLength());
        RoundRectangle2D.Double roundrect = new RoundRectangle2D.Double(x,y,this.getLength(),this.getLength(),this.getRoundedArcLength(),this.getRoundedArcLength());
        gg.setClip(roundrect);
        gg.drawImage(this.getIcon().getImage(),x,y,x+this.getLength(),y+this.getLength(),0,0,this.getIcon().getIconWidth(),this.getIcon().getIconHeight(),null);
        System.out.println("After Drawing image");
        gg.setClip(g.getClip());
        gg.setColor( c.getBackground());
        gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        gg.setStroke(new BasicStroke(3,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
        gg.draw( roundrect);
        gg.dispose();
    }
}
