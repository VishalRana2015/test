package button.view;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Ellipse2D;
import java.time.LocalDateTime;
import java.time.*;
import button.model.*;


public class test {
    public static void main(String[] args) {
        messageDemo();
    }
    public static void messageDemo(){
        JFrame frame = new JFrame("GridBagLayout Demo for constant empty space");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel = new JPanel ();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints cont = new GridBagConstraints();
        Component comp = Box.createHorizontalStrut(30);

        class MyComponent extends JTextArea{
            MyComponent(){

            }

            @Override
            public Dimension getMaximumSize() {
                return new Dimension(Integer.MAX_VALUE,Integer.MAX_VALUE);
            }

            @Override
            public Dimension getMinimumSize() {
                return new Dimension(100,100);
            }

            @Override
            public Dimension getPreferredSize() {
                return new Dimension(300,300);
            }

            @Override
            public void paint(Graphics g) {
                super.paint(g);
                int x, y , w, h;
                x = (int)g.getClipBounds().getX();
                y = (int)g.getClipBounds().getY();
                w= this.getWidth();
                h= this.getWidth();
                g.setColor(new Color(128,0,0));
                g.fillRoundRect(x,y,w,h,50,50);
            }
        }
        cont.gridx= 0;
        cont.gridy = 0;
        cont.anchor = GridBagConstraints.LINE_START;
        panel.add(Box.createHorizontalGlue(),cont);
        cont.gridx = 0;
        cont.gridy = 1;
        cont.gridwidth = 4;
        cont.gridheight = 1;
        cont.weightx =4;
        cont.weighty = 1;
        cont.anchor = GridBagConstraints.LINE_END;
        JTextArea area = new JTextArea();
        area.setText("I konow that. Life is a drama and you have to be a good actor.Before you arrived I had had tes.");
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        panel.add(area,cont);
        frame.setContentPane(panel);
        frame.setVisible(true);
    }
    public static void drawPendingMessage(){
        JFrame frame = new JFrame("drawPendingMessage Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocation(50,0);
        frame.setSize(500,500);
        class MyPanel extends JPanel{
            int radius;
            String text;

            public void setRadius(int radius) {
                this.radius = radius;
            }

            public int getRadius() {
                return radius;
            }

            public void setText(String text) {
                this.text = text;
            }

            public String getText() {
                return text;
            }

            @Override
            public void paint(Graphics g) {
                super.paint(g);
                paintStringInCircle(g);
            }
            public void paintStringInCircle(Graphics g){
                int x, y , w, h;
                x = (int)g.getClipBounds().getX() - this.getInsets().left;
                y = (int)g.getClipBounds().getY() - this.getInsets().top;
                w = (int)g.getClipBounds().getWidth() - (this.getInsets().left + this.getInsets().right);
                h = (int)g.getClipBounds().getHeight() - (this.getInsets().top + this.getInsets().bottom);
                int cx, cy ,r, minl;
                if ( w < h)
                    minl = w;
                else
                    minl = h;

                r = minl/2;
                cx  = x+ w/2;
                cy = y + h/2;
                // This method is responsible for drawing the circle and text in that circle

                double fh, fw, rl ;
                double pd , l;
                boolean iwh = false;
                Font font;
                Graphics2D gg = (Graphics2D)g.create();
                gg.setColor(new Color(0,128,0));
                gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                gg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                gg.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
                Shape circle = new Ellipse2D.Double(cx-r,cy-r,(r)*2,(r)*2);
                gg.fill(circle);

                fh= gg.getFont().getSize();
                fw= gg.getFontMetrics(gg.getFont()).stringWidth(this.getText());
                if ( fh < fw){
                    l = fw;
                    pd = fh/2;
                    iwh = false;
                }
                else{
                    l= fh;
                    pd = fw/2;
                    iwh = true;
                }

                rl = (2* r* Math.cos( Math.atan(2*pd/l)));

                if ( iwh){
                    font =new Font(Font.SANS_SERIF,Font.PLAIN,(int)rl);
                    gg.setFont(font);
                    fw = gg.getFontMetrics(gg.getFont()).stringWidth(this.getText());
                }
                else{
                    fh = (int)(fh/(double)fw * rl);
                    font = new Font(Font.SANS_SERIF,Font.PLAIN,(int)fh);
                    gg.setFont(font);
                    fw =gg.getFontMetrics(gg.getFont()).stringWidth(this.getText());
                }
                int sx, sy;
                sx = (int)(cx - fw/2 );
                sy = cy + gg.getFontMetrics(gg.getFont()).getAscent()/2 - gg.getFontMetrics(gg.getFont()).getDescent()/2;
                gg.setColor(Color.WHITE);
                gg.drawString(this.getText(),sx,sy);
                gg.dispose();

            }

        }
        MyPanel panel = new MyPanel();
        panel.setText("dy");
        frame.setContentPane(panel);

        frame.setVisible(true);
    }
    public static void JSeparatorTest(){
        JFrame frame = new JFrame("JSeparator Test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel = new JPanel();
        JSeparator separator = new JSeparator(JSeparator.VERTICAL);
       // panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
        panel.add(new JButton("Hello world"));
        panel.add(separator);
        System.out.println(separator.getBounds());
        panel.add(new JLabel("Hello world 2"));
        panel.add(new JSeparator(JSeparator.VERTICAL));
        panel.add(new JLabel("This is label."));
        frame.setContentPane(panel);
        frame.setVisible(true);
        System.out.println("separator.getBounds()" + separator.getBounds());
    }
    public static  void movableStringDemo(){
        class MyComponent extends JComponent{
            MovableStringLabel label ;
            public MyComponent(String text){
                label = new MovableStringLabel(text);
            }
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                System.out.println("g clip area :"+ g.getClipBounds());
            }

            @Override
            protected void paintChildren(Graphics g) {
                super.paintChildren(g);
                int x, y , w, h;
            }
        }
        JFrame frame= new JFrame("Movalble string Demo");
        frame.setLocation(50,0);
        frame.setSize(50,100);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel();
        MovableStringLabel label = new MovableStringLabel("hello brother what are you these days. Are you goint to tell me or not?");
        panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
        panel.add(label);
        frame.setContentPane(panel);
        frame.setVisible(true);
    }
    public static void buttontest3(){
        JFrame frame = new JFrame("button paintedIcon");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel  = new JPanel();

        VButton button = new VButton("My Name is Vishal Singh rana", "ranavishal2015@gmail.com",null);
        button.getModel().setLastMessage("Hello vishal how are you doing these days. If you need any help you can directly call me at this number.");
        button.setButtonWidth(300);
        panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
        panel.add(button);

        frame.setContentPane(panel);
        frame.setVisible(true);
    }
    public static void buttontest2(){

        LocalDate date = LocalDate.of(2020,6,19);
        LocalTime time = LocalTime.of(18,33,33,0);
        LocalDateTime datetime = LocalDateTime.of(date,time);
        //model.setTimestamp(datetime);
        ///VButton button = new VButton(model);
        //button.model =model;
        //System.out.println(button.getTimestampLabelString());
    }
    public static void textAreaTest(){
        JFrame frame = new JFrame("Text area in Box Layout");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel = new JPanel();
        JTextArea area = new JTextArea();
        area.setText("Flamingos are wading birdds famous for their bright pink feathers, stilt-like legs, and S-shaped neck. "+
                "Considering that the flamingo dips its beak into water to catch food, the beak has a series of plates that help sift the food"
    +" sourced.in essence, the beak acts like a filter. Flamingos eat plankton (which are tiny water plants and creatures that float on water,"
        +" such as algae) and small crustaceans. Chemicals in the plankton turn the flamingo's feathers pink."+
                " Flamingos 'run' on water, thanks to their webbed feet, to gain speed before lifting up into the sky." +
                " Flamingos fly and feed in large flocks of hundreds of birds."+
                " Flamingos build nests that look like mounds of mud along waterwas. At the top of the mound, in a shallow hole, the female lays one egg."+
                " Flamingo babies are born grey or white, and turn pink as they grow older. Greater flamingos are the world's tallest"+
                " species of flamingos. The have pale feathers and pink bills. Lesser flamingos are the smallest and most common.");
        area.setEditable(false);
        area.setWrapStyleWord(true);
        area.setLineWrap(true);
        panel.add(Box.createHorizontalStrut(100));
        panel.add(area);
        panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));

        frame.setContentPane(panel);
        frame.setVisible(true);
    }
    public static void buttonTest(){

    }
    public static void dispatchEventTest(){
        JFrame frame= new JFrame("Dispatch Event Test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(new Dimension(500,500));
        frame.setLocation(50,0);
        JPanel panel = new JPanel();

        class MyButton extends JButton{
            MyButton(String test){
                super(test);
            }
        }
        MyButton button = new MyButton("Hello world ");
        MyButton button2 = new MyButton("dispatchEvent here");
        JLabel label = new JLabel("This is normal label click here how does it receives event.");
        panel.add(button);
        panel.add(button2);
        panel.add(label);

        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("ActionEvent occurred on the button2");
            }
        });
        button2.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.out.println("MouseEvent occurred on button2 at x,y :"+ e.getX()+ ","+ e.getY());
                System.out.println("Source :"+ e.getSource());
                Component parent = (Component)((Component)e.getSource()).getParent();
                int x , y;
                Point parentPoint = SwingUtilities.convertPoint((Component)e.getSource(),new Point(e.getX(),e.getY()),parent);
                System.out.println("Parent Point :"+parentPoint);
                System.out.println("Deepest Component :"+SwingUtilities.getDeepestComponentAt(parent,e.getX(),e.getY()));
                if ( parent != null){
                    MouseEvent ee = new MouseEvent(parent,e.getID(),e.getWhen(),e.getModifiers(),(int)parentPoint.getX(),(int)parentPoint.getY(),e.getClickCount(),e.isPopupTrigger());
                    parent.dispatchEvent(ee);
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
        panel.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.out.println("Panel mouse Clicked event occurred. at x,y:"+ e.getX() + ","+e.getY());
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
        frame.setContentPane(panel);
        frame.setVisible(true);
    }

}

