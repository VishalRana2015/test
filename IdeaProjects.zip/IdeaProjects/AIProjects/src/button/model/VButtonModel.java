package button.model;
import button.view.RoundedIcon;

import java.time.LocalDateTime;
import java.util.*;
import javax.swing.*;
import java.awt.event.*;
import button.view.*;
public class VButtonModel {
    private VButton parent;
    String userName;
    String userID;
    String lastMessage;
    int pendingMessage;
    LocalDateTime timestamp;
    ImageIcon icon;
    Vector<ActionListener> actionListeners;

    public VButtonModel(String userName, String useID,ImageIcon icon, VButton parent){
        this.parent = parent;
        this.icon = icon;
        this.userName = userName;
        this.userID = userID;
        pendingMessage = 0;
        this.lastMessage = "";
        parent = null;
    }

    public VButton getParent() {
        return parent;
    }


    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setLastMessage(String lastMessage) {
        this.lastMessage = lastMessage;
        if ( parent != null){
            parent.repaint();
        }
    }

    public void setIcon(ImageIcon icon) {
        this.icon = icon;
        if ( parent != null){
            parent.repaint();
        }
    }

    public void setPendingMessage(int pendingMessage) {
        this.pendingMessage = pendingMessage;
        if ( parent != null){
            parent.repaint();
        }
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
        if ( parent != null){
            parent.repaint();
        }
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public ImageIcon getIcon() {
        return icon;
    }

    public int getPendingMessage() {
        return pendingMessage;
    }

    public String getLastMessage() {
        return lastMessage;
    }

    public String getUserID() {
        return userID;
    }

    public String getUserName() {
        return userName;
    }
}
