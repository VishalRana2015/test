package textfield;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;
import java.util.*;
public class VTextField  extends JTextField{
    String backgroundText;
    public VTextField(String backgroundText){
        super();
        this.backgroundText = backgroundText;
    }
    public static void main(String[] args) {
        JFrame frame =new JFrame("VTextField Deom");
        frame.setSize(500,500);
        frame.setLocation(50,0);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel();
        VTextField field = new VTextField("Search...");
        panel.add(field);
        field.setColumns(20);
        frame.setContentPane(panel);
        frame.setVisible(true);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
     //   System.out.println("paint component method called");
        if ( "".equalsIgnoreCase(this.getText()) ) {
            Graphics2D gg = (Graphics2D) g.create();
            gg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            gg.setColor(Color.GRAY);
            int sw , sx, sy ;
            gg.setFont(this.getFont());
            sw  = gg.getFontMetrics(gg.getFont()).stringWidth("");
            sx = this.getInsets().left + sw;
            sy = this.getInsets().top + this.getFontMetrics(gg.getFont()).getAscent();
            gg.drawString(this.backgroundText,sx,sy);
            gg.dispose();
        }

    }



}
