package textfield;
import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
public class VTextArea extends JTextArea{
    String emptyString;
    public VTextArea (String emptyString){
        this.emptyString = emptyString;
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("VTextArea Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel = new JPanel();
        VTextArea area = new VTextArea("Type your Message Here");
        area.setColumns(30);
        area.setRows(1);
        //area.setText("hello world");
        panel.add(area);
        frame.setContentPane(panel);
        frame.setVisible(true);
    }
    @Override
    public void paint(Graphics g) {

        super.paint(g);
        Graphics2D gg = (Graphics2D)g.create();
        int x, y , w, h;
        x= (int)g.getClipBounds().getX() - this.getInsets().left;
        y = (int)g.getClipBounds().getY() - this.getInsets().top;
        w = (int)g.getClipBounds().getWidth() - (this.getInsets().left + this.getInsets().right);
        h = (int)g.getClipBounds().getHeight() - (this.getInsets().top + this.getInsets().bottom);
        gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        gg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        gg.setColor(Color.GRAY);
        if ( this.getText().equalsIgnoreCase(""))
            gg.drawString(this.emptyString,x+this.getFontMetrics(this.getFont()).stringWidth("  "),y+this.getFont().getSize());

    }
}
