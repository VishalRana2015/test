package textfield;

import javax.swing.*;
import java.awt.*;

public class VPassword extends JPasswordField {
    String s;
    public VPassword(String s){
        super();
        this.s  =s;
    }
    public VPassword(){
        super();
        this.s = "Password";
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // if this component is empty then print the string in grey color
        if ( "".equalsIgnoreCase(new String(this.getPassword())) ) {
            Graphics2D gg = (Graphics2D) g.create();
            gg.setColor(Color.GRAY);
            gg.setFont(this.getFont());
            int sw = gg.getFontMetrics(gg.getFont()).stringWidth("");
            int sx, sy; // location of the string from where it should start printing the string
            sx = this.getInsets().left + sw;
            sy = this.getInsets().top + gg.getFontMetrics(gg.getFont()).getAscent() + 1;
            gg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            gg.drawString(this.s, sx, sy);
        }
    }
}
