import javax.swing.*;
import java.awt.*;
import javax.swing.border.Border;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;

public class MyImageFilterGiFDemo {
    private static JLabel label1;
    private static JLabel label2;
    public static void main(String[] args) {
        JFrame frame =new JFrame("My Image Filter Demo GIF");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(0,0);
        JPanel panel = new JPanel();
        ImageIcon icon = new ImageIcon("C:\\Users\\RANA1947\\Desktop\\gif2.gif");
        MyImageFilter filter = new MyImageFilter();
        Image image = Toolkit.getDefaultToolkit().createImage(new FilteredImageSource(icon.getImage().getSource(),filter));
        MediaTracker tracker  = new MediaTracker(label1);
        tracker.addImage(image,1);
        try{
            tracker.waitForID(1);
        }
        catch(Exception e){
            System.out.println("Exception caught :"+ e.getMessage());
        }

        label1 = new JLabel();
        label1.setBorder( BorderFactory.createLineBorder(Color.BLACK));
        ImageIcon icon2 = new ImageIcon(image);
        MyComponent comp = new MyComponent(icon.getImage(), 200,200);
        comp.setBorder(BorderFactory.createLineBorder(Color.ORANGE));
        label1.setIcon(icon2);
        panel.setBackground( Color.ORANGE);
        panel.add(new JLabel("Hello world"));
        panel.add(new JLabel("My name is vSiahl rana."));
        panel.setOpaque(true);
        frame.setContentPane(panel);
        JRootPane rootpane = frame.getRootPane();
        rootpane.setVisible(true);
        JPanel c  =(JPanel)frame.getGlassPane();

        c.setBackground( new Color(120,120,120,100));
        c.setOpaque(false);
        c.add(comp);
        c.setVisible(true);
        //rootpane.setOpaque(false);
        rootpane.setBackground( new Color(120,120,120,100));
        //rootpane.add( comp);
        //rootpane.setLayout(null);
        int cw, ch ;
        cw = comp.getWidth();
        ch = comp.getHeight();

        comp.setLocation(500/2-cw/2,500/2-ch/2);
        frame.setVisible(true);
    }
    private static class MyComponent extends JComponent{
        Image image ;
        int iw , ih;
        MyImageObserver observer ;
        public MyComponent( Image image, int iw, int ih){
            this.image = image;
            this.iw  = iw;
            this.ih= ih;
            this.setOpaque(false);
            observer = new MyImageObserver(this);
            this.setSize(iw,ih);
            this.setPreferredSize(new Dimension(iw,ih));
        }

        @Override
        protected void paintComponent(Graphics g) {

            super.paintComponent(g);
            int x, y , w,h;
            x = this.getInsets().left;
            y = this.getInsets().right;
            Graphics2D gg = (Graphics2D)g.create();
            gg.setColor(new Color(0,0,0,0));
            //gg.fillRect(x,y,this.getWidth(),this.getHeight());

            iw = image.getWidth(null);
            ih= image.getHeight(null);
            int cw, ch;
            cw = this.getWidth();
            ch = this.getHeight();
            if ( iw < cw && ih < ch)
            gg.drawImage(this.image,cw/2-iw/2,ch/2-ih/2,iw,ih,observer);
            else
                gg.drawImage(this.image, 0,0,cw,ch,observer);
           // System.out.println(Thread.currentThread().getName());
        }

        private static class MyImageObserver implements ImageObserver {
            MyComponent comp;
            public MyImageObserver(MyComponent comp){
                this.comp = comp;
            }
            @Override
            public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {
                //System.out.println("ImageObserver thread : " + Thread.currentThread().getName());
                comp.repaint();
                return true;
            }
        }
    }

    private static class MyImageFilter extends ImageFilter{
        int savedWidth , savedHeight;
        int[] savedPixels;
        boolean isbyte = false;
        ColorModel model;
        @Override
        public void setDimensions(int width, int height) {
            consumer.setDimensions(width, height);
            savedWidth = width;
            savedHeight = height;
            savedPixels = new int[savedHeight * savedWidth];
        }

        @Override
        public void setPixels(int x, int y, int w, int h, ColorModel model, byte[] pixels, int off, int scansize) {
            //consumer.setPixels(x, y, w, h, model, pixels, off, scansize);
            isbyte = true;
            //System.out.println("Byte medhot used");
            int row, col;
            for (int r = 0; r < h; r++){
                row = r + y;
                for ( int c = 0; c < w ; c++){
                    col = c + x;
                    if ( isWhite((IndexColorModel)this.model,pixels[r*scansize + c] ,70))
                        pixels[r*scansize + c] = -1;
                    savedPixels[row*savedWidth + col] = pixels[r*scansize +c ];
                }
            }
        }

        private boolean isWhite( IndexColorModel model, int value , int radius){
            Color color ;
            color = new Color( model.getRed(value) , model.getGreen(value) , model.getBlue(value) , model.getAlpha(value));
            int diff , max, min;
            max = Math.max( model.getRed(value) , Math.max(model.getGreen(value) , model.getBlue(value)));
            min = Math.min( model.getRed(value) , Math.min(model.getGreen(value), model.getBlue(value)));
            diff = max - min;
            if ( diff < radius)
                return true;
            return false;
        }

        @Override
        public void setProperties(Hashtable<?, ?> props) {
            consumer.setProperties(props);
        }

        @Override
        public void setHints(int hints) {
            consumer.setHints(hints);
        }

        @Override
        public void setColorModel(ColorModel model) {
            consumer.setColorModel(model);
            System.out.println("model :" + model);
            this.model = model;
            if ( model instanceof  IndexColorModel){
                IndexColorModel imodel  = (IndexColorModel) model;
                System.out.println("Component Size :"+ imodel.getComponentSize());
                System.out.println("size :"+ imodel.getMapSize());
                int size = imodel.getMapSize();
                for ( int i =0; i < size; i++){
                    Color color = new Color( imodel.getRed(i) , imodel.getGreen(i), imodel.getBlue(i) , imodel.getAlpha(i));
                    //System.out.println("color["+i+"] : "+ color + " , alpha : "+ color.getAlpha());

                }
                System.out.println("white : "+ Color.WHITE );
                int i;
                System.out.println("Transparent Pixel: "+ ( i = imodel.getTransparentPixel()));
                System.out.println("(red,green,blue) for transparent pixel : ("+ imodel.getRed(i) + ","+ imodel.getGreen(i) + ", "+ imodel.getBlue(i) + ")");

            }
        }

        @Override
        public void setPixels(int x, int y, int w, int h, ColorModel model, int[] pixels, int off, int scansize) {
            //consumer.setPixels(x, y, w, h, model, pixels, off, scansize);
            //System.out.println("Integer method used");
            int row, col;
            for (int r = 0; r < h; r++){
                row = r + y;
                for ( int c = 0; c < w ; c++){
                    col = c + x;
                    savedPixels[row*savedWidth + col ] = pixels[r*scansize +c + off ];
                }
            }

        }

        @Override
        public void imageComplete(int status) {
            super.imageComplete(status);

            if ( (status & ImageFilter.STATICIMAGEDONE) != 0) {
                //System.out.println("StaticimageDone");
                int[] temp = new int[savedWidth];
                for (int r = 0; r < savedHeight; r++) {
                    for (int c = 0; c < savedWidth; c++) {
                        temp[c] = savedPixels[r * savedWidth + c];
                     //   System.out.println(temp[c]);
                    }
                    if ( isbyte) {
                        byte[] byteArray = new byte[savedWidth];
                        for (int c =0; c< savedWidth; c++)
                            byteArray[c] = (byte)(temp[c] & 0xff);
                        consumer.setPixels(0, r, savedWidth, 1, this.model, byteArray, 0, savedWidth);
                    }
                    else
                        consumer.setPixels(0,r,savedWidth, 1, this.model, temp, 0, savedWidth);
                }
                consumer.imageComplete(status);
            }
            if ( (status & ImageFilter.SINGLEFRAMEDONE) != 0) {
                int[] temp = new int[savedWidth];
                for (int r = 0; r < savedHeight; r++) {
                    for (int c = 0; c < savedWidth; c++) {
                        temp[c] = savedPixels[r * savedWidth + c];
                    }
                    if ( isbyte) {
                        byte[] byteArray = new byte[savedWidth];
                        for (int c =0; c< savedWidth; c++)
                            byteArray[c] = (byte)(temp[c] & 0xff);
                        consumer.setPixels(0, r, savedWidth, 1, this.model, byteArray, 0, savedWidth);
                    }
                    else
                        consumer.setPixels(0,r,savedWidth, 1, this.model, temp, 0, savedWidth);
                    }
                }
            consumer.imageComplete(status);
        }
    }
}

