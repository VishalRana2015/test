import textfield.VTextArea;

import javax.swing.*;
import java.awt.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Panel2 extends JPanel {
    String userID ; // the receipient id
    String sernderID ; // senderID;
    Vector temporary ;
    JScrollPane pane = new JScrollPane();
    JPanel messagePanel = new JPanel();
    JPanel bottomPanel ;
    public Panel2(){
        super();
            this.setLayout( new BoxLayout(this, BoxLayout.Y_AXIS));
            intialize();
    }
    private void intialize(){
        JLabel label = new JLabel();
        label.setBorder( BorderFactory.createLineBorder(Color.BLACK));
        label.setIcon( new ImageIcon("C:\\Users\\RANA1947\\Desktop\\rightarrow.png"));
        JButton chooseFile = new JButton("Send File");
        JButton send = new JButton("Send");
        VTextArea area = new VTextArea("Type your message here.");
        area.setRows(2);
        bottomPanel =new JPanel();
        bottomPanel.setLayout( new BoxLayout( bottomPanel,BoxLayout.X_AXIS));
        bottomPanel.add(area);
        bottomPanel.add(chooseFile);
        bottomPanel.add(send);
        bottomPanel.setMinimumSize(bottomPanel.getPreferredSize());
        bottomPanel.setMaximumSize(new Dimension ( Integer.MAX_VALUE ,  (int)bottomPanel.getPreferredSize().getHeight()  ) ) ;
        // bottomPanel has been initialized
        JViewport viewport = new JViewport();
        viewport.setView( messagePanel);
        pane.setViewport ( viewport);
        messagePanel.add( new JLabel("This is message Panel"));

        this.setLayout( new BoxLayout(this,BoxLayout.Y_AXIS));
        pane.setMaximumSize( new Dimension( Integer.MAX_VALUE, Integer.MAX_VALUE));
        pane.setMinimumSize( pane.getPreferredSize());

        this.add( pane);
        this.add(bottomPanel);

        // adding listener to the send button
        chooseFile .addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
                int val = chooser.showDialog((JComponent)e.getSource(),"Send");
                System.out.println("val : " + val);
                if ( val == JFileChooser.APPROVE_OPTION){
                    // do the action
                }
            }
        });

        send.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // do the action
            }
        });
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserID() {
        return userID;
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Panel 2 ");
        frame.setSize( 500, 500);
        frame.setLocation( 50, 0);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Panel2 panel = new Panel2();
        frame.setContentPane(panel);
        frame.setVisible(true);
    }

}