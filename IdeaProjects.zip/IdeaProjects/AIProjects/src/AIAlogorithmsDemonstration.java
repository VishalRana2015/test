import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.*;
public class AIAlogorithmsDemonstration {

    static class ShowPanel extends JPanel{
        Vector<Point> obstacles ;
        Point source, destination;
        int linewidth =3 , gridlength = 10;


        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D gg = (Graphics2D) g.create();
            int x, y , w, h;
            x = (int)g.getClipBounds().getX();
            y = (int)gg.getClipBounds().getY();
            w = (int)gg.getClipBounds().getWidth();
            h = (int)gg.getClipBounds().getHeight();
            System.out.println("clip Bounds :"+ gg.getClipBounds());
            gg.translate(x,y+h);
            AffineTransform af = new AffineTransform(1,0,0,-1,0,0);
            gg.transform( af);

            // drawing Vertical Lines
            int vl , hl;
            vl = w / gridlength;
            int lx , ly;

            gg.setStroke(new BasicStroke(linewidth,BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER,2));
            for ( int i =0; i <= vl; i++){
                lx = i*gridlength;
                gg.drawLine(lx,y,lx,y+h);
            }
            // drawing horizontal lines
            hl = h/ gridlength;
            for ( int j =0; j < hl ; j++){
                ly = j*gridlength;
                gg.drawLine(x,ly,x+w,ly);
            }
            Font font = new Font(Font.SANS_SERIF,Font.BOLD,30);
            gg.setFont(font);
            gg.setColor(Color.RED);
            // paste your code here to draw obstacles and sorce and destination
        }

    }
    static public JPanel colorPanel(){
        JPanel panel = new JPanel();
        panel.setBorder( BorderFactory.createTitledBorder(new LineBorder(Color.BLACK,2),"Set Color Properties for Grid City."));
        panel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        JLabel slabel = new JLabel("Set Source Color");
        JLabel dlabel = new JLabel("Set Destination Color");
        JLabel nlabel = new JLabel("Set Open list Color");
        JLabel clabel = new JLabel("Set ClosedList Color");
        JLabel olabel = new JLabel("Set Obstables Color");



        JButton sbutton = new JButton("    ");
        JButton dbutton = new JButton("    ");
        JButton nbutton = new JButton("    ");
        JButton cbutton = new JButton("    ");
        JButton obutton = new JButton("    ");
        sbutton.setMinimumSize(new Dimension(40,20));
        dbutton.setMinimumSize(new Dimension(40,20));
        nbutton.setMinimumSize(new Dimension(40,20));
        cbutton.setMinimumSize(new Dimension(40,20));
        obutton.setMinimumSize(new Dimension(40,20));
        sbutton.setMaximumSize(new Dimension(40,20));
        dbutton.setMaximumSize(new Dimension(40,20));
        nbutton.setMaximumSize(new Dimension(40,20));
        cbutton.setMaximumSize(new Dimension(40,20));
        obutton.setMaximumSize(new Dimension(40,20));
        sbutton.setPreferredSize(new Dimension(40,20));
        dbutton.setPreferredSize(new Dimension(40,20));
        nbutton.setPreferredSize(new Dimension(40,20));
        cbutton.setPreferredSize(new Dimension(40,20));
        obutton.setPreferredSize(new Dimension(40,20));
        c.insets = new Insets(5,5,5,5);
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 1;
        c.gridheight = 1;
        panel.add(slabel,c);
        c.gridy = 1;
        panel.add(dlabel,c);
        c.gridy = 2;
        panel.add(nlabel,c);
        c.gridy=3;
        panel.add(clabel,c);
        c.gridy =4;
        panel.add(olabel,c);

        c.gridx = 1;
        c.gridy =0;
        panel.add(sbutton,c);
        c.gridy =1;
        panel.add(dbutton,c);
        c.gridy = 2;
        panel.add(nbutton,c);
        c.gridy = 3;
        panel.add(cbutton,c);
        c.gridy = 4;
        panel.add(obutton,c);
        return panel;


    }
    static public JPanel makeControlPanel(){
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new GridBagLayout());
        JLabel labelgridlength = new JLabel("Set GridLength :");
        GridBagConstraints cont = new GridBagConstraints();

        Font font = new Font(Font.SANS_SERIF,Font.BOLD,11);

        cont.gridx = 0;
        cont.gridy= 1;
        cont.insets = new Insets( 5,5,5,5);

        controlPanel.add(labelgridlength,cont);
        JSpinner spinner = new JSpinner();
        SpinnerNumberModel model = new SpinnerNumberModel(10,10,40,2);
        spinner.setModel(model);
        cont.gridx = 1;
        cont.gridy = 1;
        controlPanel.add(spinner,cont);
        CustomRadioButton setobs = new CustomRadioButton("Set Obstacles");
        CustomRadioButton setSource = new CustomRadioButton("Set Source");
        CustomRadioButton setDest = new CustomRadioButton("Set Destination");
        JButton cb = new JButton("Enable");
        cb.addActionListener ( new ActionListener(){
            boolean enabled = false;
            @Override
            public void actionPerformed(ActionEvent e){
                JButton button = (JButton)e.getSource();
                if ( enabled){
                    enabled = false;
                    setobs.setEnabled(false);
                    setSource.setEnabled(enabled);
                    setDest.setEnabled(enabled);
                    button.setText("Enable");
                }
                else{
                    enabled = true;
                    setobs.setEnabled(enabled);
                    setSource.setEnabled(enabled);
                    setDest.setEnabled(enabled);
                    button.setText("Done");
                }
            }
        });

        cont.gridx =0;
        cont.gridy = 2;
        controlPanel.add(setobs,cont);
        cont.gridx = 1;
        controlPanel.add(setSource,cont);
        cont.gridx =2;
        controlPanel.add(setDest,cont);
        cont.gridx =3;
        setobs.setEnabled(false);
        setSource.setEnabled(false);
        setDest.setEnabled(false);
        controlPanel.add(cb,cont);
        ButtonGroup bg = new ButtonGroup();
        bg.add(setobs);
        bg.add(setSource);
        bg.add(setDest);
        JLabel algolabel = new JLabel("Select Algorithm");
        cont.gridx = 0;
        cont.gridy = 3;
        controlPanel.add(algolabel,cont);
        JComboBox<String> algocombo = new JComboBox<String>();
        algocombo.addItem("Heuristic Search");
        algocombo.addItem("A* search ");
        algocombo.addItem("AO* serach");
        algocombo.addItem("Breadth First Search");
        algocombo.addItem("Depth first search");
        cont.gridx=1;
        cont.gridy = 3;

        controlPanel.add(algocombo,cont);



        JPanel colorPanel = colorPanel();
        cont.gridx = 0;
        cont.gridy = 4;
        cont.gridwidth = 4;
        cont.gridheight = 1;
        controlPanel.add(colorPanel,cont);


        JButton start = new JButton("Start Demonstrating");
        cont.gridx = 0;
        cont.gridy = 5;
        cont.gridwidth = 4;
        cont.gridheight =1;
        cont.anchor = GridBagConstraints.CENTER;
        cont.fill = GridBagConstraints.NONE;
        controlPanel.add(start,cont);



        JPanel panel = new JPanel();
        panel.setBorder( BorderFactory.createTitledBorder(new LineBorder(Color.BLACK,2)));
        JPanel showpanel = new ShowPanel();
        panel.setLayout(new GridBagLayout());


        cont.gridx = 0;
        cont.gridy =0;
        cont.gridwidth = 1;
        cont.gridheight =1;
        cont.weighty =2;
        cont.weightx = 2;
        cont.fill  = GridBagConstraints.BOTH;
        cont.anchor = GridBagConstraints.CENTER;
        panel.add(showpanel,cont);
        cont.gridwidth = 4;
        cont.gridheight  =1;

        cont.weighty = 2;
        cont.weightx = 2;
        controlPanel.add(panel,cont);
        return controlPanel;
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("AI alogorithms Demostration ");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize( 700,700);
        frame.setLocation(50,0);
        JPanel panel = makeControlPanel();
        frame.setContentPane(panel);
        frame.setVisible(true);

    }
    static class CustomRadioButton extends JRadioButton implements MouseListener , ItemListener {
        @Override
        public void itemStateChanged(ItemEvent e) {
            setColor();
            repaint();
        }

        Color bgcolor, fgcolor;
        boolean ishover;
        public void setHover( boolean ishover){
            this.ishover = ishover;
            setColor();
            repaint();
        }
        public boolean isHover(){
            return ishover;
        }

        private void setColor(){
            if ( this.isEnabled()) {
                if ( this.ishover) {
                    if (this.isSelected()) {
                        bgcolor = new Color(205, 255, 186);
                        fgcolor = new Color(109, 138, 97);
                    } else {
                        bgcolor = new Color(255, 181, 168);
                        fgcolor = new Color(172, 62, 75);
                    }
                }
                else{
                    if ( this.isSelected() ){
                        bgcolor = new Color( 0, 196,0);
                        fgcolor = new Color(255,255,255);
                    }
                    else{
                        bgcolor =new Color(214, 64, 61);
                        fgcolor =new Color(255,255,255);
                    }
                }
            }
            else{
                bgcolor = new Color(188, 180, 181);
                fgcolor = Color.WHITE;
            }
        }
        @Override
        public void mouseClicked(MouseEvent e) {
            repaint();
        }
        @Override
        public void mousePressed(MouseEvent e){

        }
        @Override
        public void mouseReleased(MouseEvent e){

        }
        @Override
        public void mouseEntered(MouseEvent e){
            setHover(true);

        }
        @Override
        public void mouseExited(MouseEvent e){
            setHover(false);
        }

        String text;
        public CustomRadioButton(String text){
            super(text);
            this.text = text;
            fgcolor = Color.WHITE;
            this.addMouseListener(this);
            this.addItemListener(this);
            this.setSelected(false);
            MouseEvent e = new MouseEvent(this,1,1,MouseEvent.NOBUTTON,0,0,0,false);
            mouseExited(e);
            this.setFocusPainted(false);
            this.setRolloverEnabled(false);
            this.setBorder(new EmptyBorder(0,0,0,0));
        }

        @Override
        public void setEnabled(boolean b) {
            super.setEnabled(b);
            setColor();
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D gg = (Graphics2D)g.create();
            int x, y , w, h;
            x = (int)gg.getClipBounds().getX();
            y =(int)gg.getClipBounds().getY();
            w  = (int)gg.getClipBounds().getWidth();
            h =(int)gg.getClipBounds().getHeight();
            gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING , RenderingHints.VALUE_ANTIALIAS_ON);
            x = x + this.getInsets().left;
            y  = y + this.getInsets().top;
            w = w - ( this.getInsets().left + this.getInsets().right);
            h = h- (this.getInsets().top + this.getInsets().bottom);
        //    System.out.println(" this.getInsets() : "+ this.getInsets());
          //  System.out.println("clip area : "+ gg.getClipBounds());
           // System.out.println( " x,y,w,h : "+ x+ ", "+ y + " , " + w+ " , " + h);
            gg.setColor(bgcolor);
            gg.fillRoundRect(x,y,w,h,30,30);

            int sx, sy ;
            sx = x + 10;
            sy = y + h/2 + gg.getFont().getSize()/2;
            gg.setColor(fgcolor);
            gg.drawString(text,sx,sy);
            //System.out.println("Paintint done . \n");

        }
    }
}
