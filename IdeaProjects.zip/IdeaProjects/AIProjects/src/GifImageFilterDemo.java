import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.*;

public class GifImageFilterDemo {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Gif Image Filter Demo");
        frame.setSize(1200,700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocation(0,0);
        JPanel panel  = new JPanel();
        String fileloc = "C:\\Users\\RANA1947\\Desktop\\LoadingGif2.gif";
        String filelocw = "F:\\All Downloads\\Documents\\gif.gif";
        String convo = "C:\\Users\\RANA1947\\Desktop\\convo.jpg";
        ImageIcon icon =new ImageIcon(convo);
        MyComponent comp  = new MyComponent(icon.getImage(),600,600);

        comp.setBorder( BorderFactory.createLineBorder(Color.BLACK));
        panel.add(comp);
        panel.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                panel.repaint();
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
        frame.setContentPane(panel);

        frame.setVisible(true);

    }

    private static class MyComponent extends JComponent{
        int cw, ch;
        Image image ;
        public MyComponent(Image image,  int cw, int ch){
            this.cw = cw;
            this.ch = ch;
            this.setSize(cw,ch);
            this.setPreferredSize(new Dimension(cw,ch));
            this.setMinimumSize(new Dimension(cw,ch));
            this.setMaximumSize(new Dimension(cw,ch));
            this.image = image;
            MyImageFilter filter = new MyImageFilter(cw,ch,Color.WHITE);
            this.image = createImage( new FilteredImageSource(image.getSource(),filter));
            MediaTracker tracker = new MediaTracker(this);
            tracker.addImage(this.image , 1);
            try{
                tracker.waitForID(1);
            }
            catch( Exception e){
                System.out.println("Exception caught :"+ e.getMessage());
            }
            System.out.println("Image Created");
            ImageIcon icon = new ImageIcon(this.image);
            JLabel label = new JLabel(icon);
            label.setSize( cw,ch);
            label.setLocation(0,0);
            this.add(label);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int x, y , w, h;
            x = this.getInsets().left;
            y = this.getInsets().top;
            w = this.getWidth() - (this.getInsets().left + this.getInsets().right);
            h = this.getHeight() - (this.getInsets().top + this.getInsets().bottom);
            Graphics2D gg = (Graphics2D)g.create();

        }
    }
    private static class MyObserver implements ImageObserver{
        @Override
        public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {
            System.out.println("Image update called");
            return true;
        }
    }
    private static class MyImageFilter extends  ImageFilter{
        Color transparentColor;
        int imageWidth , imageHeight , alpha;
        ColorModel model;
        int hints;
        public MyImageFilter(int imageWidth , int imageHeight, Color transparentColor){
            this.imageHeight = imageHeight;
            this.imageWidth = imageWidth;
            this.transparentColor = transparentColor;
        }
        public MyImageFilter ( int imageWidth, int imageHeight, Color transparentColor , int alpha) throws IllegalArgumentException{
            if ( alpha < 0 || alpha > 255)
                throw new IllegalArgumentException("alpha("+ alpha + ") not in the range(0,255)");
            this.imageWidth = imageWidth;
            this.imageHeight = imageHeight;
            this.transparentColor = transparentColor;
            this.alpha = alpha;
        }
        public MyImageFilter( Color transparentColor){
            this.imageWidth = 0;
            this.imageHeight =0;
            this.alpha  = 255;
            this.transparentColor = transparentColor;
        }
        public MyImageFilter( Color transparentColor, int alpha) throws  IllegalArgumentException{
            if ( alpha < 0 || alpha > 255)
                throw new IllegalArgumentException("alpha(\"+ alpha + \") not in the range(0,255)");
            this.imageWidth =0;
            this.imageHeight =0;
            this.transparentColor = transparentColor;
            this.alpha = alpha;
        }
        int savedWidth ,savedHeight;
        int[] savedPixels;
        @Override
        public void setDimensions(int width, int height) {
            //super.setDimensions(width, height);

            savedWidth = width;
            savedHeight = height;
            if ( imageWidth == 0 && imageHeight ==0){
                imageWidth = savedWidth;
                imageHeight = savedHeight;
            }
            consumer.setDimensions(imageWidth,imageHeight);
            savedPixels = new int[savedWidth * savedHeight];
        }

        @Override
        public void setPixels(int x, int y, int w, int h, ColorModel model, int[] pixels, int off, int scansize) {
            //super.setPixels(x, y, w, h, model, pixels, off, scansize);
            int row, column ;
            for ( int r = 0; r < h; r++){
                row = y + r;
                for ( int c = 0; c < w ; c++){
                    column = c + x;
                    savedPixels[row*savedWidth + column] = pixels[r*scansize + c];
                }
            }

        }

        @Override
        public void setColorModel(ColorModel model) {
            //super.setColorModel(model);
            this.model = model;
            consumer.setColorModel(model);
        }

        @Override
        public void setHints(int hints) {
            //super.setHints(hints);
            this.hints = hints;
            consumer.setHints(hints);
        }

        @Override
        public void setProperties(Hashtable<?, ?> props) {
            consumer.setProperties(props);
        }

        @Override
        public void setPixels(int x, int y, int w, int h, ColorModel model, byte[] pixels, int off, int scansize) {
            int row, column ;
            for ( int r = 0; r < h; r++){
                row = x + y;
                for ( int c = 0; c < w ; c++){
                    column = c + x;
                    savedPixels[row*savedWidth + column] = pixels[r*scansize + c];
                }
            }
        }

        @Override
        public void imageComplete(int status) {
            // This method is responsible for sending the image to the ultimate consumer.
            //super.imageComplete(status);
            if (  (( status & ImageFilter.SINGLEFRAMEDONE) | ( status & ImageFilter.STATICIMAGEDONE)) != 0 ){
                // one part of the image has been received by this imageFilter instance
                AreaAveragingScaleFilter filter = new AreaAveragingScaleFilter(imageWidth, imageHeight);
                MemoryImageSource mis = new MemoryImageSource(savedWidth, savedWidth,savedPixels,0,savedWidth);
                int[] newPixels  = new int[imageWidth * imageHeight];
                Image image = Toolkit.getDefaultToolkit().createImage(new FilteredImageSource(mis,filter));
                MediaTracker tracker = new MediaTracker(new JPanel());
                tracker.addImage(image,1);
                try{
                    tracker.waitForID(1);
                }catch( Exception e){
                    System.out.println("Exception caught :"+ e.getMessage());
                }
                Toolkit.getDefaultToolkit().prepareImage(image,imageWidth, imageHeight, new MyObserver());
                PixelGrabber grabber = new PixelGrabber( image ,0,0,imageWidth,imageHeight,newPixels,0,imageWidth);
                grabber = new PixelGrabber(image,0,0,imageWidth,imageHeight,false);

                try{
                   System.out.println(grabber.grabPixels());
                   newPixels = (int[])grabber.getPixels();
                }catch( Exception e){
                    System.out.println("Excpeption caught :"+ e.getMessage());
                }

                int[] temp;
                temp = new int[imageWidth];
                for ( int r =0; r < imageHeight; r++){
                    for (int c = 0; c< imageWidth ; c++) {
                        temp[c] = newPixels[r * imageWidth + c];
                        System.out.println("temp :" + temp[c]);
                    }
                    consumer.setPixels(0,r,imageWidth,1,this.model,temp,0,imageWidth);
                    //System.out.println("Sending "+ r + "th rectangle");
                }
                System.out.println("Image Complete done.");
                consumer.imageComplete(status);
            }
        }
    }
}
