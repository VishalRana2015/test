package practice;
import javax.swing.*;
import java.awt.*;
import java.awt.*;
import javax.swing.event.*;
import javax.swing.text.Utilities;
import java.awt.event.*;
public class TextAreaTest {
    public static void main(String[] args) throws Exception{
        JFrame frame= new JFrame("TextArea Test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(new Dimension(500,500));
        frame.setLocation(50,0);
        JPanel panel =new JPanel();
        //panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
        MyTextArea area2= new MyTextArea();
        area2.setText("What the fuck are you talking adfadfadfadfadfadfdfasdfasdfjkljladsfkajkasdklfjavjklvaoiiwfinanaklgaklgjaklsfj");
        MyTextArea area = new MyTextArea();
        System.out.println("text area font size :"+ area.getFont().getSize());
        area.setText("hello world");
        panel.add(area);
        panel.add(area2);
        frame.setContentPane(panel);
        frame.setVisible(true);
        System.out.println("area2 count :"+ area2.getLineCount());
        System.out.println("ares2 get Rows :"+ area2.getRows());
        System.out.println("getRowEnd :"+ Utilities.getRowEnd(area2,0));
    }
    static class MyTextArea extends JTextArea{
        public MyTextArea(){
            super();
            //this.setEditable(false);
            this.setLineWrap(true);
            this.setWrapStyleWord(true);
            this.setBackground(new Color(120,0,0));
            this.setForeground(new Color(0,0,0));
            this.setAlignmentX(1.0f);
            this.setOpaque(false);
        }


        @Override
        public void paint(Graphics g) {
            System.out.println("In paint method :");
            System.out.println("preferred Size :"+ this.getPreferredSize());
            System.out.println("this.getWidth :"+ this.getWidth()  + " this.getHeight() :"+ this.getHeight());
            System.out.println("get Column Width :"+ this.getColumnWidth());
            System.out.println("get Row height :"+ this.getRowHeight());
            System.out.println("width of character 'm' :"+ this.getFontMetrics(this.getFont()).stringWidth("m"));
            System.out.println("line count :"+ this.getLineCount());
            int x, y , w, h;
            x= (int)g.getClipBounds().getX();
            y = (int)g.getClipBounds().getY();
            w= (int)g.getClipBounds().getWidth();
            h = (int)g.getClipBounds().getHeight();
            Graphics2D gg = (Graphics2D)g.create();
            gg.setColor(new Color(0,0,120));
            gg.fillRoundRect(x,y,w,h,50,50);

            super.paint(gg);
        }

        @Override
        protected void paintComponent(Graphics g) {
            System.out.println("width, height :"+getWidth() +","+ getHeight());
            int x, y , w, h;
            x = (int)g.getClipBounds().getX();
            y = (int)g.getClipBounds().getY();
            w = (int)g.getClipBounds().getWidth();
            h = (int)g.getClipBounds().getHeight();
            Graphics2D gg = (Graphics2D)g.create();
            gg.setColor(new Color(255,255,0));
            gg.fillRoundRect(x,y,w,h,10,10);
            gg.dispose();
            super.paintComponent(g);

        }
    }
}
