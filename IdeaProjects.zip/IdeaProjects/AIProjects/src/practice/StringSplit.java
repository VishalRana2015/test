package practice;

public class StringSplit {
    public static void main(String[] args) {
       String text = "My    Name  is vishal rana.  ";
        String[] s = text.split(" ",-1);
        System.out.println("s.length :"  + s.length);
        for (int i = 0; i < s.length ; i++){
            System.out.println("s[" + i + "] : "+ s[i] + " -len : " + s[i].length());
        }
        System.out.println("Done.");
    }
}
