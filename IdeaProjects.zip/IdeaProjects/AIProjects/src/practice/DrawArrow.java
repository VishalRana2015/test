package practice;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.GeneralPath;
import java.util.*;
public class DrawArrow {
    static class MyPanel extends JPanel{
        boolean up;
        MyPanel(){
            up = false;
        }

        public void setUp(boolean up) {
            this.up = up;
            this.repaint();
        }

        public boolean isUp() {
            return up;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int x, y, w,h;
            x = (int)g.getClipBounds().getX() + this.getInsets().left;
            y = (int)g.getClipBounds().getY() + this.getInsets().top;
            w = (int)g.getClipBounds().getWidth() - (this.getInsets().left + this.getInsets().right);
            h = (int)g.getClipBounds().getHeight()- (this.getInsets().top + this.getInsets().bottom);

            Graphics2D gg = (Graphics2D)g.create();
            gg.setStroke(new BasicStroke(2,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
            gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
            if ( this.isUp()){
                drawUpArrow(gg,x,y,w,h);
            }
            else
                drawBelowArrow(gg,x,y,w,h);
            gg.dispose();

        }
        private void drawBelowArrow(Graphics2D gg, int x, int y , int w, int h){
            GeneralPath path = new GeneralPath(GeneralPath.WIND_EVEN_ODD);
            path.moveTo(x+0.75*w , y+0.6*h);
            path.quadTo(0.75*w+x,0.01*h+y,0.01*w+x,0.01*h+y);
            path.quadTo(0.5*w+x,0.01*h+y,0.5*w+x,0.6*h+y);
            path.lineTo(0.26*w+x,0.6*h+y);
            path.lineTo(0.62*w+x,0.99*h+y);
            path.lineTo(0.98*w+x,0.6*h+y);
            path.closePath();
            gg.setColor(new Color(0,255,0));
            gg.fill(path);
            gg.setColor(Color.BLACK);
            gg.draw(path);

        }
        private void drawUpArrow(Graphics2D gg , int x, int y , int w, int h){
            GeneralPath path = new GeneralPath(GeneralPath.WIND_EVEN_ODD);
            path.moveTo(0.5*w + x, 0.4*h + y);
            path.quadTo(0.5*w+x,0.99*h+y, 0.01*w + x,0.99*h+y);
            path.quadTo(0.75*w+x,0.99*h+y,0.75*w+x,0.4*h+y);
            path.lineTo(0.99*w +x , 0.4*h+ y);
            path.lineTo(0.62*w + x, 0.01*h + y);
            path.lineTo(0.26*w+x, 0.4*h+ y);
            path.closePath();
            gg.setColor(new Color(0,255,0));
            gg.fill(path);
            gg.setColor(Color.BLACK);
            gg.draw(path);
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame ("Drawing Arrow Demo");
        frame.setSize(500,500);
        frame.setLocation(50,0);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        MyPanel panel = new MyPanel();
        panel.setUp(true);
        frame.setContentPane(panel);
        frame.setVisible(true);
    }
    static class MyBorder extends TitledBorder {
        String title;
        MyBorder(Border border , String title){
            super(border,title.concat("   "));
            title = super.getTitle();
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            super.paintBorder(c, g, x, y, width, height);
            x = this.getBorderInsets(c).left + c.getFontMetrics(c.getFont()).stringWidth(this.getTitle().concat(" "));

        }

        private void drawBelowArrow(Graphics2D gg, int x, int y , int w, int h){
            GeneralPath path = new GeneralPath(GeneralPath.WIND_EVEN_ODD);
            path.moveTo(x+0.75*w , y+0.6*h);
            path.quadTo(0.75*w+x,0.01*h+y,0.01*w+x,0.01*h+y);
            path.quadTo(0.5*w+x,0.01*h+y,0.5*w+x,0.6*h+y);
            path.lineTo(0.26*w+x,0.6*h+y);
            path.lineTo(0.62*w+x,0.99*h+y);
            path.lineTo(0.98*w+x,0.6*h+y);
            path.closePath();
            gg.setColor(new Color(0,255,0));
            gg.fill(path);
            gg.setColor(Color.BLACK);
            gg.draw(path);

        }
        private void drawUpArrow(Graphics2D gg , int x, int y , int w, int h){
            GeneralPath path = new GeneralPath(GeneralPath.WIND_EVEN_ODD);
            path.moveTo(0.5*w + x, 0.4*h + y);
            path.quadTo(0.5*w+x,0.99*h+y, 0.01*w + x,0.99*h+y);
            path.quadTo(0.75*w+x,0.99*h+y,0.75*w+x,0.4*h+y);
            path.lineTo(0.99*w +x , 0.4*h+ y);
            path.lineTo(0.62*w + x, 0.01*h + y);
            path.lineTo(0.26*w+x, 0.4*h+ y);
            path.closePath();
            gg.setColor(new Color(0,255,0));
            gg.fill(path);
            gg.setColor(Color.BLACK);
            gg.draw(path);
        }

    }
}
