import java.rmi.Remote;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.concurrent.TimeoutException;


public interface Server extends Remote {
        public UserObject login(String userID, String password)throws SQLException, TimeoutException , UserNameOrPasswordIsInvalidException, RemoteException;
        public UserObject signup(String userID, String userName, String password) throws SQLException, TimeoutException, EmaiIDAlreadyRegisteredException, RemoteException;
}

class UserNameOrPasswordIsInvalidException extends Exception {
    private String userID;
    private String password;
    public UserNameOrPasswordIsInvalidException(String userID){
        this.userID =userID;
    }

    public String getUserID() {
        return userID;
    }

    @Override
    public String toString() {
        return "UserNameOrPasswordIsInvalidException{" +
                "userID='" + userID + '\'' +
                '}';
    }
}


class EmaiIDAlreadyRegisteredException extends Exception{
    private String emailID;
    public EmaiIDAlreadyRegisteredException(String emailID){
        this.emailID =emailID;
    }

    public String getEmailID() {
        return emailID;
    }

    @Override
    public String toString() {
        return "EmaiIDAlreadyRegisteredException{" +
                "emailID='" + emailID + '\'' +
                '}';
    }
}