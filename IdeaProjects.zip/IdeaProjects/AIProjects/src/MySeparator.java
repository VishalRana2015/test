import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.*;

public class MySeparator extends JComponent{
    private String text;
    MySeparator(String text){
        this.text = text;
    }

    public static void main(String[] args) {
        JFrame frame =new JFrame("MySeparator Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocation(50,0);
        frame.setSize(500,500);
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
        MySeparator separator = new MySeparator("Yesterday");
        panel.add(separator);
        separator.setFont(new Font(Font.SANS_SERIF,Font.BOLD,30));
        System.out.println(separator.getMinimumSize());
        separator.setForeground(new Color(255,0,0));

        frame.setContentPane(panel);
        frame.setVisible(true);
    }
    public void setText(String text) {
        this.text = text;
        this.repaint();
    }

    public String getText() {
        return text;
    }

    @Override
    public Dimension getMinimumSize() {
        int w, h;
        h= this.getFont().getSize() +2;
        w = this.getFontMetrics(this.getFont()).stringWidth(this.getText()) + 10;
        return new Dimension(w,h);
    }

    @Override
    public Dimension getMaximumSize() {
        int h = this.getFont().getSize() +2;
        return new Dimension(Integer.MAX_VALUE,h);
    }

    @Override
    public Dimension getPreferredSize() {
        int w,h;
        w = this.getFontMetrics(this.getFont()).stringWidth(this.getText()) + 20;
        h= this.getFont().getSize() + 2;
        return new Dimension(w,h);
    }

    @Override
    public void setSize(Dimension d) {
        super.setSize(d);
    }

    @Override
    public void setSize(int width, int height) {
        super.setSize(width,height);
    }


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        int x, y, w, h;
        x = (int)g.getClipBounds().getX() - this.getInsets().left;
        y = (int)g.getClipBounds().getY() - this.getInsets().top;
        w = (int)g.getClipBounds().getWidth() - (this.getInsets().left + this.getInsets().right);
        h = (int)g.getClipBounds().getHeight() - (this.getInsets().top + this.getInsets().bottom);
        int sw = this.getFontMetrics(this.getFont()).stringWidth(this.getText());
        int sh = this.getFont().getSize() + 1 - this.getFontMetrics(this.getFont()).getDescent();
        int gap = (int)Math.min(0.01*w, 2);
        int sx, sy;
        sx = (w-sw)/2;
        sy = y + sh;
        Graphics2D gg = (Graphics2D)g.create();
        gg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        gg.setColor(this.getForeground());
        gg.drawString(this.getText(),sx,sy);
        // drawing line
        y = (int)g.getClipBounds().getY() - this.getInsets().top;
        y = y+ h/2;
        x = (int)g.getClipBounds().getX() - this.getInsets().left;
        gg.drawLine(x,y,sx-gap,y);
        gg.drawLine(sx+sw+gap,y,w,y);
        gg.dispose();
    }
}
