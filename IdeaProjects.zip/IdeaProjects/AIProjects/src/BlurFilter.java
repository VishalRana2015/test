import javax.swing.*;
import java.awt.*;
import java.awt.image.ColorModel;
import java.awt.image.FilteredImageSource;
import java.awt.image.ImageFilter;
import java.util.Hashtable;

public class BlurFilter extends ImageFilter {
    public static void main(String[] args) {
            JFrame frame = new JFrame("BlueFilter Demo");
            frame.setSize( 500, 500);
            frame.setLocation( 50 , 0);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            JPanel panel = new JPanel();
            JLabel label = new JLabel();
            ImageIcon icon = new ImageIcon("C:\\users\\rana1947\\desktop\\msg.jpg");
            BlurFilter filter = new BlurFilter(5);
            Image image = Toolkit.getDefaultToolkit().createImage( new FilteredImageSource(icon.getImage().getSource(),filter ));
            icon = new ImageIcon( image);
            label.setIcon( icon);
            label.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            panel.add(label);
            frame.setContentPane(panel);
            frame.setVisible(true);
    }
    public BlurFilter(int radius){
        this.radius = radius;
        if ( radius  < 1 )
            this.radius = 1;
        if ( radius % 2 == 0)
            this.radius = radius + 1;
    }

    int radius;
    int savedWidth , savedHeight;
    int[] savedPixels;
    @Override
    public void setDimensions(int width, int height) {
        //super.setDimensions(width, height);
        savedWidth  = width;
        savedHeight = height;
        savedPixels = new int[savedWidth * savedHeight];
        consumer.setDimensions(savedWidth, savedHeight);
    }

    @Override
    public void setPixels(int x, int y, int w, int h, ColorModel model, byte[] pixels, int off, int scansize) {
        //super.setPixels(x, y, w, h, model, pixels, off, scansize);
        int row, col;
        for ( int r = 0; r < h ; r++ ){
            row = r + y;
            for ( int c = 0; c < w ; c++){
                col = c + x;
                savedPixels[row * savedWidth + col] = pixels[r*scansize + c + off];
            }
        }
    }

    @Override
    public void setHints(int hints) {
        consumer.setHints( ImageFilter.COMPLETESCANLINES | ImageFilter.TOPDOWNLEFTRIGHT | ( ImageFilter.SINGLEFRAME & hints) | ( ImageFilter.SINGLEPASS & hints));
    }

    @Override
    public void setProperties(Hashtable<?, ?> props) {
        consumer.setProperties(props);
    }

    @Override
    public void setPixels(int x, int y, int w, int h, ColorModel model, int[] pixels, int off, int scansize) {
        int row, col;
        for ( int r = 0; r < h ; r++ ){
            row = r + y;
            for ( int c = 0; c < w ; c++){
                col = c + x;
                savedPixels[row * savedWidth + col] = pixels[r*scansize + c + off];
            }
        }
    }
    ColorModel model;
    @Override
    public void setColorModel(ColorModel model) {
        this.model = model;
        consumer.setColorModel(ColorModel.getRGBdefault());
    }

    @Override
    public void imageComplete(int status) {
        if ( (( status & ImageFilter.STATICIMAGEDONE ) | ( status & ImageFilter.SINGLEFRAME)) != 0  ){
            int rr = radius/2;
            int red, green , blue  =0;
            int total = 0;
            int row , col;
            int[] temp = new int[savedWidth];
            int[] newPixels = new int [ savedWidth * savedHeight];
            for ( int  r= 0; r < savedHeight ; r++){

               for ( int c = 0; c < savedWidth ; c++){
                   red = green = blue = 0;
                   for ( int i = 0; i < radius ;i++){
                       for ( int j = 0; j < radius ; j++){
                           try{
                                row = -radius/2 + r + i ;
                                col = -radius/2 + c + j;

                               int val = savedPixels[row * savedWidth + col];
                           //    System.out.println("row : " + row + " col + "+ col);
                             //  System.out.println("val :"+ val);
                               val = this.model.getRGB(val);
                               red += (val >> 16) & (0xff);
                               green +=  ( val >> 8 ) & ( 0xff);
                               blue +=  ( val ) & 0xff;
                           }
                           catch( ArrayIndexOutOfBoundsException e ){
                                    red += 0;
                                    green += 0;
                                    blue += 0;
                    //                System.out.println("row : " + r + " col : " + c);
                           }
                           catch( Exception e){
                               System.out.println("Some other exception occurred");
                           }
                       }
                   }
                   red = red / (radius*radius);
                   green =green / (radius * radius);
                   blue =blue / (radius * radius);
                  // System.out.println(" red : " +red + " green : " + green + " blue : " + blue);
                   Color color  = new Color( red, green , blue);
                   int val = color.getRGB();
                   temp[c] = val;
                   newPixels[ r* savedWidth + c] = val;
                   //System.out.println("val :"+ val);
               }
               //consumer.setPixels(0, r , savedWidth, 1 , ColorModel.getRGBdefault(),temp,0,savedWidth);
           }
            temp = new int[savedWidth];
            for ( int r = 0 ; r < savedHeight ; r++){
                for ( int c = 0; c < savedWidth ; c++){
                    temp[c] = newPixels[r*savedWidth + c];
                }
                consumer.setPixels(0,r,savedWidth,1 , ColorModel.getRGBdefault(),temp,0,savedWidth);
            }
        }
        consumer.imageComplete(status);
    }

}
