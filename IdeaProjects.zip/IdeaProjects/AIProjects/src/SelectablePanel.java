import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class SelectablePanel{
    public static void main(String[] args) {
        JFrame frame;

        JPanel panel =new JPanel(){
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D gg = (Graphics2D)g.create();
                gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                super.paintComponent(g);
                g.setColor(Color.BLACK);

            }

        };
        JFileChooser fileChooser  = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);



    }
}