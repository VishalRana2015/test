package ImageFilters;
import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.util.*;
public class ColorModelDemo {
    public static void main(String[] args) {
        JFrame frame = new JFrame("JFrame");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocation(50,0);
        frame.setSize(500,500);

        JLabel label =new JLabel();
        ImageIcon icon =new ImageIcon("F:\\PICS\\style\\necklock.jpg");
        label.setIcon(icon);
        Image image = icon.getImage();
        BufferedImage bimage = new BufferedImage(image.getWidth(null) , image.getHeight(null) , BufferedImage.TYPE_INT_RGB);
        System.out.println("Color model of image data :"+ bimage.getColorModel());
        JPanel panel =new JPanel();
        panel.add(label);
        frame.setContentPane(panel);
        frame.setVisible(true);
    }

    static class GrayColorModel extends ColorModel{
        public GrayColorModel(){
            super(32);
        }
        @Override
        public int getRed(int pixel) {
            return 0;
        }

        @Override
        public int getAlpha(int pixel) {
            return 0;
        }

        @Override
        public int getBlue(int pixel) {
            return 0;
        }

        @Override
        public int getBlue(Object inData) {
            return super.getBlue(inData);
        }

        @Override
        public int getGreen(int pixel) {
            return 0;
        }
    }
}
