package ImageFilters;
import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;

public class TransparentImage {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Transparent Image Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocation(50,0);
        frame.setSize(500,500);
        JPanel panel = new JPanel();
        panel.setBackground(Color.ORANGE);
        JLabel label = new JLabel();
        ImageIcon icon = new ImageIcon("C:\\Users\\RANA1947\\Desktop\\usericon.jpg");
        Image image = icon.getImage();


        label.setIcon(icon);
        panel.add(label);
        frame.setContentPane(panel);

        frame.setVisible(true);
    }
    static public BufferedImage imageToBufferedImage( Image image){
        BufferedImage bimage = new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_RGB);
        Graphics2D gg = (Graphics2D)bimage.getGraphics();
        gg.drawImage(image,0, 0 , bimage.getWidth(),bimage.getHeight() , 0 , 0 , image.getWidth(null) , image.getHeight(null) , null);
        gg.dispose();
        return bimage;
    }
    static class MyFilter extends RGBImageFilter{
        Color backgroundColor;
        MyFilter(Color color){
            this.backgroundColor = color;
        }
        @Override
        public int filterRGB(int x, int y, int rgb) {
            return 1;
        }
    }
}
