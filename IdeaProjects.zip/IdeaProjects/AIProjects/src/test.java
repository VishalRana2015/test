import java.sql.*;

public class test {
    public static void main(String[] args) {
        try{
            String s = "jdbc:sqlite3:C://users//rana1947//desktop//mydb2.db";
            Connection conn = DriverManager.getConnection(s);
            System.out.println("Connection made");
        }
        catch( Exception e){
            System.out.println("Exception thrown : "  + e.getMessage());
        }
    }
}
