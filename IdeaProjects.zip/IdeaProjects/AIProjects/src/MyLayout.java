import java.awt.*;
import java.awt.Component;
import java.io.*;
import javax.swing.*;
public class MyLayout implements LayoutManager2 , java.io.Serializable {
    static public String HELP = "HELP";
    static public String BACK = "BACK";
    static public String NEXT = "NEXT";
    static public String EXIT = "EXIT";
    int hgap,vgap;
    int maxgap ;
    int maxWidth,maxHeight;
    boolean isMaxSet;
    boolean isHelpExists, isBackExists, isNextExists, isExitExists;
    Component helpComp, exitComp, backComp, nextComp;

    public static void main(String[] args) {
        JFrame frame= new JFrame("MyLayout Demo");
        frame.setSize(500,500);
        frame.setLocation(50,0);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel =new JPanel();
        panel.setLayout(new MyLayout());
        panel.add(new JButton("Help"),MyLayout.HELP);
        panel.add(new JButton("Go to Next"),MyLayout.NEXT);
        panel.add(new JButton("Back"),MyLayout.BACK);
        panel.add(new JButton("exit"),MyLayout.EXIT);
        JPanel panel2 = new JPanel();
        panel2.setLayout(new BoxLayout(panel2,BoxLayout.Y_AXIS));
        panel2.add(panel);
        frame.setContentPane(panel2);
        frame.setVisible(true);
    }
    MyLayout(){
        isBackExists  = false;
        isHelpExists = false;
        isNextExists = false;
        isExitExists = false;
        hgap = 5;
        vgap = 5;
        maxgap = 100;
        maxHeight = 0;
        maxWidth = 0;
        isMaxSet = false;
    }

    public int getMaxgap() {
        return maxgap;
    }

    public int getHgap() {
        return hgap;
    }

    public int getVgap() {
        return vgap;
    }

    @Override
    public void removeLayoutComponent(Component comp) {
        System.out.println("In remove LayoutComponent");
        if ( isHelpExists ){
            if( comp.equals(helpComp)){
                helpComp= null;
                isHelpExists = false;
            }
        }
        if ( isNextExists){
            if( comp.equals(nextComp)){
                nextComp = null;
                isNextExists=  false;
            }
        }
        if ( isBackExists ){
            if ( comp.equals(backComp)){
                isBackExists = false;
                backComp= null;
            }
        }
        if ( isExitExists){
            if ( comp.equals(exitComp)){
                isHelpExists = false;
                exitComp = null;
            }
        }
        isMaxSet  = false;
    }

    @Override
    public void addLayoutComponent(String name, Component comp) {
        System.out.println("In Add LayoutComponent (name, comp)");
    }

    @Override
    public void addLayoutComponent(Component comp, Object constraints) {
       // System.out.println("in addLayoutComponent (comp,constraints)");
        if ( constraints instanceof String){
         //   System.out.println("Constraints is an instace of String");
            String s= (String)constraints;
            if(  s.equalsIgnoreCase(MyLayout.EXIT)){
           //     System.out.println("equals to exit");
                exitComp = comp;
                isExitExists = true;
            }
            if ( s.equalsIgnoreCase(MyLayout.HELP)){
             //   System.out.println("equals to help");
                helpComp = comp;
                isHelpExists = true;
            }
            if ( s.equalsIgnoreCase(MyLayout.BACK)){
               // System.out.println("equals to back");
                isBackExists = true;
                backComp= comp;
            }
            if (  s.equalsIgnoreCase(MyLayout.NEXT)){
                //System.out.println("equals to next");
                isNextExists = true;
                nextComp = comp;
            }
            isMaxSet = false;
        }
        else{
            throw new IllegalArgumentException("Not a valid contraint" + constraints.toString());
        }
    }

    @Override
    public void layoutContainer(Container parent) {
      //  System.out.println("layoutContainer method called");
        // This method is responsible for laying out the components on the container.
        int x, y;
        x = hgap;
        y = vgap;
        if ( isHelpExists){
            helpComp.setBounds(x,y,maxWidth,maxHeight);
            int n =2;
            if ( isBackExists)
                ++n;
            if ( isNextExists)
                ++n;
            if ( isExitExists)
                ++n;
            int w ;
        //    System.out.println("n,maxWidth ,hgap :"+ n+","+maxWidth+","+hgap);
          //  System.out.println("parent.width :"+parent.getWidth());
            w= parent.getWidth()- (n*hgap + (n-1)*maxWidth);
            //System.out.println("w: "+w);
            if( w> 0)
            x= x+ maxWidth+ hgap + w;
            else
                x= x+ maxWidth + hgap;
        }
        if ( isBackExists){
            backComp.setBounds(x,y,maxWidth,maxHeight);
            x = x+maxWidth+ hgap;
        }
        if ( isNextExists){
            nextComp.setBounds(x,y,maxWidth,maxHeight);
            x = x+maxWidth+ hgap;
        }
        if( isExitExists){
            exitComp.setBounds(x,y,maxWidth,maxHeight);
            x = x+maxWidth+ hgap;
        }
       // System.out.println("setted bounds succesffully");

    }

    @Override
    public Dimension minimumLayoutSize(Container parent) {
        Dimension d = new Dimension(0,0);
        int w, h;
        w  = 0;
        h = 0;
        boolean isany = false;
        if ( !isMaxSet){
            setMax();
        }

        if ( isHelpExists){
            w += maxWidth + hgap ;
            isany = true;
        }
        if (isBackExists){
            w += maxWidth + hgap ;
            isany = true;
        }
        if( isNextExists ){
            w += maxWidth + hgap;
            isany = true;
        }
        if (isExitExists){
            w += maxWidth + hgap;
            isany = true;
        }
        if (isany){
            h = maxHeight + 2*vgap;
        }
        d.setSize(new Dimension(w,h));
       // System.out.println("called minimumLayoutSize :"+d);
        return d;
    }
    private void setMax(){
        maxWidth = 0;
        maxHeight = 0;
        if ( isHelpExists){
            maxWidth = Math.max(maxWidth,(int) helpComp.getPreferredSize().getWidth());
            maxHeight = Math.max(maxHeight,(int)helpComp.getPreferredSize().getHeight());
            System.out.println("help button maxheight :"+ helpComp.getPreferredSize().getSize().getHeight());
        }
        if ( isBackExists){
            maxWidth = Math.max( maxWidth, (int)backComp.getPreferredSize().getWidth());
            maxHeight = Math.max(maxHeight,(int)backComp.getPreferredSize().getHeight());
        }
        if( isHelpExists){
            maxWidth =Math.max(maxWidth , (int)helpComp.getPreferredSize().getWidth());
            maxHeight = Math.max(maxHeight,(int)backComp.getPreferredSize().getHeight());
        }
        if ( isNextExists){
            maxWidth = Math.max(maxWidth, (int)nextComp.getPreferredSize().getWidth());
            maxHeight = Math.max(maxHeight, (int)nextComp.getPreferredSize().getHeight());
        }
        isMaxSet = true;
    }
    @Override
    public Dimension maximumLayoutSize(Container target) {
        Dimension d = new Dimension(0,0);
        int w, h;
        w  = 0;
        h = 0;
        boolean isany = false;
        if ( !isMaxSet){
            setMax();
        }

        if ( isHelpExists){
            w += maxWidth + hgap + maxgap ;
            isany = true;
        }
        if (isBackExists){
            w += maxWidth + hgap ;
            isany = true;
        }
        if( isNextExists ){
            w += maxWidth + hgap;
            isany = true;
        }
        if (isExitExists){
            w += maxWidth + hgap;
            isany = true;
        }
        if (isany){
            h = maxHeight + 2*vgap;
        }
        //System.out.println("w,h :"+ w+","+ h);
        d.setSize(new Dimension(w,h));
        //System.out.println("called maxLayoutSize :"+ d);
        return d;
    }

    @Override
    public Dimension preferredLayoutSize(Container parent) {
        Dimension d = new Dimension(0,0);
        int w, h;
        w  = 0;
        h = 0;
        boolean isany = false;
        if ( !isMaxSet){
            setMax();
        }

        if ( isHelpExists){
            w += maxWidth + hgap + maxgap ;
            isany = true;
        }
        if (isBackExists){
            w += maxWidth + hgap ;
            isany = true;
        }
        if( isNextExists ){
            w += maxWidth + hgap;
            isany = true;
        }
        if (isExitExists){
            w += maxWidth + hgap;
            isany = true;
        }
        if (isany){
            h = maxHeight + 2*vgap;
        }
       // System.out.println("w,h :"+ w+ ","+ h);
        d.setSize(new Dimension(w,h));
        //System.out.println("called layoutPreferredSize :"+ d);
        return d;
    }

    @Override
    public float getLayoutAlignmentX(Container target) {
        return 0;
    }

    @Override
    public float getLayoutAlignmentY(Container target) {
        return 0;
    }

    @Override
    public void invalidateLayout(Container target) {

    }
}
