import login.BottomLineBorder;
import textfield.VPassword;
import textfield.VTextField;
import java.rmi.*;
import java.awt.Component;
import java.io.*;
import java.awt.image.*;
import javax.smartcardio.Card;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
public class LoginAndSignup {
    private static int fw, fh;
    private static JFrame frame;
    private static JPanel signuppanel , loginpanel , mainpanel;
    public static void main(String[] args) {
        frame = new JFrame("Login And Signup");
        int w, h ;
        w = Toolkit.getDefaultToolkit().getScreenSize().width;
        h = Toolkit.getDefaultToolkit().getScreenSize().height;
        int tx, ty;
        fw = 400; fh = 600;
        tx = (w - fw)/2;
        ty = ( h -fh)/2;
        frame.setSize(fw,fh);
        frame.setLocation(tx,ty);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        mainpanel = new JPanel();
        mainpanel.setLayout(new CardLayout());
        loginpanel =login();
        signuppanel = signup();
        mainpanel.add(loginpanel,"login");
        mainpanel.add(signuppanel,"signup");
        frame.setContentPane(mainpanel);
        frame.setUndecorated(true);
        frame.setVisible(true);
    }
    private static JButton createExitButton(){
        JButton exitButton;
        Font font = new Font(Font.SERIF,Font.PLAIN,16);
        exitButton = new JButton();
        exitButton.setText("Exit");
        exitButton.setFont(font);
        int cw, ch;
        cw = (int)exitButton.getPreferredSize().getWidth();
        ch = (int)exitButton.getPreferredSize().getHeight();
        System.out.println("cw , ch :"+ cw + " , " + ch);
        exitButton.setSize( cw, ch);
        Color bgColor = new Color(0,0,0,0);
        exitButton.setBackground(bgColor);
        exitButton.setOpaque(false);
        exitButton.setFocusPainted(false);
        exitButton.setBorderPainted(false);
        exitButton.setBorder(BorderFactory.createEmptyBorder());
        exitButton.setForeground(new Color(244, 2, 69));
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });
        return exitButton;
    }
    public static JPanel login(){
        int offset = 10;
        int x, y , w, h;
        x = 10; y = 10;
        int cw, ch; // stands for component width and component height
        // these values will keep track of last component location's and size's values.
        JPanel panel = new JPanel();
        panel.setBackground(Color.ORANGE);
        panel.setLayout(null);
        JLabel welcome = new JLabel("Welcome");
        Font font = new Font(Font.SERIF,Font.PLAIN,50);
        welcome.setFont(font);
        welcome.setSize(w =welcome.getFontMetrics(welcome.getFont()).stringWidth(welcome.getText()), h = welcome.getFont().getSize()+2);
        welcome.setLocation(10,10);
        panel.add(welcome);
        y = y + h + offset;
        JLabel welcomemsg = new JLabel("glad to see you!");
        font = new Font(Font.SERIF,Font.PLAIN,25);
        welcomemsg.setFont(font);
        welcomemsg.setLocation(x + offset,y);
        welcomemsg.setSize( w= welcomemsg.getFontMetrics(welcomemsg.getFont()).stringWidth(welcomemsg.getText()),h = welcomemsg.getFont().getSize()+ welcomemsg.getFontMetrics(welcomemsg.getFont()).getDescent());
        panel.add(welcomemsg);
        y= y + h + 4*offset;
        VTextField username = new VTextField("email@mail.com");
        font = new Font(Font.SERIF,Font.PLAIN,20);
        username.setFont(font);
        Border lineborder =new BottomLineBorder(0,0,2,0);
        username.setBorder(lineborder);
        username.setSize(w = fw -2*offset, h = username.getFontMetrics(username.getFont()).getHeight() + username.getInsets().bottom + username.getInsets().top );
        username.setLocation(x,y);
        panel.add(username);

        VPassword password = new VPassword("Password");
        password.setFont(font);
        y = y + h + offset;
        password.setSize(w = fw-2*offset, h = password.getFontMetrics(password.getFont()).getHeight() + password.getInsets().bottom + password.getInsets().top);
        password.setLocation(x,y);
        panel.add(password);
        password.setBorder(lineborder);
        y = y + h + offset;

        // creating info label
        JTextArea errorArea = new JTextArea();
        errorArea.setEditable(false);
        errorArea.setBackground(new Color(0,0,0,0));
        font = new Font(Font.SERIF,Font.PLAIN,16);
        errorArea.setFont(font);
        errorArea.setForeground(new Color(111, 103, 255));
        ch = errorArea.getFont().getSize() * 2;
        cw = fw - 2*offset;
        errorArea.setText("This is error area.");
        errorArea.setSize( cw, ch);
        errorArea.setLocation(x,y);
        panel.add(errorArea);
        // forget about for now

        y = y + h + 3*offset;
        JButton loginButton = new JButton();
        loginButton.setText("Login");
        int bw , bh ;
        bw = (int)loginButton.getPreferredSize().getWidth();
        bh = (int)loginButton.getPreferredSize().getHeight();
        x = fw/2-bw/2;
        loginButton.setLocation(x,y);
        loginButton.setSize(bw,bh);
        panel.add(loginButton);
        y = y + h + offset;


        font =new Font(Font.SERIF,Font.PLAIN,16);
        JLabel l1 = new JLabel("Don't have any account.");
        JButton toSignup = new JButton("Click here");
        JLabel l2 = new JLabel(" to create a new one.");
        l1.setFont(font);
        toSignup.setFont(font);
        toSignup.setOpaque(false);
        toSignup.setBorder( BorderFactory.createEmptyBorder());
        toSignup.setBorderPainted(false);
        toSignup.setFocusPainted(false);
        toSignup.setBackground(new Color(0,0,0,0));

        toSignup.setForeground(new Color(117, 119, 164));
        l2.setFont(font);
        ch = (int)l1.getPreferredSize().getHeight();
        cw = (int)l1.getPreferredSize().getWidth();
        l1.setSize(cw, ch);
        x = offset;
        l1.setLocation(x,y);
        x = x + cw;
        cw = (int)toSignup.getPreferredSize().getWidth();
        toSignup.setSize(cw, ch);
        toSignup.setLocation(x,y);
        x = x+ cw;
        cw = (int)l2.getPreferredSize().getWidth();
        l2.setSize(cw,ch);
        l2.setLocation(x,y);

        panel.add(l1);
        panel.add(toSignup);
        panel.add(l2);

        x = offset;
        y = y + ch + offset;
        JButton exitButton = createExitButton();
        exitButton.setLocation(x,y);
        panel.add(exitButton);


        JLabel loginlabel = new JLabel("LOGIN");
        font = new Font(Font.SERIF,Font.BOLD , 50);
        loginlabel.setHorizontalTextPosition(JLabel.TRAILING);
        loginlabel.setVerticalTextPosition(JLabel.CENTER);
        loginlabel.setFont(font);

        loginlabel.setHorizontalAlignment(JLabel.CENTER);
        loginlabel.setSize(fw,100);
        loginlabel.setForeground(new Color(255,255,255));
        loginlabel.setBackground(new Color(220,0,0));
        loginlabel.setOpaque(true);
        loginlabel.setLocation(0,fh-100);
        panel.add(loginlabel);

        toSignup.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CardLayout layout = (CardLayout)mainpanel.getLayout();

                layout.show(mainpanel,"signup");
            }
        });

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("loin button clicked");
                Image image = createImage( loginpanel,128);
                ImageIcon icon = new ImageIcon("C:\\Users\\RANA1947\\IdeaProjects\\AIProjects\\files\\gif1.gif");
                MyComponent comp =  new MyComponent(image,icon.getImage());
                frame.setGlassPane(comp);
                frame.getGlassPane().setVisible(true);
                // Now accessing the server for login purpose
                Runnable runn = new Runnable() {
                    @Override
                    public void run() {
                        UserObject obj = null;
                        try{
                            Server server = (Server)Naming.lookup("rmi://localhost:20000//object" );
                            Thread.currentThread().sleep(1000);
                            obj = (UserObject)server.login( username.getText() , password.getText());
                            frame.setVisible(false);
                            UserFrame frame = new UserFrame(obj);
                            frame.dispose();
                        }
                        catch( Exception e){
                            System.out.println("Exception occurred inloginButon : " + e.getMessage());
                            errorArea.append(e.getMessage());
                            frame.getGlassPane().setVisible(false);
                        }

                    }
                };
                Thread thread = new Thread(runn);
                thread.start();
            }
        });
        return panel;
    }
    public static JPanel signup(){
        int x, y  , offset;
        x = 10; y = 10;  offset = 5; // x and y are used to set locaion of various components in this panel
        int w, h;
        int sw, ch , cw;// statnds for stringWidth , componentHeight , componentWidth;
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.ORANGE);

        Font font ;
        font = new Font(Font.SERIF,Font.BOLD,50);
        JLabel welcomeLabel = new JLabel("Welcome");
        welcomeLabel.setFont(font);
        welcomeLabel.setLocation(x,y);
        sw = welcomeLabel.getFontMetrics(welcomeLabel.getFont()).stringWidth(welcomeLabel.getText());
        ch = (int)welcomeLabel.getPreferredSize().getHeight();
        ch = (int)welcomeLabel.getFont().getSize();
        welcomeLabel.setSize(sw,ch);
        y = y + ch + offset;
        font = new Font( Font.SERIF,Font.PLAIN,25);
        JLabel infoLabel = new JLabel("Chatting Application");
        infoLabel.setFont(font);
        infoLabel.setLocation(x,y);
        sw = infoLabel.getFontMetrics(infoLabel.getFont()).stringWidth(infoLabel.getText());
        ch = (int)infoLabel.getPreferredSize().getHeight();
        infoLabel.setSize(sw,ch);
        panel.add(infoLabel);
        y = y + ch + 4*offset;
        VTextField name = new VTextField("Name");
        VTextField userid = new VTextField("UserID@-mail.com");
        VTextField password =new VTextField( "Password");
        VTextField confirmPassword = new VTextField("ConfirmPassword");
        font = new Font(Font.SERIF,Font.PLAIN,20);
        name.setFont(font);
        userid.setFont(font);
        password.setFont(font);
        confirmPassword.setFont(font);
        BottomLineBorder blackBorder = new BottomLineBorder(0,0,5,0);
        BottomLineBorder redBorder = new BottomLineBorder( 0, 0, 5, 0);
        name.setBorder( blackBorder);
        userid.setBorder(blackBorder);
        password.setBorder(blackBorder);
        confirmPassword.setBorder(blackBorder);

        cw = fw-2*offset -x;
        ch = (int)name.getPreferredSize().getHeight();
        name.setSize(cw,ch);
        userid.setSize(cw,ch);
        password.setSize(cw,ch);
        confirmPassword.setSize(cw,ch);
        //name.setLocation(x,y);
        y = y  + offset;


        name.setLocation(x,y);
        y = y + ch + offset;
        userid.setLocation(x,y);
        y = y + ch + offset;
        password.setLocation(x,y);
        y = y + ch + offset;
        confirmPassword.setLocation(x,y);
        y = y + ch + offset;

        panel.add(name);
        panel.add(userid);
        panel.add(password);
        panel.add(confirmPassword);
        panel.add(welcomeLabel);

        JTextArea errorArea = new JTextArea();
        font = new Font(Font.SERIF,Font.ITALIC,12);
        errorArea.setForeground(new Color(120,0,0));
        errorArea.setOpaque(false);
        errorArea.setEditable(false);
        errorArea.setLocation(x,y);
        errorArea.setText("This is error Area.");
        errorArea.setLineWrap(true);
        ch = errorArea.getFont().getSize();
        ch = ch * 2;
        errorArea.setSize( cw, ch);
        y = y + ch + offset;
        panel.add(errorArea);

        JButton sbutton = new JButton("Signup");
        font = new Font(Font.SERIF,Font.PLAIN,16);
        sbutton.setFont(font);
        ch = (int)sbutton.getPreferredSize().getHeight();
        cw = (int)sbutton.getPreferredSize().getWidth();
        x = fw/2 - cw/2;
        sbutton.setLocation(x,y);
        sbutton.setSize(cw,ch);
        x = offset;
        y= y + ch + offset;
        panel.add(sbutton);

        Color bgColor= new Color(0,0,0,0);
        JLabel l1 = new JLabel("Already have an account. ");
        font = new Font(Font.SERIF,Font.PLAIN,16);
        l1.setFont(font);
        cw = (int)l1.getPreferredSize().getWidth();
        ch = (int)l1.getPreferredSize().getHeight();
        l1.setBackground(bgColor);
        l1.setBorder(BorderFactory.createEmptyBorder());
        l1.setLocation(x,y);
        l1.setSize(cw,ch);
        x = x + cw;

        JButton toLogin = new JButton("Click here");
        toLogin.setFont(font);
        toLogin.setOpaque(false);
        toLogin.setBorder( BorderFactory.createEmptyBorder());
        toLogin.setBackground(new Color(0,0,0,0));
        toLogin.setForeground(new Color(65, 68, 244));
        cw = (int)toLogin.getPreferredSize().getWidth();
        ch = (int)toLogin.getPreferredSize().getHeight();
        toLogin.setLocation(x,y);
        toLogin.setSize(cw,ch);


        JLabel l2 = new JLabel(" to Login.");
        l2.setFont(font);
        l2.setBackground(bgColor);
        l2.setBorder( BorderFactory.createEmptyBorder());
        x= x+ cw;
        l2.setLocation(x,y);
        l2.setSize(cw,ch);
        y = y + ch + offset;

        panel.add(l1);
        panel.add(toLogin);
        panel.add(l2);
        x = offset;


        x = 10*offset;
        JButton exitButton = createExitButton();
        cw= (int)exitButton.getPreferredSize().getWidth();
        ch = (int)exitButton.getPreferredSize().getHeight();
        exitButton.setVisible(true);
        exitButton.setLocation(x,y);

        panel.add(exitButton);


        JLabel signuplabel = new JLabel("SIGNUP");
        signuplabel.setHorizontalAlignment(JLabel.CENTER);
        signuplabel.setHorizontalTextPosition(JLabel.CENTER);
        signuplabel.setVerticalTextPosition(JLabel.CENTER);
        font = new Font(Font.SERIF, Font.BOLD, 50);
        signuplabel.setFont(font);
        signuplabel.setForeground(new Color(255,255,255));
        signuplabel.setBackground(new Color(220,0,0));
        signuplabel.setOpaque(true);
        signuplabel.setSize(fw,100);
        signuplabel.setLocation(0,fh-100);
        panel.add(signuplabel);

        toLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CardLayout layout = (CardLayout) mainpanel.getLayout();
                layout.show(mainpanel,"login");
            }
        });
        return panel;
    }



    public static Image createImage (Component comp  , int alpha){
        int w, h;
        w = comp.getWidth();
        h = comp.getHeight();
        BufferedImage image = new BufferedImage(w,h,BufferedImage.TYPE_INT_RGB);
        Graphics g = image.getGraphics();
        comp.paint(g);
        Graphics2D gg = (Graphics2D)g.create();
        Color color = new Color( 0, 0, 0 , alpha);
        gg.setComposite( AlphaComposite.getInstance( AlphaComposite.SRC_OVER));
        gg.setColor( color);
        gg.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,((float)alpha)/(float)256));
        gg.fillRect(0,0,w,h);
        g.dispose();
        BlurFilter filter= new BlurFilter(5);
        return  Toolkit.getDefaultToolkit().createImage( new FilteredImageSource(image.getSource(), filter) );

    }
    private static class MyComponent extends JComponent{
        Image bgImage;
        Image labelImage;
        int lw,lh;
        MyImageObserver observer ;
        public MyComponent(Image bgImage, Image labelImage, int lw, int lh){
            this.bgImage = bgImage;
            this.labelImage = labelImage;
            this.lw = lw;
            this.lh = lh;
            JLabel label =new JLabel();
            label.setIcon( new ImageIcon(labelImage));
            this.setLayout( null);
            this.add(label);
            System.out.println(label.getPreferredSize());
            label.setSize( label.getPreferredSize());
            label.setLocation(fw/2-lw/2 , fh/2-lh/2);
            observer = new MyImageObserver(this);
        }
        public MyComponent( Image  bgImage ,Image labelImage ){
            this.bgImage = bgImage;
            this.labelImage = labelImage;
            this.lw = labelImage.getWidth(null);
            this.lh = labelImage.getWidth( null);
            JLabel label =new JLabel();
            label.setIcon( new ImageIcon(labelImage));
            this.setLayout( null);
            this.add(label);
            System.out.println(label.getPreferredSize());
            label.setSize( label.getPreferredSize());
            label.setLocation(fw/2-lw/2 , fh/2-lh/2);

            observer = new MyImageObserver(this);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int x, y , w, h;
            x= this.getInsets().left;
            y= this.getInsets().top;
            w = this.getWidth() - (this.getInsets().left + this.getInsets().right);
            h = this.getHeight() - (this.getInsets().top + this.getInsets().bottom);
            Graphics2D gg = (Graphics2D) g.create();
            gg.drawImage(bgImage, 0, 0 , w, h, observer);
            gg.dispose();
        }

        private static class MyImageObserver implements ImageObserver{
            MyComponent comp;
            public MyImageObserver(MyComponent comp){
                this.comp = comp;
            }
            @Override
            public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {
                if (  ((infoflags & ImageObserver.FRAMEBITS ) | (infoflags & ImageObserver.ALLBITS)) != 0){
                    comp.repaint();
                }
                return true;
            }
        }
    }

    private class LoginTask extends SwingWorker<Integer,Object> {
        String username, password;
        public LoginTask( String username, String password){
            this.username = username;
            this.password = password;
        }
        @Override
        protected Integer doInBackground() throws Exception {
            System.out.println("Login doInBackground method");
            try{
                Server s = (Server)Naming.lookup("rmi://locahost:20000//server");
                UserObject object = s.login(this.username, this.password);

            }
            catch ( Exception e){
                System.out.println("Exception thrown :"+ e.getMessage());
            }
            return 1;
        }

        @Override
        protected void done() {
            System.out.println("done ");
        }
    }
}
