
import javax.imageio.ImageIO;
import javax.imageio.ImageTranscoder;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.Border;
import javax.swing.event.*;
import javax.tools.Tool;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;
import java.lang.reflect.*;
import java.io.*;
import java.awt.geom.*;
public class JFrameOpacity {
    public static void main(String[] args) {
        final5();
    }

    private static void final2() {
        JFrame frame = new JFrame("what the hell");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 700);
        frame.setLocation(0, 0);
        frame.setContentPane(new JLabel(new ImageIcon("C:\\Users\\RANA1947\\Desktop\\convo.jpg")));
        JPanel panel1 = new JPanel();
        panel1.setPreferredSize(new Dimension(100, 100));
        panel1.setBackground(new Color(0, 0, 0, 100));
        panel1.setBorder(BorderFactory.createLineBorder(Color.BLACK, 10));
        frame.setLayout(new FlowLayout());
        frame.add(panel1);

        frame.setVisible(true);
        frame.pack();
    }

    private static void final1() {
        JFrame frame = new JFrame("Translucent Glass Pane Demo");
        frame.setSize(500, 500);
        frame.setLocation(50, 0);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel rootpanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                super.paintComponent(g);

                Graphics2D g2 = (Graphics2D) g.create();
                g.setColor(Color.black); // black background

                Area area = new Area();
                // This is the area that will filled...
                area.add(new Area(new Rectangle2D.Float(0, 0, getWidth(), getHeight())));

                g2.setColor(Color.GREEN.darker());

                int width = getWidth() - 1;
                int height = getHeight() - 1;

                int openWidth = 200;
                int openHeight = 200;

                int x = (width - openWidth) / 2;
                int y = (height - openHeight) / 2;

                // This is the area that will be uneffected
                area.subtract(new Area(new Rectangle2D.Float(x, y, openWidth, openHeight)));

                // Set up a AlphaComposite
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
                g2.fill(area);
                g2.dispose();
            }
        };

        JPanel framepanel = new JPanel();
        framepanel.add(new JLabel("My name is vishal rana."));
        framepanel.add(new JLabel("Hello world!"));
        framepanel.setBackground(new Color(0, 255, 0));
        frame.setContentPane(framepanel);
        JLabel rootlabel = new JLabel("This is glass Label");
        rootlabel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        rootpanel.add(rootlabel);
        JLayeredPane pane = new JLayeredPane();

        rootpanel.setPreferredSize(new Dimension(200, 200));
        framepanel.add(rootpanel);
        pane.add(rootpanel);
        frame.setContentPane(framepanel);
        frame.setVisible(true);
    }

    private static void final3() {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 700);
        frame.setLocation(50, 0);
        JPanel panel = new JPanel();
        JLayeredPane pane = new JLayeredPane();
        JLabel label = new JLabel(new ImageIcon("C:\\Users\\RANA1947\\Desktop\\msg.jpg"));
        label.setLocation(0, 0);
        label.setSize(label.getPreferredSize());
        JButton button = new JButton("Show translucent panel");
        button.setSize(button.getPreferredSize());
        int x, y;
        x = 10;
        y = label.getHeight() + 10;
        button.setLocation(x, y);
        pane.add(button, 1);
        pane.add(label, 1);
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JPanel panel = new JPanel();
                panel.setSize(pane.getSize());
                JLabel label = new JLabel(new ImageIcon("C:\\Users\\RANA1947\\Desktop\\gif1.gif"));
                label.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 4));
                panel.add(label);
                JButton button = new JButton("Remove this layer");
                button.setSize(button.getPreferredSize());
                button.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        button.remove(panel);
                    }
                });
                panel.setBackground(new Color(0, 0, 0, 100));
                panel.setBorder(BorderFactory.createLineBorder(Color.GREEN, 3));
                panel.add(button);
                pane.add(panel, 2);

            }
        });
        frame.setContentPane(pane);
        frame.setVisible(true);
    }
    private static void final4(){
        JFrame frame =new JFrame("final4");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(0,0);
        class MyPanel extends JComponent{
            ImageIcon icon;
            MyPanel(ImageIcon icon){
                this.icon  = icon;
                JLabel label = new JLabel(icon);
                this.setLayout(null);
                label.setLocation(0,0);
                label.setSize( label.getPreferredSize());
                this.add(label);
            }
            Point point;

            public void setPoint(Point point) {
                this.point = point;
                this.repaint();
            }

            @Override
            protected void paintChildren(Graphics g) {
                super.paintChildren(g);
                int x, y, w, h;
                x = this.getInsets().left;
                y = this.getInsets().top;
                w = this.getWidth() - (this.getInsets().left + this.getInsets().right);
                h = this.getHeight() - (this.getInsets().top + this.getInsets().bottom);
                Graphics2D gg = (Graphics2D)g.create();
                gg.setComposite( AlphaComposite.getInstance(AlphaComposite.SRC_OVER,0.2f));
                //gg.setColor( new Color(0,0,0,0));
                gg.fillRect(x,y,w,h);
                if ( point != null){
                    gg.setColor( Color.RED);
                    int cw, ch;
                    cw = ch = 20;
                    int cx, cy;
                    cx = (int)point.getX() - cw/2;
                    cy = (int)point.getY()- ch/2;
                    gg.fillOval(cx,cy,cw,ch);
                    System.out.println("Point drawned");
                }
                gg.dispose();
            }
        };
        ImageIcon icon = new ImageIcon("C:\\Users\\RANA1947\\Desktop\\gif1.gif");
        File file = new File("C:\\Users\\RANA1947\\Desktop\\gif1.jpg");
        MyPanel rootpanel  = new MyPanel(icon);
        rootpanel.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int x, y;
                x= e.getX();
                y = e.getY();
                MyPanel panel = (MyPanel)e.getSource();
                panel.setPoint(new Point(x,y));
                System.out.println("clicked detected");
                if ( ! file.exists())
                    try {
                        file.createNewFile();
                    }catch( Exception ee){
                        System.out.println("Exception caught : "+ ee.getMessage());
                    }

                BufferedImage image = new BufferedImage(frame.getWidth(), frame.getHeight(),BufferedImage.TYPE_INT_RGB);
                Graphics g = image.getGraphics();
                frame.paint(g);
                try {
                    ImageIO.write(image, "jpg", file);
                    System.out.println("Successfully written to the file");
                }catch( Exception ee){
                    System.out.println("Error occurred while writing to the file : "+ ee.getMessage());
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        frame.getGlassPane().setVisible(true);
        System.out.println("is opaque :"+ frame.getGlassPane().isOpaque());
        JLabel label = new JLabel("This is content pane");
        label.setFont( new Font(Font.SERIF , Font.BOLD, 40));
        frame.setContentPane(label);
        frame.setGlassPane(rootpanel);
        frame.setVisible(true);

    }

    private static void final5(){
        JFrame frame= new JFrame("final5");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700,700);
        frame.setLocation(0,0);
        JLabel bglabel = new JLabel(new ImageIcon("C:\\Users\\RANA1947\\Desktop\\convo.jpg"));
        frame.setContentPane(bglabel);
        frame.getContentPane().setLayout(null);
        JButton showpane = new JButton("Show Glass Pane");
        showpane.setSize( showpane.getPreferredSize());
        int w, h;
        w= frame.getWidth();
        h =frame.getHeight();
        showpane.setLocation(w/2-showpane.getWidth()/2 , h/2-showpane.getHeight()/2);
        bglabel.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.out.println("Clicked onto the label");
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
        frame.getContentPane().add(showpane);
        JButton hidepane = new JButton("Hide Pane");
        hidepane.setSize( hidepane.getPreferredSize());
        class MyComponent extends JComponent{
            Image image;
            MyImageObserver observer;
            MyComponent( Image image){
                this.image = image;
                observer = new MyImageObserver(this);
                this.addMouseListener(new MouseListener() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        System.out.println("Clicked onto the component");
                    }

                    @Override
                    public void mousePressed(MouseEvent e) {

                    }

                    @Override
                    public void mouseReleased(MouseEvent e) {

                    }

                    @Override
                    public void mouseEntered(MouseEvent e) {

                    }

                    @Override
                    public void mouseExited(MouseEvent e) {

                    }
                });
            }

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                int x, y , w, h;
                x = this.getInsets().left;
                y= this.getInsets().top;
                w = this.getWidth() - (this.getInsets().left + this.getInsets().right);
                h = this.getHeight() - (this.getInsets().top + this.getInsets().bottom);
                Graphics2D gg = (Graphics2D)g.create();
                gg.drawImage(this.image, x,y,w,h,observer);
                gg.dispose();
                System.out.println("Image painted at x,y,w,h :"+ x + ", " + y + " , " + w + " , "+ h);
            }

            class MyImageObserver implements ImageObserver{
                MyComponent comp;
                MyImageObserver( MyComponent comp){
                    this.comp = comp;
                }
                @Override
                public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {
                    comp.repaint();
                    return true;
                }
            }
        }
        showpane.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                BufferedImage image = new BufferedImage( frame.getContentPane().getWidth(), frame.getContentPane().getHeight(),BufferedImage.TYPE_INT_RGB);
                Graphics gg = image.getGraphics();
                frame.getContentPane().paint(gg);
                BlurImageFilter filter = new BlurImageFilter(7);
                Image im = Toolkit.getDefaultToolkit().createImage(new FilteredImageSource(image.getSource(),filter));
                MediaTracker tracker = new MediaTracker(frame);
                tracker.addImage(im,1);
                try{
                    tracker.waitForID(1);
                }catch( Exception ee){
                    System.out.println("Exception caught : "+ ee.getMessage());
                }
                File file = new File("C:\\Users\\RANA1947\\Desktop\\file.jpg");
                if ( !file.exists())
                    try{
                        file.createNewFile();
                    }catch( Exception ee){
                        System.out.println("Exception caught while creating file : "+ ee.getMessage());
                    }

                gg.drawImage(im,0,0,im.getWidth(null),im.getHeight(null),null);
                gg.dispose();
                try{
                    ImageIO.write(image,"jpg",file);
                }catch( Exception ee){
                    System.out.println("Exception caught " + ee.getMessage());
                }
                MyComponent comp = new MyComponent(image);
                comp.setLayout(null);
                comp.setSize(frame.getContentPane().getWidth(), frame.getContentPane().getHeight());
                JLabel label = new JLabel(new ImageIcon("C:\\Users\\RANA1947\\Desktop\\gif4.gif"));
                label.setSize(label.getPreferredSize());
                label.setLocation(50,50);
                comp.add(label);
                //comp.add(hidepane);
                int hx, hy;
                hx = comp.getWidth()/2 - label.getHeight()/2;
                hy = comp.getHeight()/2 - label.getHeight()/2;
                label.setLocation(hx,hy);
                frame.setGlassPane(comp);
                frame.getGlassPane().setVisible(true);

                // image has been drawned successfully
            }
        });
        hidepane.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.getGlassPane().setVisible(false);
            }
        });

        frame.setVisible(true);
    }

    private static class BlurImageFilter extends ImageFilter {
        int matsize;
        BlurImageFilter (int matsize){
            this.matsize = matsize;
            if ( matsize < 3)
                matsize = 3;
            if ( matsize %2 ==0)
                matsize = matsize + 1;
            System.out.println("Final matsize : "+ matsize);
        }
        int savedWidth ,savedHeight;
        int[] savedPixels;
        ColorModel model;
        @Override
        public void setDimensions(int width, int height) {
            consumer.setDimensions(width, height);
            savedHeight = height;
            savedWidth = width;
            savedPixels = new int[savedWidth * savedHeight];
        }

        @Override
        public void setColorModel(ColorModel model) {
            consumer.setColorModel(ColorModel.getRGBdefault());
            this.model =model;
        }

        @Override
        public void setPixels(int x, int y, int w, int h, ColorModel model, byte[] pixels, int off, int scansize) {
            //super.setPixels(x, y, w, h, model, pixels, off, scansize);
            int row, column ;
            for ( int r = 0 ; r < h; r++){
                row = r + y;
                for ( int c = 0; c < w ; c++){
                    column = c + x;
                    savedPixels[row*savedWidth + column] = pixels[r*scansize + c];
                }
            }
        }

        @Override
        public void setPixels(int x, int y, int w, int h, ColorModel model, int[] pixels, int off, int scansize) {
            //super.setPixels(x, y, w, h, model, pixels, off, scansize);
            int row, column ;
            for ( int r = 0 ; r < h; r++){
                row = r + y;
                for ( int c = 0; c < w ; c++){
                    column = c + x;
                    savedPixels[row*savedWidth + column] = pixels[r*scansize + c];
                }
            }
        }

        @Override
        public void setProperties(Hashtable<?, ?> props) {
            consumer.setProperties(props);
        }

        @Override
        public void setHints(int hints) {
            consumer.setHints(hints);
        }

        @Override
        public void imageComplete(int status) {
            //super.imageComplete(status);
            if ( ( (status & ImageFilter.SINGLEFRAMEDONE) | ( status & ImageFilter.STATICIMAGEDONE ) ) !=0){
                // Bluring the image
                int[] newPixels = new int[savedWidth * savedHeight];
                int half = matsize /2;
                for ( int r  = 0; r < savedHeight ; r++) {
                    for (int c = 0; c < savedWidth; c++) {
                        int red, green , blue;
                        red = green = blue = 0;
                        for ( int i = -half ; i <= half ;i++){
                            int px,py;
                            for ( int j = -half; j <=half ; j++){
                                px = c+j;
                                py = r+i;
                                if ( (px >= 0 && px < savedWidth) && ( py >= 0 && py < savedHeight) ){
                                    red +=    this.model.getRed(savedPixels[py*savedWidth + px]);
                                    green += this.model.getGreen(savedPixels[py*savedWidth + px]);
                                    blue += this.model.getBlue(savedPixels[py*savedWidth + px]);
                                }
                                else{
                                    //System.out.println("out of boundary for r :"+ r + " c :"+ c);
                                }
                            }
                        }
                        red = ( red /(matsize * matsize) ) % 256;
                        blue = ( blue/(matsize* matsize) ) % 256;
                        green = (green / (matsize* matsize) ) %256;
                        Color color = new Color(red,green,blue);
                        newPixels[r*savedWidth + c] = color.getRGB();
                    }
                }
                int[] temp = new int[savedWidth];
                for ( int r = 0; r < savedHeight ; r++){
                    for ( int c= 0; c < savedWidth ; c++)
                        temp[c] = newPixels[r*savedWidth +c];
                    consumer.setPixels(0,r,savedWidth,1,ColorModel.getRGBdefault(),temp,0,savedWidth);
                }
                System.out.println("Done ");
            }
            else{
                System.out.println("What the fuck");
            }
            consumer.imageComplete(status);

        }
    }

    private static void final6(){
        JFrame frame = new JFrame("final6");
        frame.setSize( 600,600);
        frame.setLocation(0,0);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ImageIcon icon  = new ImageIcon("C:\\Users\\RANA1947\\Desktop\\msg.jpg");
        ImageFilter filter = new BlurImageFilter(7);
        Image image = Toolkit.getDefaultToolkit().createImage(new FilteredImageSource(icon.getImage().getSource(),filter));
        /*MediaTracker tracker = new MediaTracker(frame.getContentPane());
        tracker.addImage(image,1);
        try{
            tracker.waitForID(1);
        }catch( Exception e){
            System.out.println("Exception caugt : "+ e.getMessage());
        }*/
        JLabel label = new JLabel(new ImageIcon(image));
        frame.setContentPane(label);

        frame.setVisible(true);
    }
}
