import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
public class WindowListenerDemo {
    static JFrame frame;
    static JTextArea area;
    static int order = 0;
    public static void main(String[] args) {
        frame = new JFrame("JFrame Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        area = new JTextArea();
        area.setEditable(false);
        frame.setContentPane(area);
        MyListener listener = new MyListener();
        frame.addWindowFocusListener(listener);
        frame.addWindowListener(listener);
        frame.addWindowStateListener(listener);
        frame.setVisible(true);
    }

    public static class MyListener implements WindowListener , WindowFocusListener , WindowStateListener{
        @Override
        public void windowStateChanged(WindowEvent e) {
            System.out.println("Window stated changed to : " + e.toString() + " order : "+ order);
            area.append("Window state changed to : "+ e.toString() + " order : " + order + "\n");
            order ++;
        }

        @Override
        public void windowGainedFocus(WindowEvent e) {
            System.out.println("Window gained focus : "+ order);
            area.append("Window gained focus : " + order + "\n");
            order ++;
        }

        @Override
        public void windowLostFocus(WindowEvent e) {
            System.out.println("Window lost focus : "+ order);
            area.append("window lost focus : "+ order + "\n");
            order ++;
        }

        @Override
        public void windowActivated(WindowEvent e) {
            area.append("windowActivated :" +order + "\n");
            System.out.println("Window Activated :"+ order);
            order ++;
        }

        @Override
        public void windowClosed(WindowEvent e) {
            area.append("Window closed :"+ order + "\n");
            System.out.println("Window closed :"+ order);
            order ++;
        }

        @Override
        public void windowClosing(WindowEvent e) {
            area.append("Before Window Closing " + order + "\n");
            System.out.println("Before window closing:" + order);
            order ++;
            frame.dispose();
        }

        @Override
        public void windowDeactivated(WindowEvent e) {
            area.append("Window Deativated :"+ order + "\n");
            System.out.println("Window Deactivated :"+ order);
            order++;
        }

        @Override
        public void windowDeiconified(WindowEvent e) {
            area.append("Window Deiconified :"+ order + "\n");
            System.out.println("Window Deiconified :"+ order);
            order++;
        }

        @Override
        public void windowIconified(WindowEvent e) {
            area.append("Window Iconified :"+ order + "\n");
            System.out.println("Window Iconified :"+ order);
            order++;
        }

        @Override
        public void windowOpened(WindowEvent e) {
            area.append("Window opened :" + order + "\n");
            System.out.println("Window opened " + order);
            order ++;
        }
    }
}
