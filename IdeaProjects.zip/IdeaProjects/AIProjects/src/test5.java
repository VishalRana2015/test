import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.time.LocalDateTime;
import java.util.*;
public class test5  {
    public static void main(String[] args) {
       test7();
    }
    public static void test8(){
        Date date  = Calendar.getInstance().getTime();
        System.out.println(date);
        System.out.println(date.getTime());
        System.out.println(date.getMonth());
        System.out.println(date.getDay());
        LocalDateTime time = LocalDateTime.now();
        System.out.println("Local Date time :"+ time);
        System.out.println("Month :"+ time.getMonth());
        System.out.println("hour:minutes:seconds :"+ time.getHour()+":"+ time.getMinute()+":"+time.getSecond());

    }
    public static void test7(){
        JFrame frame = new JFrame("Disposable Frame on focus lost Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setUndecorated(true);
        frame.setSize(400,600);
        int sw, sh;
        sw = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        sh = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        frame.setLocation(sw/2 -200,sh/2-300);
        JLabel label = new JLabel();
        label.setBackground(Color.ORANGE);
        label.setOpaque(true);
        frame.setContentPane(label);

        frame.setVisible(true);

        frame.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {

            }

            @Override
            public void focusLost(FocusEvent e) {
                if ( e.getSource() instanceof JFrame){
                    JFrame source = (JFrame)e.getSource();
                    System.out.println("Going to dispose the frame");
                    MyThread thread = new MyThread(source);
                    thread.start();
                }
            }
        });
    }
    static class MyThread extends Thread{
        JFrame comp;
        public MyThread(JFrame comp){
            this.comp = comp;
        }

        @Override
        public void run() {
            int w , h;
            w = comp.getWidth();
            h = comp.getHeight();
            float ratio;
            int sx, sy;
            int sw, sh;
            sw = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
            sh = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();

            ratio = (float)h/(float)w;
            while ( w > 0){
                h = h-10;
                w= (int)( h / ratio);
                sx = sw/2 -w/2;
                sy = sh/2 - h/2;
                comp.setLocation(sx,sy);
                comp.setSize(w,h);
                comp.repaint();
                try {
                    Thread.sleep(2);
                }catch( Exception e){
                    System.out.println("Exception caugth :");
                }
            }
            System.out.println("Taking exit from run");
            comp.dispose();
        }

    }
    public static void test5(){
        JFrame frame =new JFrame("test 5");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel  = new JPanel();
        MyLayout ml = new MyLayout();
        panel.setLayout(ml);
        JButton next = new JButton("Nextgjhg");
        JButton exit = new JButton("Exit");
        JButton help = new JButton("Help");
        JButton back = new JButton("Back");
        panel.add(next,MyLayout.NEXT);
        panel.add(exit,MyLayout.EXIT);
        panel.add(help,MyLayout.HELP);
        panel.add(back,MyLayout.BACK);

        panel.setBackground(Color.ORANGE);
        JPanel panel2 =new JPanel();
        panel2.setLayout(new BoxLayout(panel2,BoxLayout.X_AXIS));
        panel2.add(panel);
        frame.setContentPane(panel2);
        frame.setVisible(true);
    }
    public static void test6(){
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        MyComponent comp = new MyComponent();

        JPanel panel = new JPanel(){

            ImageIcon icon;

            public void setIcon(ImageIcon icon) {
                this.icon = icon;
            }
            public Icon getIcon(){
                return this.icon;
            }
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D gg = (Graphics2D)g.create();
                int width = 100;
                int height = 100;
                int arcWidth = 50;
                int arcHeight = 50;
                gg.setColor(Color.BLACK);
                float[] dashpattern ={5,5};
                float dash_phase  = 2f;
                ImageIcon icon  = new ImageIcon("C:\\Users\\RANA1947\\IdeaProjects\\AIProjects\\Images\\batman.jpg");

                gg.drawLine(50,30,150,30);
                gg.drawLine(50,100,50+arcWidth/2,100);
                gg.drawLine(50 + arcWidth/2, 50,50+arcWidth/2,150);
                float length , arclength , arcdashlength;
                length = 2*width + 2*height - 2*arcWidth -2*arcHeight + (3.14f * (arcWidth/2 + arcHeight/2));
                arclength = (length/10.4f);
                arcdashlength = (0.3f* arclength);
                dashpattern[0]  = arclength;
                dashpattern[1]= arcdashlength;
                dash_phase = 0;
                gg.setColor(new Color(210,255, 240));
                gg.fillRect((int)g.getClipBounds().getX(),(int)g.getClipBounds().getY(),(int)g.getClipBounds().getWidth(),(int)g.getClipBounds().getHeight());

                System.out.println("length :"+ length);
                System.out.println("arclength : "+ arclength  + "arcdashlength : "+ arcdashlength);
                BasicStroke bs = new BasicStroke(2,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND,0,dashpattern,dash_phase);
                gg.setStroke(bs);
                gg.setColor(Color.GREEN);
                gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                //gg.drawRoundRect(50,50,width,height,arcWidth , arcHeight);
                if( icon != null){
                    gg.setClip(new RoundRectangle2D.Float(50,50,width,height,arcWidth,arcHeight));
                    BufferedImage image = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
                    Graphics2D bg = (Graphics2D)image.getGraphics();
                    Image i = icon.getImage();
                    bg.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                    bg.drawImage(i,0,0,image.getWidth(),image.getHeight(),0,0,icon.getIconWidth(),icon.getIconHeight(),null);
                    bg.dispose();
                    ImageIcon icon2 = new ImageIcon(image);
                     System.out.println("width :"+ width + " height :"+ height);
                    gg.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                    gg.setRenderingHint(RenderingHints.KEY_DITHERING,RenderingHints.VALUE_DITHER_ENABLE);
                    gg.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION , RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
                    gg.drawImage(image,50,50,50+width,50+height,0,0,image.getWidth(),image.getHeight(),null);
                }
                gg.setClip(g.getClipBounds());
                //gg.setComposite(AlphaComposite.DstAtop);
                gg.setStroke(new BasicStroke(2,BasicStroke.CAP_ROUND,BasicStroke.CAP_ROUND));
                gg.setColor(Color.WHITE);
                gg.drawRoundRect(50,50,width,height,arcWidth,arcHeight);
                gg.setColor(Color.CYAN);

                gg.dispose();
            }
        };
        frame.setContentPane(panel);
        frame.setVisible(true);
    }
    static class MyComponent extends JComponent{
        MyComponent(){
            super();
        }
    }
}
