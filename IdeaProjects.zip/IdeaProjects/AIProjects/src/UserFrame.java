import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.*;

public class UserFrame extends JFrame{
    UserObject object;
    public UserFrame(UserObject object ){
        super("Instant Messaging App");
        this.object  = object;
        this.setSize( 500, 500);
        this.setLocation( 50 , 0);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        initialize();
    }
    public void initialize(){
        JPanel panel = new JPanel();
        JLabel label = new JLabel();
        String s = object.getUserID() ;
        label.setText( s);
        panel.add(label);
        this.setContentPane(panel);
    }

}
