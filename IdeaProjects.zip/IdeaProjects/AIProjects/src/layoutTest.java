import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class layoutTest {
    public static void main(String[] args) {
        test3();
    }
    public static void test4(){
        JFrame frame= new JFrame("Box Layout Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel = new JPanel();
        Component comp  = new Component();
        comp.setPreferredSize(new Dimension(300,400));
        comp.setMinimumSize(new Dimension(200,300));
        comp.setMaximumSize(new Dimension(400,450));
        panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
        panel.add(comp);
        frame.setContentPane(panel);
        frame.setVisible(true);
    }
    public static void test2(){
        JFrame frame = new JFrame("layoutTest");
        frame.setSize(new Dimension(500,500));
        frame.setLocation(50,0);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        TestPanel testpanel = new TestPanel();
        testpanel.setLayout(new MyLayout());
        testpanel.add(new JButton("Help"),MyLayout.HELP);
        testpanel.add(new JButton("Go to Next"),MyLayout.NEXT);
        testpanel.add(new JButton("Back"),MyLayout.BACK);
        testpanel.add(new JButton("Exit"),MyLayout.EXIT);
        JPanel panel2= new JPanel();
        panel2.setLayout(new BoxLayout(panel2,BoxLayout.Y_AXIS));
        panel2.add(testpanel);
        frame.setContentPane(panel2);
        frame.setVisible(true);
    }
    public static void test1(){
        JFrame frame = new JFrame("MyPanel");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        MyPanel panel = new MyPanel();
        panel.setLayout(new MyLayout());
        panel.add(new JButton("Help"),MyLayout.HELP);
        panel.add(new JButton("Go to Next"),MyLayout.NEXT);
        panel.add(new JButton("Back"),MyLayout.BACK);
        panel.add(new JButton("Exit"),MyLayout.EXIT);
        JPanel panel2 = new JPanel();
        panel2.setLayout(new BoxLayout(panel2,BoxLayout.Y_AXIS));
        panel2.add(panel);
        frame.setContentPane(panel2);
        frame.setVisible(true);
    }
    static public void test3(){
        JFrame frame = new JFrame("normal panel demo");
        frame.setSize(500,500);
        frame.setLocation(50,0);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK,5));
        panel.add(new JButton("Hello wordld what are you these days"));
        panel.add(new JButton("Hello world 2"));
        panel.add(new JButton("Hello world2"));
        JPanel panel2 = new JPanel();
        panel2.setLayout(new BoxLayout(panel2,BoxLayout.Y_AXIS));
        panel2.add(panel);
        frame.setContentPane(panel2);
        frame.setVisible(true);
    }
}
class TestPanel extends JComponent{
    TestPanel(){
        this.setBorder(BorderFactory.createLineBorder(Color.BLACK));
    }

    @Override
    public Dimension getMinimumSize() {
        Dimension d = super.getMinimumSize();
        System.out.println("Returning minimum size of testpanel:" + d);
        return d;
    }

    @Override
    public Dimension getMaximumSize() {
        Dimension d = super.getMaximumSize();
        System.out.println("Returning maximum Size of testpanel :"+d);
        return d;
    }

    @Override
    public Dimension getPreferredSize() {
        Dimension d = super.getPreferredSize();
        System.out.println("Returning preferredSize of testpanel: "+ d);
        return d;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        System.out.println("TestPanel this width , height :"+this.getWidth() + ","+ this.getHeight());
    }
}

class MyPanel extends JPanel {
    public MyPanel(){
        this.setBorder(BorderFactory.createLineBorder(Color.BLACK));
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        System.out.println("MyPanel current width,height :"+this.getWidth()+","+this.getHeight());
    }

    @Override
    public Dimension getMinimumSize() {
        Dimension d = super.getMinimumSize();
        System.out.println("MyPanel : minimumSize :"+ d);
        return d;
    }

    @Override
    public Dimension getMaximumSize() {
        Dimension d=  super.getMaximumSize();
        System.out.println("MyPanel : maximumSize :" + d);
        return d;
    }

    @Override
    public Dimension getPreferredSize() {
        Dimension d = super.getPreferredSize();
        System.out.println("MyPanel : preferredSize :"+d);
        return d;
    }
}
class Component extends JComponent{
    Component(){

    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.ORANGE);
        int x,  y , w,h;
        x = (int)g.getClipBounds().getX();
        y = (int)g.getClipBounds().getY();
        w = this.getWidth();
        h = this.getHeight();
        g.fillRoundRect(x,y,w,h,50,50);
        g.setColor(Color.BLACK);
        g.drawString(this.getWidth() +","+this.getHeight(),1,10 );
    }
}