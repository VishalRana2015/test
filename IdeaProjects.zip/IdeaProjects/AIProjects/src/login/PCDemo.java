package login;

import javax.swing.*;
import java.util.*;
import java.util.function.Consumer;

public class PCDemo {
    static private class PC{
        int item;
        boolean  available =false; // gives the status whether the item is available to consume or not
        public void produe(){
            System.out.println("Produced item");
            item = (int)(Math.random()*100+ 1);
            available= true;
        }
        public void consume(){
            if ( available) {
                System.out.println("Item Consumed" + item);
                item = 0;
                available =false;
            }
            else
                System.out.println("No item is available to consume");

        }
    }

    static private class ProducerThread extends Thread{
        PC pc;
        ProducerThread(PC pc){
            this.pc = pc;
        }
        @Override
        public void run() {
            while(true){
                synchronized (pc){
                    pc.produe();
                    try{
                        pc.notify();
                        pc.wait();
                        Thread.sleep( (int)Math.random() * 3000);
                    }
                    catch( Exception e){
                        System.out.println("Exception caught :"+ e.getMessage());
                    }
                }
            }
        }
    }
    static private class ConsumerThread extends Thread{
        PC pc;
        ConsumerThread(PC pc){
            this.pc = pc;
        }

        @Override
        public void run() {
            while(true){
                synchronized (pc){
                    pc.consume();
                    pc.notify();

                    try {
                        pc.wait();
                        Thread.sleep((int) Math.random() * 3000);
                    }
                    catch( Exception e){
                        System.out.println("Exception caught in consumer thread");
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        PC pc = new PC();
        ProducerThread producer  = new ProducerThread(pc);
        ConsumerThread consumer  = new ConsumerThread(pc);
        producer.start();
        consumer.start();

    }
}
