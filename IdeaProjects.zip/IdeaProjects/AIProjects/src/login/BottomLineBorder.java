package login;
import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.border.*;
public class BottomLineBorder extends EmptyBorder{
    Color color = Color.BLACK;
    public BottomLineBorder(int top, int left , int bottom, int right){
        super(top,left,bottom,right);
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public Color getColor() {
        return color;
    }

    @Override
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        //super.paintBorder(c, g, x, y, width, height);

        //System.out.println("In paint component's border method x, y , w, h "+ x + "," + y + ", "+ width + ","+ height);
         Graphics2D gg = (Graphics2D)g.create();
         gg.setColor(this.getColor());
         gg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
         gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
         gg.fillRect(x,height -this.getBorderInsets(c).bottom, width , this.getBorderInsets(c).bottom);
         gg.dispose();

    }
}