package login;
import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.util.*;
import java.awt.event.*;
import java.util.List;

public class SwingWorkerExample {
    private static class Task extends SwingWorker<Void,Integer> {
        @Override
        protected Void doInBackground() throws Exception {
            for (int i =0; i < 10; i ++){
                System.out.println("Executing int the thread :"+ Thread.currentThread().getName());
                publish(i);
                try {
                    Thread.sleep(1000);
                }catch( Exception e){
                    System.out.println("Exception caught :"+ e.getMessage());
                }
            }
            System.out.println("doInBackground Done");
            return null;
        }

        @Override
        protected void done() {
            System.out.println("Done ");
        }

        @Override
        protected void process(List<Integer> chunks) {
            int i = chunks.get(chunks.size() - 1);
            System.out.println("In Process Method :" + i);
        }
    }

    public static void main(String[] args) {
        Task task = new Task();
        System.out.println("Main Thread :"+ Thread.currentThread().getName());
        task.execute();
        SwingUtilities.invokeLater(task);
        SwingUtilities.invokeLater(new Task());
    }
}
