package login;
import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
public class MyComponent extends JComponent{
    public MyComponent(){
        this.setPreferredSize(new Dimension(100,100));
        this.setMinimumSize(new Dimension(100,100));
        this.setMaximumSize(new Dimension(200,200));
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        int x, y , w, h;
        x = (int)g.getClipBounds().getX();
        y = (int)g.getClipBounds().getY();
        w = (int)g.getClipBounds().getWidth();
        h = (int)g.getClipBounds().getHeight();
        Graphics2D gg = (Graphics2D)g.create();
        gg.setColor(Color.ORANGE);
        gg.fillRoundRect(x,y,w,h,10,10);
        gg.dispose();
    }
}
