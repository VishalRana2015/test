package login;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;

public class Main extends JFrame implements ActionListener {
    private final JButton startButton, stopButton;
    private JScrollPane scrollPane = new JScrollPane();
    private JList listBox = null;
    private DefaultListModel listModel = new DefaultListModel();
    private final JProgressBar progressBar;
    private mySwingWorker swingWorker;

    public Main() {
        super();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(new GridLayout(4, 1));
        startButton = makeButton("Start");
        stopButton = makeButton("Stop");
        stopButton.setEnabled(false);
        progressBar = makeProgressBar(0, 99);
        listBox = new JList(listModel);
        scrollPane.setViewportView(listBox);
        add(scrollPane);
        pack();
        setVisible(true);
    }

    private class mySwingWorker extends
            javax.swing.SwingWorker<ArrayList<Integer>, Integer> {
        @Override
        protected ArrayList<Integer> doInBackground() {
            if (javax.swing.SwingUtilities.isEventDispatchThread()) {
                System.out.println("javax.swing.SwingUtilities.isEventDispatchThread() returned true.");
            }
            ArrayList<Integer> list = new ArrayList<Integer>();
            for (int i = 0; i < 100; i++) {
                try {
                    Thread.sleep(1000);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (isCancelled()) {
                    System.out.println("SwingWorker - isCancelled");
                    return list;
                }
                publish(new Integer(i));
                list.add(i);
            }
            return list;
        }

        @Override
        protected void process(java.util.List<Integer> progressList) {
            if (!javax.swing.SwingUtilities.isEventDispatchThread()) {
                System.out.println("javax.swing.SwingUtilities.isEventDispatchThread() + returned false.");
            }
            Integer percentComplete = progressList.get(progressList.size() - 1);
            progressBar.setValue(percentComplete.intValue());
        }

        @Override
        protected void done() {
            if (!javax.swing.SwingUtilities.isEventDispatchThread()) {
                System.out.println("javax.swing.SwingUtilities.isEventDispatchThread() + returned false.");
            }
            try {
                ArrayList<Integer> results = get();
                for (Integer i : results) {
                    listModel.addElement(i.toString());
                }
            } catch (Exception e) {
                System.out.println("Caught an exception: " + e);
            }
            startButton();
        }

    }

    private JButton makeButton(String caption) {
        JButton b = new JButton(caption);
        b.setActionCommand(caption);
        b.addActionListener(this);
        getContentPane().add(b);
        return b;
    }

    private JProgressBar makeProgressBar(int min, int max) {
        JProgressBar progressBar1 = new JProgressBar();
        progressBar1.setMinimum(min);
        progressBar1.setMaximum(max);
        progressBar1.setStringPainted(true);
        progressBar1.setBorderPainted(true);
        getContentPane().add(progressBar1);
        return progressBar1;
    }

    private void startButton() {
        startButton.setEnabled(true);
        stopButton.setEnabled(false);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if ("Start" == null ? e.getActionCommand() == null : "Start".equals(e
                .getActionCommand())) {
            startButton.setEnabled(false);
            stopButton.setEnabled(true);
            (swingWorker = new mySwingWorker()).execute();
        } else if ("Stop" == null ? e.getActionCommand() == null : "Stop".equals(e
                .getActionCommand())) {
            startButton.setEnabled(true);
            stopButton.setEnabled(false);
            swingWorker.cancel(true);

            swingWorker = null;
        }
    }

    public static void main(String[] args) {

        Thread thread = new Thread(){
            boolean stop = false;
            public void run(){
                int i =0;
                while ( !stop) {
                    System.out.println("i : " + i++);
                    try {
                        Thread.currentThread().sleep(1000);
                    } catch (Exception e) {
                        System.out.println("Exception caught :" + e.getMessage());
                    }
                }
            }
        };
        JFrame frame = new JFrame("Start and stop thread example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,50);
        JPanel panel = new JPanel();
        JButton start =new JButton("Start");
        start.setActionCommand("start");
        JButton stop = new JButton("stop");
        stop.setActionCommand("stop");
        start.setEnabled(false);
        stop.setEnabled(true);
        thread.start();
        ActionListener listener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if ( e.getActionCommand().equalsIgnoreCase("start")){
                    thread.resume();
                    stop.setEnabled(true);
                    start.setEnabled(false);
                }
                else{
                    thread.suspend();
                    start.setEnabled(true);
                    stop.setEnabled(false);
                }
            }
        };
        start.addActionListener(listener);
        stop.addActionListener(listener);
        panel.add(start);
        panel.add(stop);
        frame.setContentPane(panel);
        frame.setVisible(true);
        frame.pack();
    }
}
