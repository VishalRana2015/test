

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;

public class LAS extends JFrame  {
    public LAS(int fw, int fh){
        super();
        this.setUndecorated(true);
        this.setSize(fw,fh);
        int cx, cy ,w,h;
        w = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        h = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        System.out.println("w : " + w + " h :"+ h);
        cx =(w-fw)/2;
        cy = (h-fh)/2;
        this.setLocation(cx,cy);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel mainpanel = new JPanel();
        mainpanel.setLayout(new CardLayout());
        JPanel loginpanel, signuppanel;
        loginpanel = loginPanel(fw,fh);
        signuppanel = signuppanel(fw,fh);
        mainpanel.add(signuppanel,"signup");
        this.setContentPane(mainpanel);
        this.setVisible(true);

    }
    static public JPanel loginPanel(int fw, int fh){
            JPanel loginpanel = new JPanel();
            loginpanel.setLayout(null);
            JLayeredPane lbpane = new JLayeredPane();
            System.out.println(lbpane.getLayout());
            lbpane.setBackground(new Color(158,0,0));
            JTextField emailf = new JTextField();
            JLabel emaill = new JLabel();
            emailf.setLocation(10,100);
            emailf.setSize(250,20);
            emailf.addKeyListener(new KeyListener() {
                @Override
                public void keyTyped(KeyEvent e) {

                }

                @Override
                public void keyPressed(KeyEvent e) {
                    JTextField f =(JTextField)e.getSource();

                }

                @Override
                public void keyReleased(KeyEvent e) {
                    JTextField f = (JTextField)e.getSource();
                    if( f.getText().length() == 0) {
                        emaill.setText(" UserID@vmail.com");
                    }
                    else{
                        emaill.setText("");
                    }
                }
            });
            if ( emailf.getText().length() ==0)
                emaill.setText(" UserID@vmail.com");
            else
                emaill.setText("");
            emaill.setForeground(new Color(170,170,170));
            emailf.setOpaque(false);
            emaill.setLocation(10,100);
            emaill.setSize(250,20);
            emailf.setForeground(new Color(255,255,255));
            lbpane.add(emailf,1);
            lbpane.add(emaill,0);
            lbpane.setLocation(0,0);
            lbpane.setSize(fw,fh);
            lbpane.setVisible(true);
            lbpane.setOpaque(true);



            // Similarly for password
            JPasswordField passwordf = new JPasswordField();
            passwordf.setEchoChar('*');
            passwordf.setOpaque(false);
            passwordf.setForeground(new Color(255,255,255));
            passwordf.setSize(250,20);
            passwordf.setLocation(10,150);
            lbpane.add(passwordf,1);

            JLabel passwordl = new JLabel();
            passwordl.setForeground(new Color(255,255,0));
            passwordl.setLocation(10,150);
            passwordl.setSize(250,20);
            if ( passwordf.getPassword().length ==0){
                passwordl.setText(" Password");
            }
            else
                passwordl.setText(" ");
            passwordf.addKeyListener(new KeyListener() {
                @Override
                public void keyTyped(KeyEvent e) {

                }

                @Override
                public void keyPressed(KeyEvent e) {

                }

                @Override
                public void keyReleased(KeyEvent e) {
                    JPasswordField f = (JPasswordField)e.getSource();
                    if ( f.getPassword().length ==0){
                        passwordl.setText(" Password");
                    }
                    else
                        passwordl.setText(" ");
                }
            });
            lbpane.add(passwordl,0);


            // Adding statuspanel
            JLabel statusl = new JLabel ();
            statusl.setForeground(new Color(0,0,128));
            statusl.setSize(300,20);
            statusl.setOpaque(false);
            statusl.setLocation(10,200);
            statusl.setText("Invalid user name or password");
            lbpane.add(statusl,0);

            // creating submit Button
            JButton button = new JButton("Submit");
            button.setText("Submit");
            button.setLocation(50,250);
            button.setSize(100,30);
            lbpane.add(button,1);
            loginpanel.add(lbpane);


            JLabel loginlabel =new JLabel("Login");
            //loginlabel.setHorizontalTextPosition(JLabel.TRAILING);
            loginlabel.setHorizontalTextPosition(JLabel.RIGHT);
            loginlabel.setHorizontalAlignment(JLabel.CENTER);
            loginlabel.setVerticalTextPosition(JLabel.CENTER);
            loginlabel.setSize(350,50);
            loginlabel.setLocation(0,450);
            loginlabel.setBackground(new Color(0,0,100));
            loginlabel.setOpaque(true);
            loginlabel.setForeground(new Color(255,255,255));
            lbpane.add(loginlabel);
            return loginpanel;

    }
    public static JPanel signuppanel( int fw, int fh){
        JPanel sp = new JPanel();
        sp.setLayout(null);
        JLayeredPane lfpane  = new JLayeredPane();
        lfpane.setLayout(null);
        lfpane.setBackground(new Color(230,230,230));
        lfpane.setSize(fw,fh);
        lfpane.setLocation(0,0);
        JLabel wmsg = new JLabel("Welcome");
        wmsg.setFont( new Font(Font.SANS_SERIF,Font.BOLD,28));
        FontMetrics fm = wmsg.getFontMetrics(wmsg.getFont());
        int w = fm.stringWidth("Welcome");
        int h = wmsg.getFont().getSize() + 2;
        wmsg.setLocation(10,10);
        wmsg.setSize(w,h);
        JLabel wmsg2 = new JLabel();
        wmsg2.setText("glad to see you!");
        wmsg2.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,16));
        wmsg2.setLocation(10,10+h+5);
        wmsg2.setSize( wmsg2.getFontMetrics(wmsg2.getFont()).stringWidth(wmsg2.getText()), wmsg2.getFont().getSize()+wmsg2.getFontMetrics(wmsg2.getFont()).getDescent());
        lfpane.add(wmsg2,0);
        lfpane.add(wmsg,0);
        JTextField namef = new JTextField();
        namef.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,14));
        JPasswordField pf = new JPasswordField();
        pf.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,14));
        JPasswordField cpf  = new JPasswordField();
        cpf.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,14));
        pf.setEchoChar('*');
        cpf.setEchoChar('*');
        namef.setSize(300,30);
        namef.setLocation(25,70);
        namef.setBorder( new MyBorder(Color.BLACK,2));
        lfpane.add(namef);
        sp.add(lfpane);
        return sp;
    }

    static class MyBorder  extends LineBorder{
        Color linecolor;
        int thickness;
        public MyBorder(Color linecolor , int thickness){
            super(linecolor,thickness);

        }

        public void setLinecolor(Color linecolor) {
            this.linecolor = linecolor;
        }

        public Color getLinecolor() {
            return linecolor;
        }


        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D gg =(Graphics2D)g.create();
            System.out.println(gg.getClip());
            System.out.println(gg.getClipBounds());
            gg.setColor(Color.YELLOW);
            gg.drawRect((int)gg.getClipBounds().getX(),(int)gg.getClipBounds().getY(),(int)gg.getClipBounds().getWidth(),(int)gg.getClipBounds().getHeight());
            gg.dispose();
        }
    }
    public static void main(String[] args) {
        new LAS(350,500);
    }
}
