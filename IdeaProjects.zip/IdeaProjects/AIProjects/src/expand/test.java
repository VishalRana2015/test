package expand;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class test {
    public static void main(String[] args) {
            test3();
    }
    public static void test3(){
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel = new JPanel();
        panel.add(new JButton("Hello world 1"));
        panel.add(new JButton("pirates of the SEA."));
        frame.setContentPane(panel);
        panel.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.out.println("Mouse clicked on panel");
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        frame.setVisible(true);
    }
    public static void test2(){
        JFrame frame = new JFrame("demo");
        frame.setSize(500,500);
        frame.setLocation(50,0);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel();
        MyComponent comp = new MyComponent(Color.ORANGE,300,100,500,400);
        comp.setMaximumSize(new Dimension(600,200));
        //comp.setPreferredSize(new Dimension(1,1));
       panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
        panel.setLayout(new GridBagLayout());
        GridBagConstraints cont = new GridBagConstraints();
        cont.gridx = 0;
        cont.gridy = 0;
        cont.gridwidth= 1;
        cont.gridheight = 1;

        panel.add(comp,cont);
        cont.gridy=1;
        //panel.add( new MyButton("Hello world I am tired now . what to do next "),cont);
        frame.setContentPane(panel);

        frame.setVisible(true);
    }
    static class MyButton extends JButton{
        MyButton(String text){
            super(text);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            System.out.println("Button width "+ this.getWidth());
        }
    }
    public static void test1() {
        JFrame frame = new JFrame("Expandable Menu Demo");
        frame.setSize(500,500);
        frame.setLocation(50,0);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel =new JPanel();
        panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
        ExpandableMenu menu = new ExpandableMenu("Set Color Properties");
        MyComponent comp1 = new MyComponent(Color.CYAN,200,20,300,40);
        MyComponent comp2 =new MyComponent(Color.RED,150,40,250,100);
        MyLabel label = new MyLabel("Hello world how are you doint well here");
        menu.add(label);
        menu.add(comp1);
        menu.add(comp2);
        panel.add(menu);
        frame.setContentPane(panel);

        frame.setVisible(true);
    }
    static class MyLabel extends JLabel{
        MyLabel(String title){
            super(title);
        }

        @Override
        public void paint(Graphics g) {
            System.out.println("label paint method : w,h "+ this.getWidth()+","+ this.getHeight());
            super.paint(g);

        }
    }
    static class MyComponent extends JComponent{
        Color color;
        String text;
        MyComponent( Color color, int minw, int minh , int prew, int preh ){
            this.color = color;
            this.setMinimumSize(new Dimension(minw, minh ));
            this.setPreferredSize(new Dimension( prew, preh));
            this.setMaximumSize(new Dimension(prew,preh));
            text= "Hello world what are you doint these days. Tell me because I am messing up ";
        }

        @Override
        public void setSize(Dimension d) {
            System.out.println("setSize called MyComponent:"+d);
            super.setSize(d);
        }

        @Override
        public void setBounds(Rectangle r) {
            super.setBounds(r);
            System.out.println("set bounds called component :"+ r);
        }

        @Override
        public void setBounds(int x, int y, int width, int height) {
            System.out.println("Set Bounds called component :"+ width +","+ height);
            super.setBounds(x, y, width, height);
        }

        @Override
        protected void paintComponent(Graphics g) {
            System.out.println("paint method of it's child called");
            super.paintComponent(g);
            Graphics2D gg = (Graphics2D)g.create();
            gg.setColor(this.color);
            int x, y , w, h;
            x = (int)g.getClipBounds().getX();
            y = (int)g.getClipBounds().getY();
            w = this.getWidth();
            h = this.getHeight();
            System.out.println("this width,height "+ w+","+h);
            gg.fillRoundRect(x,y,this.getWidth(),this.getHeight(), 50,50);
            gg.setColor(Color.BLACK);
            gg.drawString(this.getWidth() + "",x+1,y+10);
            gg.dispose();
        }

        @Override
        public Dimension getPreferredSize() {
            Dimension d  = super.getPreferredSize();
            System.out.println("Returning MyComponent's object PreferredSize" +d);
            return d;
        }

        @Override
        public Dimension getMinimumSize() {
            Dimension d= super.getMinimumSize();
            //System.out.println("Returning MyComponent's object Minimum Size" + d);
            return d;
        }

        @Override
        public Dimension getMaximumSize() {
            //System.out.println("returning MyComponent's object maximum Size");
            return super.getMaximumSize();
        }
    }
}
