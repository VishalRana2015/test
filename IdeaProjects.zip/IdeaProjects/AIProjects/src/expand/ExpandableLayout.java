package expand;
import java.awt.*;

public class ExpandableLayout  implements LayoutManager{
    int leftOffset, vgap , hgap;
    public ExpandableLayout(){
        leftOffset = 10;
        vgap = 2;
        hgap = 4;
    }

    public int getLeftOffset() {
        return leftOffset;
    }

    public int getVgap() {
        return vgap;
    }

    public int getHgap() {
        return hgap;
    }

    @Override
    public Dimension preferredLayoutSize(Container parent) {
        int w= 0, h =0;
        int nmembers = parent.getComponentCount();
        Dimension predim;
        for ( int i =0; i < nmembers;i++){
            Component comp = parent.getComponent(i);
            predim = comp.getPreferredSize();
            w  =(int) Math.max(w,predim.getWidth());
            h += this.getVgap()+ (int)predim.getHeight();
        }
        //System.out.println("maximum width :"+w);
        w += this.getLeftOffset()+ this.getHgap() * 2  + parent.getInsets().left + parent.getInsets().right;
        h += this.getVgap() + parent.getInsets().top + parent.getInsets().bottom;
        Dimension d = new Dimension(w,h);
        //System.out.println("Returning preferredLayoutSize :"+ d);
        return d;
    }

    @Override
    public Dimension minimumLayoutSize(Container parent) {
        int w= 0, h =0;
        int nmembers = parent.getComponentCount();
        Dimension mindim;
        for ( int i =0; i < nmembers;i++){
            Component comp = parent.getComponent(i);
            mindim = comp.getPreferredSize();
            w  =(int) Math.max(w,mindim.getWidth());
            h += this.getVgap()+ (int)mindim.getHeight();
        }
        w += this.getLeftOffset()+ this.getHgap() * 2  + parent.getInsets().left + parent.getInsets().right;
        h += this.getVgap() + parent.getInsets().top + parent.getInsets().bottom;
        Dimension d = new Dimension(w,h);
       // System.out.println("returning minimumLayoutSize :"+ d);
        return d;
    }

    @Override
    public void addLayoutComponent(String name, Component comp) {
        this.getHgap();
    }

    @Override
    public void removeLayoutComponent(Component comp) {

    }

    @Override
    public void layoutContainer(Container parent) {
        // for each component do this
        int members = parent.getComponentCount();
        Dimension predim;
        int x, y ;
        x= this.getLeftOffset()+ parent.getInsets().left + this.getHgap();
        y= parent.getInsets().top + this.getVgap();
        System.out.println("nmembers :"+ members);
        for ( int i =0;i < members; i++){
            Component comp = parent.getComponent(i);
            predim  = comp.getPreferredSize();
            comp.setLocation(x,y);
            comp.setSize((int)predim.getWidth(),(int)predim.getHeight());
            y= y+(int)predim.getHeight() + this.getVgap();
        }
        System.out.println("Components drawn successfully");
    }
}
