package expand;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.util.*;
public class ExpandableMenu extends JComponent {
    boolean expanded;
    String title;
    ExpandableMenu(String title){
        this.title = title;
        expanded = false;
        this.setBorder( new ExpandableBorder(BorderFactory.createLineBorder(Color.YELLOW,10),title));
        this.setLayout(new ExpandableLayout());
    }
    public boolean isExpanded() {
        return expanded;
    }

    public void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }

    @Override
    public Dimension getMaximumSize() {
        if ( this.getLayout() != null){
            return this.getLayout().preferredLayoutSize(this);
        }
        return super.getMaximumSize();
    }

    @Override
    public Dimension getMinimumSize() {
        if ( this.getLayout() != null)
            return this.getLayout().minimumLayoutSize(this);
        return super.getMinimumSize();
    }

    @Override
    public Dimension getPreferredSize() {
        if ( this.getLayout() != null){
            return this.getLayout().preferredLayoutSize(this);
        }
        return super.getPreferredSize();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        int x, y , w, h;

        x = (int)g.getClipBounds().getX();
        y = (int)g.getClipBounds().getY();
        w = (int)g.getClipBounds().getWidth();
        h = (int)g.getClipBounds().getHeight();
        g.setColor(Color.ORANGE);
        g.fillRoundRect(x,y,w,h,10,10);
        g.setColor(Color.BLACK);
        g.drawString(this.getWidth()+"",x+this.getWidth()/2,10);
    }

    @Override
    protected void paintChildren(Graphics g) {
       // System.out.println("Paint Children method called");

        int x, y , w, h;
        w = (int)g.getClipBounds().getWidth() - (this.getInsets().left + this.getInsets().right);
        h = (int)g.getClipBounds().getHeight() - (this.getInsets().top + this.getInsets().bottom);
        x = (int)g.getClipBounds().getX() + this.getInsets().left;
        y = (int)g.getClipBounds().getY() + this.getInsets().top;
        Graphics gg = g.create();
        gg.setClip(x,y,w,h);
        super.paintChildren(gg);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);

    }

    @Override
    protected void paintBorder(Graphics g) {
//        System.out.println("paint border called");
        super.paintBorder(g);
    }
}
