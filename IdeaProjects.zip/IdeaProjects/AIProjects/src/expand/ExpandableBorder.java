package expand;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.GeneralPath;
import javax.swing.event.*;

public class ExpandableBorder extends TitledBorder {
    String title;
    boolean expand;
    public ExpandableBorder(Border border,String title){
        super(border, title + "     ");
        this.title = title;
        expand = false;
    }

    @Override
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        super.paintBorder(c, g, x, y, width, height);
        int sx, sy , w, h;
        sx= this.getBorderInsets(c).left  + c.getFontMetrics(c.getFont()).stringWidth(title+"  ");
        sy = 0;
        w = c.getFontMetrics(c.getFont()).stringWidth("   ");
        h = this.getBorderInsets(c).top;
        Graphics2D gg = (Graphics2D)g.create();
        if ( c instanceof ExpandableMenu) {
            ExpandableMenu menu   = (ExpandableMenu)c;
            if (menu.isExpanded())
                drawUpArrow(gg, sx, sy, w, h);
            else
                drawBelowArrow(gg, sx, sy, w, h);
        }
        gg.dispose();
//        System.out.println("Border Painted");
    }
    private void drawBelowArrow(Graphics2D gg, int x, int y , int w, int h){
        GeneralPath path = new GeneralPath(GeneralPath.WIND_EVEN_ODD);
        path.moveTo(x+0.75*w , y+0.6*h);
        path.quadTo(0.75*w+x,0.01*h+y,0.01*w+x,0.01*h+y);
        path.quadTo(0.5*w+x,0.01*h+y,0.5*w+x,0.6*h+y);
        path.lineTo(0.26*w+x,0.6*h+y);
        path.lineTo(0.62*w+x,0.99*h+y);
        path.lineTo(0.98*w+x,0.6*h+y);
        path.closePath();
        gg.setColor(new Color(0,100,0));
        gg.fill(path);
        gg.setColor(Color.BLACK);
        //gg.draw(path);

    }
    private void drawUpArrow(Graphics2D gg , int x, int y , int w, int h){
        GeneralPath path = new GeneralPath(GeneralPath.WIND_EVEN_ODD);
        path.moveTo(0.5*w + x, 0.4*h + y);
        path.quadTo(0.5*w+x,0.99*h+y, 0.01*w + x,0.99*h+y);
        path.quadTo(0.75*w+x,0.99*h+y,0.75*w+x,0.4*h+y);
        path.lineTo(0.99*w +x , 0.4*h+ y);
        path.lineTo(0.62*w + x, 0.01*h + y);
        path.lineTo(0.26*w+x, 0.4*h+ y);
        path.closePath();
        gg.setColor(new Color(0,100,0));
        gg.fill(path);
        gg.setColor(Color.BLACK);
        //gg.draw(path);
    }
}
