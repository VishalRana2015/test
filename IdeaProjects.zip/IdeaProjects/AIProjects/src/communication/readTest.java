package communication;
import java.io.*;
public class readTest {
    public static void main(String[] args) {
            try{
                File file = new File("C:\\Users\\RANA1947\\IdeaProjects\\AIProjects\\src\\communication\\Hello");
                FileInputStream input  = new FileInputStream(file);
                for ( int  i =0 ; i < 20 ; i++)
                    System.out.println(input.read());
            }catch( Exception e){
                System.out.println("Exception caught " + e.getMessage());

            }
    }
}
