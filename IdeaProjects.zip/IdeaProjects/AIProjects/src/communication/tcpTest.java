package communication;
import java.net.*;
import java.io.*;
public class tcpTest {
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(20000);
            int i =1;
            System.out.println("Server Started...");
            while( true){
                Socket socket = serverSocket.accept();
                ListiningThread thread = new ListiningThread(socket,"Thread"+ i,"Client"+i);
                System.out.println("Starting thread...");
                thread.start();
                i++;
            }
        }catch(Exception e){
            System.out.println("Exception caught "+ e.getMessage());
            System.out.println("taking exit.");
        }
    }
    static class ListiningThread extends Thread{
        String threadName , clientID;
        Socket socket;

     ListiningThread(Socket socket , String threadName, String clientID){
         super(threadName);
         this.threadName = threadName;
         this.socket = socket;
         this.clientID = clientID;
         System.out.println("Listining thread ,"+threadName+" object initiazed "+ socket);
     }

        @Override
        public void run() {
            super.run();
            // This method is responsible for listining the data comming from the device connected to the port until exit entered.
            try {
                InputStream stream = socket.getInputStream();
                byte[] b = new byte[10];
                // read operation returns -1 if there is no input available in the device or file, in case of tcp connection input stream
                // it will wait for the closing of the connection before returning -1
                int len;
                while( (len =stream.read(b,0,10)) != -1){
                    String s = new String(b,0,len);
                    //System.out.println("len :"+len);
                    for ( int  i=0; i < len; i++)
                        System.out.print("  a["+i+"]:"+b[i]);
                    System.out.println(clientID + ","+threadName +" :"+ s);
                    System.out.println("available :"+ stream.available());
                }
                System.out.println("Exited from the loop");
            }catch(Exception e){
                System.out.println("Exception caught in run method of "+ this.threadName + e.getMessage());
            }
        }
    }
}
