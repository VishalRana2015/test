package communication;

import java.net.ServerSocket;
import java.net.*;
import java.io.*;
public class SendToClient {
    public static void main(String[] args) {
        try{
            ServerSocket serverSocket =new ServerSocket(20000);
            System.out.println("Server Started...");
            int i =1;
            while ( true){
                Socket socket = serverSocket.accept();
                MyThread thread  = new MyThread(socket , i);
                thread.start();
                i++;
            }
        }catch(Exception e){
            System.out.println("Exception caught :"+ e.getMessage());
        }
    }
    static class MyThread extends Thread{
        String clientID , threadID;
        Socket socket;
        MyThread(Socket socket , int i ){
            this.socket = socket;
            this.clientID  = "Client"+i;
            this.threadID = "thread"+i;
            System.out.println("Thread Created");
        }

        @Override
        public void run() {
            super.run();
            // Running the thread method
            System.out.println("Running the thread");
            try {
                System.out.println("Is connected :"+ socket.isConnected());
                System.out.println("is closed :"+ socket.isClosed());
                System.out.println("is bound :"+ socket.isBound());

                InputStreamReader reader = new InputStreamReader(socket.getInputStream());
                OutputStreamWriter writer = new OutputStreamWriter(socket.getOutputStream());
                char[] buf = new char[100];
                int len;
                while ((len = reader.read(buf)) != -1) {
                    String s = new String(buf, 0, len);
                    String ss= threadID + ","+ clientID+ " :"+ s;
                    System.out.println(ss);
                    Thread.sleep(5000);
                    writer.write(ss);
                    writer.flush();
                }
            }
            catch( Exception e){
                System.out.println("Exception caught :"+e.getMessage());
                if ( socket.isConnected()){
                    System.out.println("Is connected");
                }
                else
                    System.out.println("Not Connected");
                System.out.println("is bound :"+ socket.isBound());
                System.out.println("is connected :"+ socket.isConnected());
                System.out.println("is closed :"+ socket.isClosed());
            }
        }
    }
}

