import javax.swing.*;
import java.awt.*;
import javax.swing.border.LineBorder;
import javax.swing.event.*;
import java.awt.event.*;
import javax.swing.border.*;

public class FocusTraversalDemo {

    public static void main(String[] args) {
        JFrame frame = new JFrame("FocusTravrsal Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel = new JPanel();
        MyComponent comp1 = new MyComponent("comp1",Color.RED);
        comp1.setSize(100,100);
        comp1.setLocation(50,50);
        panel.add(comp1);
        MyComponent comp2 = new MyComponent( "Comp2", Color.GREEN);
        comp2.setSize(100,100);
        comp2.setLocation(200,50);
        comp1.setPreferredSize(new Dimension(100,100));
        comp2.setPreferredSize( new Dimension(100,100));
        panel.add(comp2);
        comp1.setFocusable(true);
        comp2.setFocusable(true);
        System.out.println("traversal policy for the panel :" + panel.getFocusTraversalPolicy());
        frame.setContentPane(panel);
        frame.setVisible(true);
    }

    private static class MyComponent extends JComponent{
        private String compName;
        private static FocusBorder commonBorder;
        static {
            // All Components will have this border as their default border.
            commonBorder = new FocusBorder(2,2,2,2 , new Color(0,0,0));
        }
        MyComponent(String compName, Color backgroundColor){
            this.compName = compName;
            this.setBackground(backgroundColor);
            this.setBorder(commonBorder);
            this.setFocusable(true);
        }

        public String getCompName() {
            return compName;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int x, y , w, h;
            w = this.getWidth();
            h =this.getHeight();
            x = (int)g.getClipBounds().getX();
            y = (int)g.getClipBounds().getY();
            Graphics2D gg = (Graphics2D)g.create();
            gg.setColor(this.getBackground());
            gg.fillRoundRect(x,y,w,h,10,10);
        }
    }
    private static class FocusBorder extends EmptyBorder{
        Color coolor, focusColor;
        FocusBorder(int top , int left , int bottom, int right ,Color color){
            super(top ,left, bottom, right);
            this.coolor= color;
            this.focusColor= new Color(120,0,0);
        }
        public FocusBorder( int top , int left , int bottom , int right , Color color , Color focusColor){
            super(top,left, bottom, right);
            this.coolor = color;
            this.focusColor = focusColor;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            super.paintBorder(c, g, x, y, width, height);
            int top , left , bottom , right;
            top =this.getBorderInsets().top;
            left = this.getBorderInsets().left;
            bottom = this.getBorderInsets().bottom;
            right = this.getBorderInsets().right;
            Graphics2D gg = (Graphics2D)g.create();
            if ( c.hasFocus()) {
                gg.setColor(focusColor);
            }else {
                gg.setColor(this.coolor);
            }
            gg.fillRect(x,y,width,top);
            gg.fillRect(x,y,left,height);
            gg.fillRect(x,y+height-bottom,width,bottom);
            gg.fillRect(x+width-right,y,right,height);
            gg.dispose();
        }
    }
}
