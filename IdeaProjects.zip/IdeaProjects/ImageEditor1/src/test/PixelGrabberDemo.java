package test;
import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.*;
import java.awt.image.*;
public class PixelGrabberDemo {
    public static void main(String[] args) {
        JFrame frame =new JFrame("PixelGrabber Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,50);
        JPanel panel = new JPanel();
        panel.setLayout(null);
        MyComponent comp = new MyComponent("C:\\Users\\RANA1947\\Desktop\\logo.jpg");
        ImageIcon icon = new ImageIcon( "C:\\Users\\RANA1947\\Desktop\\logo.jpg");
        Image image = icon.getImage();

        comp.setSize(400,400);
        comp.setLocation(0,0);
        panel.add(comp);

        frame.setContentPane(panel);
        frame.setVisible(true);
    }
    private static class MyComponent extends JComponent{
        Image image;
        Image ni, vi , vfi, nfi;
        public MyComponent(String filename){
            ImageIcon icon = new ImageIcon("C:\\Users\\RANA1947\\Desktop\\img3.jpg");
            image = icon.getImage();
            int iw, ih ;
            iw = image.getWidth(null);
            ih = image.getHeight(null);
            if ( image == null){
                System.out.println("Image is null");
                return;
            }
            PixelGrabber grabber = new PixelGrabber(image,0,0,iw,ih,true);
            long time = System.currentTimeMillis();
            try{
                grabber.grabPixels();
            }
            catch(Exception e){
                System.out.println("Exception thrown :" + e.getMessage());
            }
            time = System.currentTimeMillis() - time;
            System.out.println("Time taken  to grab pixels (ms):"+ time);
            int[] pixels = (int[])grabber.getPixels();
            System.out.println("println pixels grabbed");
            MemoryImageSource mni = new MemoryImageSource(iw,ih,pixels,0,iw);
            ni = createImage(mni);
            // creating nfi
            int index = 0;
            int[] nfipixels = new int[iw * ih];
            for ( int r = 0; r < ih ; r++){
                for ( int c = iw -1; c  >= 0; c--){
                    nfipixels[index++] = pixels[r*iw + c];
                }
            }
            MemoryImageSource mnfi = new MemoryImageSource(iw, ih, nfipixels , 0, iw);
            nfi = createImage(mnfi);
            index = 0;
            int [] vipixels  = new int[iw * ih];
            for ( int c = iw-1 ; c >=0 ; c--){
                for ( int r = 0 ; r < ih ; r++){
                    vipixels[index++] = pixels[r*iw + c];
                }
            }
            MemoryImageSource mvi = new MemoryImageSource(ih,iw,vipixels,0,ih);
            vi = createImage(mvi);

            int[] vfipixels = new int[iw * ih];
            index = 0;
            for ( int c = 0; c < iw ; c++){
                for ( int r = 0; r < ih; r++){
                    vfipixels[index++] = pixels[r*iw + c];
                }
            }
            MemoryImageSource mvfi = new MemoryImageSource(ih,iw,vfipixels,0,ih);
            vfi = createImage(mvfi);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            System.out.println("Paint Component Called");
            int w, h;
            w= this.getWidth();
            h= this.getHeight();
            Graphics2D gg = (Graphics2D)g.create();
            if ( ni != null){
                gg.drawImage(ni,0,0,w/2,h/2,null);
            }
            if ( vi != null){
                gg.drawImage(vi ,w/2 + 1 , 0,w/2,h/2,null);
            }
            if ( nfi != null){
                gg.drawImage(nfi , 0, h/2+1, w/2, h/2 , null);
            }
            if ( vfi != null){
                gg.drawImage(vfi , w/2 + 1, h/2 + 1 , w/2 , h/2 , null);
            }
        }
    }
}
