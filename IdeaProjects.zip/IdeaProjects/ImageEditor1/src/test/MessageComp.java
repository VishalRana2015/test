package test;
import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.security.SecureRandom;
import java.util.*;
public class MessageComp extends JComponent{

    MessageComp(){
        super();
        internalPadding = new Insets(2,2,2,2);
        this.setBorder( BorderFactory.createLineBorder(Color.BLACK));
        lineIndent= 2;
        this.setFont( new Font(Font.SERIF,Font.PLAIN,16));
        setPreferredWidth(100);
    }
    String text;
    int pw, ph;// stands for preferredWidth and preferredHeight
    String[][] paraWord; // stands for paragraphWords
    Insets internalPadding ;
    int lineIndent ;
    public void setText(String text) {
        this.text = text;
        paraWord = getParaWord(this.text);
        setPreferredWidth(this.getPreferredWidth());
        repaint();
    }

    public int getPreferredWidth( ) {
        return pw;
    }

    public void setPreferredWidth(int pw){
        this.pw = pw;
        int mw = this.getFontMetrics(this.getFont()).stringWidth("mmmmmmmmmmmmmmmmmmmm");
        if ( this.pw < mw) // setting minimum Width of 20 m characters
            this.pw = mw;

        int ph = this.getPreferredHeight(pw);
        this.setSize(pw,ph);
        this.setPreferredSize(new Dimension(pw,ph));
        this.setMinimumSize(new Dimension(pw,ph));
        this.setMaximumSize(new Dimension(pw,ph));
    }

    // This is the message Component therefore we don't have to worry about about indent and paragraph indent just keep the things loosely.
    private int getPreferredHeight(int width ){
        int nl= 1; // represents no of lines

        int aw, w;
        w= width - (this.getInsets().left + this.getInternalPadding().left + this.getInternalPadding().right + this.getInsets().right);
        aw = w;
        // aw will be decreased as we keep on pasting words on the same line
        if ( paraWord != null) {
            for ( int i =0; i < paraWord.length; i++){
                for ( int j =0; j < paraWord[i].length; j++){
                    System.out.println("paraWord["+ i + "]["+j+"] :"+ paraWord[i][j]);
                }
            }
            for (int i = 0; i < paraWord.length; i++) {

                for (int j = 0; j < paraWord[i].length; j++) {
                    if (paraWord[i][j].equalsIgnoreCase("\n")) {
                        nl = nl + 1;
                        aw = w;
                        continue;
                    }
                    int sw = this.getFontMetrics(this.getFont()).stringWidth(paraWord[i][j]);  // because this font will be used to paint the string
                    if (sw < aw) {
                        // This string can be painted in the current line
                        aw = aw - sw;
                    } else {
                        // We have to try to fit this string in the next line
                        if ( aw != w) {
                            nl = nl + 1;
                            aw = w;
                        }
                        while (sw > aw) {
                            sw = sw - w;
                            nl = nl + 1; // As soon as we increase the nl, we shifted to next empty line
                        }
                        aw = aw - sw; //
                    }

                }
            }
        }
        int height;
        int lw;
        lw = this.getFont().getSize() + this.lineIndent ;
        height = this.getInsets().top + this.getInternalPadding().top + this.getInsets().bottom + this.getInternalPadding().bottom + nl * lw;
        return height;
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setFont(this.getFont());
        paintText(g);
    }

    public Insets getInternalPadding() {
        return internalPadding;
    }

    private void paintText(Graphics g){
        Graphics2D gg = (Graphics2D)g.create();
        int ix, iy;
        ix = this.getInsets().left + this.getInternalPadding().left;
        iy = this.getInsets().top + this.getInternalPadding().top ;
        gg.setFont(this.getFont());
        System.out.println("In paint text method fontSize :"+ Math.random());
        gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        gg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        gg.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL , RenderingHints.VALUE_STROKE_NORMALIZE);
        gg.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        int x, y , lw , w;
        lw = this.getFont().getSize() + this.lineIndent;
        x = ix + this.getInsets().left + this.getInternalPadding().left;
        y = iy + this.getInsets().top + this.getInternalPadding().top + gg.getFontMetrics(gg.getFont()).getAscent();
        int aw;
        w= this.getWidth() - (this.getInsets().left + this.getInternalPadding().left + this.getInsets().right + this.getInternalPadding().right);
        aw = w; // Initially available width is save as total width available to paint the text

        for ( int i =0; i < paraWord.length; i++){

            for  (int j =0; j < paraWord[i].length;j++){
                if ( paraWord[i][j].equalsIgnoreCase("\n")){
                    aw =w;
                    y=y+ lw;
                    x = ix + this.getInternalPadding().left + this.getInsets().left;
                    continue;
                }
                int sw = gg.getFontMetrics(gg.getFont()).stringWidth(paraWord[i][j]);
                if ( sw < aw ){
                    // then the string can painted in the current line of available width
                    gg.drawString(paraWord[i][j] , x,y);
                    x = x + sw;
                    aw = aw -sw;
                }
                else{
                    //Then the string can't be painted in the available width of the current line , we have to shift it to the next line
                    if ( aw != w)
                        y = y + lw;
                    x = ix + this.getInsets().left + this.getInternalPadding().left; // Shifted to next line
                    aw = w;
                    String s = paraWord[i][j];
                    while( sw > aw){
                        int sl = getStringLengthofWidth(s,gg,aw);
                        System.out.println("sl :"+ sl);
                        String ss = s.substring(0,sl);
                        System.out.println("SubString :"+ ss);
                        gg.drawString(ss,x,y);
                        y = y + lw;
                        s = s.substring(sl,s.length());
                        sw= sw - aw;
                    }
                    if ( s!= null){
                        gg.drawString(s , x,y);
                        x = x+sw;
                        aw = aw -sw;
                    }
                    // endif
                }
                //end Else
            }
            // end inner loop for words
        }
        // end outer loop for words
        //String has been painted
    }

    private int getStringLengthofWidth( String s, Graphics2D gg , int w){
        boolean found = false;
        int l = s.length();
        for (int i =1; i <s.length(); i++){
            String ss = s.substring(0,i);
            int sw = gg.getFontMetrics(gg.getFont()).stringWidth(ss);
            if ( sw > w){
                l = i-1;
                break;
            }
        }
        return l;
    }

    // Following method have been tested and working as expected
    private String[] getStringArray(String[] ss , String seperator){
        int l =0;
        String temp[] , temp2[];
        boolean flag ;
        temp = new String[2*ss.length];
        for (int k =0; k < ss.length; k++){
            temp[l] = ss[k];
            if ( temp[l].equalsIgnoreCase(seperator) || temp[l].equalsIgnoreCase("")) {
                flag = true;
                temp[l] = seperator;
            }
            else {
                flag = false;
            }
            l++;
            if ( !flag && k!=(ss.length-1)){
                temp[l] = seperator;
                l++;
            }
        }
        temp2 = new String[l];
        for (int i =0; i <l ;i ++){
            temp2[i] = temp[i];
        }
        return temp2;
    }
    private  String[][] getParaWord(String s ){
        String[] ss = s.split("[\n]");
        String[] p = getStringArray(ss,"\n");

        String[][] pw = new String[p.length][];
        String[] temp;

        for (int i =0; i < p.length; i++){
            temp = p[i].split(" ");
            pw[i] = getStringArray(temp," ");
        }
        return pw;
    }
}
