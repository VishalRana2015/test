package test;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.util.*;
import java.awt.image.*;
public class IndexColorModelDemo {
    public static void main(String[] args) {
        JFrame frame = new JFrame("IndexColorModelDemo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel =new JPanel();
        panel.setLayout(null);
        MyComponent comp = new MyComponent(300,300);
        comp.setSize(300,300);
        comp.setLocation(50,0);
        panel.add(comp);
        frame.setContentPane(panel);
        JPanel panel2 = new JPanel();
        panel2.setLayout(null);
        ImageIcon icon = new ImageIcon("C:\\Users\\RANA1947\\Desktop\\family.jpg");

        RedComponent comp2 = new RedComponent(icon);
        comp2.setSize(400,400);
        comp2.setLocation(20,20);
        panel2.add(comp2);
        frame.setContentPane(panel2);
        ColorModel model = ColorModel.getRGBdefault();
        System.out.println("blue :"+ model.getBlue(1025));
        JPanel panel3 = new JPanel();
        JColorChooser chooser = new JColorChooser();
        panel3.add(chooser);
        // BasicPlayer
        frame.setContentPane(panel3);
        frame.setVisible(true);
    }
    private static class MyComponent extends JComponent{
        int ww, hh;
        Image image ;
        IndexColorModel model;
        MyComponent(int ww, int hh){
            this.ww = ww;
            this.hh = hh;
            int[] cmap = { Color.RED.getRGB(), Color.GREEN.getRGB(), Color.BLUE.getRGB(), Color.CYAN.getRGB() , Color.MAGENTA.getRGB() , Color.YELLOW.getRGB(), Color.WHITE.getRGB(), Color.BLACK.getRGB()};
            createNewImage();
            model = new IndexColorModel(3,8,cmap,0,true,-1,DataBuffer.TYPE_BYTE);
           seeModelInfo();
        }
        private void seeModelInfo(){
            System.out.println("Map Size :"+ model.getMapSize());
            int[] ar = model.getComponentSize();
            System.out.println("Component size");
            for (int i =0; i < ar.length;i++){
                System.out.print(ar[i]+ ",");
            }
            System.out.println();
            //System.out.println("Get Component Size :"+ model.getComponentSize());
            System.out.println("Pixel size :"+ model.getPixelSize());
            System.out.println("Get Transparency :"+ model.getTransparency());
            System.out.println("Trasparent Pixel :"+ model.getTransparentPixel());
        }
        private void createNewImage(){
            int length , rangeSize;

            length = 8;
            rangeSize = ww/ 8;
            int[] pixels = new int[ww*hh];
            int index =0;
            int temp;
            for ( int i =0; i < ww; i++){
                for ( int  j =0; j < hh; j++){
                    temp = j /rangeSize;
                    pixels[index++] = temp;
                }
            }
            MemoryImageSource mis = new MemoryImageSource(ww,hh,model,pixels,0,ww);
            image = createImage(mis);
            BufferedImage bimage  = new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_RGB);
            Graphics2D gg = (Graphics2D)bimage.getGraphics();
            gg.drawImage(image,0,0,image.getWidth(null),image.getHeight(null),null);
            gg.setColor(Color.BLACK);
            int x  , y;
            x = 0;
            y = 20;
            Font font = new Font(Font.SERIF,Font.BOLD,15);
            gg.drawString("RED",x,y);
            x += rangeSize;
            y= y+20;
            gg.drawString("GREEN",x,y);
            y =y+20;
            x += rangeSize;
            gg.drawString("BLUE",x,y);
            y = y+20;
            x += rangeSize;
            gg.drawString("CYAN",x,y);
            y =y+20;
            x += rangeSize;
            gg.drawString("MAGENTA",x,y);
            y = y+20;
            x += rangeSize;
            gg.drawString("YELLOW",x,y);
            y= y+20;
            x += rangeSize;
            gg.drawString("WHITE",x,y);
            y = y+20;
            x += rangeSize;
            gg.setColor(Color.WHITE);
            gg.drawString("BLACK",x,y);
            gg.dispose();
            image = bimage;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int x, y , w, h;
            w= this.getWidth() - (this.getInsets().left + this.getInsets().right);
            h = this.getHeight() - (this.getInsets().top + this.getInsets().bottom);
            x = (int)g.getClipBounds().getX() + this.getInsets().left;
            y= (int)g.getClipBounds().getY() + this.getInsets().top;
            if( image != null)
                g.drawImage(image,x,y,w,h,null);
            else
                System.out.println("Image is null");
        }
    }
    static class RedComponent extends JComponent{
        ImageIcon icon ;
        Image image;
        int[] pixels;
        int iw,ih;
        RedComponent(ImageIcon icon){
            this.icon = icon;
            iw = icon.getIconWidth();
            ih = icon.getIconHeight();
            image = icon.getImage();
            pixels = new int[iw * ih];
            PixelGrabber grabber = new PixelGrabber(image,0,0,iw,ih,true);
            try{
                grabber.grabPixels();
            }
            catch(Exception e){
                System.out.println("Exception caught while grabbing :"+ e.getMessage());
            }
            pixels = (int[])grabber.getPixels();
            for ( int i =0; i < pixels.length ; i++){
                pixels[i] = (pixels[i] | 0x0000ff);
            }
            MemoryImageSource mis = new MemoryImageSource(iw,ih,pixels,0,iw);
            image = createImage(mis);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int x, y , w, h;
            w = this.getWidth() - (this.getInsets().left + this.getInsets().right);
            h = this.getHeight() - (this.getInsets().top + this.getInsets().bottom);
            x = (int)g.getClipBounds().getX() + this.getInsets().left;
            y = (int)g.getClipBounds().getY() + this.getInsets().top;
            Graphics2D gg = (Graphics2D)g.create();
            if( image != null){
                gg.drawImage(image,0,0,w,h,null);
            }
            gg.dispose();
        }
    }
    static class HSVComponent extends ColorModel{
        HSVComponent(int bits){
            super(bits);
        }
        @Override
        public int getRed(int pixel) {
            return 0;
        }

        @Override
        public int getGreen(int pixel) {
            return 0;
        }

        @Override
        public int getBlue(Object inData) {
            return super.getBlue(inData);
        }

        @Override
        public int getBlue(int pixel) {
            return 0;
        }

        @Override
        public int getAlpha(int pixel) {
            return 0;
        }

    }
}
