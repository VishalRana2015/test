package test;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import javax.swing.text.Document;
import java.io.*;
public class mainTest {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);

        JPanel panel = fileMessageTest();


        frame.setContentPane(panel);
        frame.setVisible(true);

        /*JFrame frame2 = new JFrame("Frame2");
        frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame2.setSize(500,500);
        frame2.setLocation(50,0);
        JPanel panel2 = testMessageComp();

        frame2.setContentPane(panel2);
        frame2.setVisible(true);
*/
    }
    public static JPanel fileMessageTest(){
        JPanel panel = new JPanel();
        File file = new File("C:\\Users\\RANA1947\\Desktop\\family.jpg");
        FileMessage fm = new FileMessage(file);
        FileMessage fm2 = new FileMessage(new File("C:\\Users\\RANA1947\\Desktop\\family.jpg"));
        fm.setBorder( BorderFactory.createLineBorder(Color.BLACK));
        panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
        //panel.setLayout(new FlowLayout());
        fm.setAlignmentX(0.75f);
        fm2.setAlignmentX(0.0f);
        System.out.println("fm:alignmentX: " + fm.getAlignmentX());
        System.out.println("fm2 :alignmentX:"+ fm2.getAlignmentX());
        panel.add(fm);
       // panel.add(fm2);
        return panel;
    }
    public static JPanel ImageMessageTest(){
        JPanel panel = new JPanel();
        ImageIcon icon = new ImageIcon("C:\\Users\\RANA1947\\Desktop\\family.jpg");
        if ( icon == null)
            System.out.println("icon is null");
        else
            System.out.println("Icon is not null");
        ImageMessageComp comp = new ImageMessageComp(icon,300,200);
        comp.setLocation(50,50);
        comp.setBorder( BorderFactory.createLineBorder(Color.BLACK));
        panel.setLayout(null);
        panel.add(comp);

        return panel;
    }
    public static JPanel drawingTest(){
        JPanel panel  = new JPanel();
        class MyComponent extends JComponent{
            MyComponent(){

            }

            @Override
            public void paintAll(Graphics g) {
                super.paintAll(g);
                System.out.println("Paint all called");
            }

            @Override
            public void paintImmediately(int x, int y, int w, int h) {
                super.paintImmediately(x, y, w, h);
                System.out.println("Paint Immediately called");
            }

            @Override
            public void repaint(Rectangle r) {
                //super.repaint();
                //super.repaint(r);
            }

            @Override
            public void repaint(long tm, int x, int y, int width, int height) {
                //super.repaint();
                //super.repaint(tm, x, y, width, height);
            }

            @Override
            public void repaint(int x, int y, int width, int height) {
                //super.repaint();
                //super.repaint(x, y, width, height);
            }

            @Override
            public void repaint(long tm) {
                //super.repaint(tm);
            }

            @Override
            protected void paintComponent(Graphics g) {
                //super.paintComponent(g);
                int x, y , w, h;
                x = this.getInsets().left;
                y = this.getInsets().top;
                w = this.getWidth() - (this.getInsets().left + this.getInsets().right);
                h = this.getHeight() - ( this.getInsets().top + this.getInsets().bottom);
                String s1 = "Hello Wrodl";
                String s2 = "Hello world 2";
                System.out.println("x,y,w,h :"+ x + ", "+ y + ", "+ w + ", " + h);
                Graphics2D gg = ( Graphics2D)g.create();

                gg.clearRect(x,y,w,h);
                gg.setColor( new Color(255,0,0));
                gg.fillRect(x,y,w,h);
                gg.setColor(new Color(0,0,0));
                gg.drawString(s1,x,y+12);
                gg.drawString(s2,x,y+18);
                gg.dispose();
            }
        }
        MyComponent comp = new MyComponent();
        comp.setBorder( BorderFactory.createLineBorder(Color.BLACK));
        panel.setLayout(null);
        comp.setSize(200,200);
        comp.setLocation(50,50);
        panel.add(comp);
        return panel;
    }
    public static JPanel JTextAreaTest(){
        JPanel panel = new JPanel();
        JTextArea area = new JTextArea();
        area.setText("\"C:\\Program Files\\Java\\jdk-14.0.2\\bin\\java.exe\" -agentlib:jdwp=transport=dt_socket,address=127.0.0.1:57854,suspend=y,server=n -javaagent:C:\\Users\\RANA1947\\.IdeaIC2019.3\\system\\captureAgent\\debugger-agent.jar -Dfile.encoding=UTF-8 -classpath \"C:\\Users\\RANA1947\\IdeaProjects\\ImageEditor1\\out\\production\\ImageEditor1;C:\\Program Files\\JetBrains\\IntelliJ IDEA Community Edition 2019.3.3\\lib\\idea_rt.jar\" test.mainTest\n" +
                "Connected to the target VM, address: '127.0.0.1:57854', transport: 'socket'");
        area.setEditable(false);
        area.setWrapStyleWord(true);
        area.setLineWrap(true);
        area.setFont(new Font(Font.SERIF,Font.PLAIN,16));
        Document d = area.getDocument();

        area.setBackground(new Color(200,120,120));
        area.setOpaque(true);
        area.setColumns(17);
        panel.add(area);
        return panel;
    }
    public static JPanel testBorder(){
        JPanel panel = new JPanel();
        //panel.setLayout(null);
        MyComponent comp = new  MyComponent( Color.RED);
        comp.setSize(100,100);
        comp.setPreferredSize(new Dimension(100,100));
        comp.setLocation(50,50);
        Border border = MessageBorder.createBorderForSender();
        comp.setBorder(border);
        panel.add(comp);
        return panel;
        }
        public static JPanel testMessageComp(){
        JPanel panel = new JPanel();
        MessageComp comp = new MessageComp();
        String s = "C:\\Program Files\\Java\\jdk-14.0.2\\bin\\java.exe\" -agentlib:jdwp=transport=dt_socket,address=127.0.0.1:57393,suspend=y,server=n -javaagent:C:\\Users\\RANA1947\\.IdeaIC2019.3\\system\\captureAgent\\debugger-agent.jar -Dfile.encoding=UTF-8 -classpath \"C:\\Users\\RANA1947\\IdeaProjects\\ImageEditor1\\out\\production\\ImageEditor1;C:\\Program Files\\JetBrains\\IntelliJ IDEA Community Edition 2019.3.3\\lib\\idea_rt.jar\" test.mainTest\n" +
                "Connected to the target VM, address: '127.0.0.1:57393', transport: 'socket'";
        String s2 = "Java HotSpot(TM) 64-Bit Server VM warning: Sharing is only supported for boot loader classes because bootstrap classpath has been appended";
        String s3 = "llkalkdjfalksdjfalkdsjflaksdjflasdjfalksjfa;slkfja;sldfjas;";
        comp.setText(s);
        comp.setLocation(50,50);
        panel.setLayout(null);
        panel.add(comp);
        return panel;
        }
    private  static class MyComponent extends JComponent{

        MyComponent(Color color){
            super();
            this.setBackground(color);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int x, y, w, h;
            x = (int)g.getClipBounds().getX() + this.getInsets().left;
            y = (int)g.getClipBounds().getY() + this.getInsets().top ;
            w = this.getWidth() - (this.getInsets().left + this.getInsets().right);
            h = this.getHeight() - (this.getInsets().top + this.getInsets().bottom);
            Graphics2D gg = (Graphics2D)g.create();
            gg.setColor( this.getBackground());
            gg.fillRect(x,y,w,h);
            gg.dispose();

        }
    }
}
