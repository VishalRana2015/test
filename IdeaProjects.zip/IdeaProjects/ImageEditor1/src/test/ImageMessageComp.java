package test;
import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.*;
import java.awt.image.*;
public class ImageMessageComp extends JComponent {
    Image image;
    int cw, ch;
    Color shadeColor;
    int expandTo;
    MyImageObserver observer;
    ImageMessageComp(ImageIcon icon , int cw, int ch){
        super();
        this.setWidthAndHeight(cw,ch);
        observer = new MyImageObserver();
        this.shadeColor = Color.ORANGE;
        expandTo = 10;
        this.setImage(icon.getImage());
    }
    public void setWidthAndHeight( int cw, int ch){
        this.cw = cw;
        this.ch = ch;
        this.setSize(cw,ch);
        this.setPreferredSize(new Dimension(cw,ch));
        this.setMinimumSize(new Dimension(cw,ch));
        this.setMaximumSize( new Dimension(cw,ch));
    }
    public void setImage(Image image){
        int savedWidth, savedHeight;
        savedWidth = image.getWidth(null);
        savedHeight = image.getHeight(null);
        System.out.println("savedWidth :" + savedWidth + " savedHeigth :"+ savedHeight);
        double ratio = (double)savedWidth / (double)savedHeight;
        int dw, dh; // stands for displayableWidth and displayableHeight
        dw = (int)(ch/ratio);
        dh = (int)( cw/ratio);
        int iw, ih;
        if ( dh < ch){
            iw = cw;
            ih = dh;
        }
        else{
            ih= ch;
            iw= (int)(ih*ratio);
        }

        BufferedImage bimage = new BufferedImage(cw, ch, BufferedImage.TYPE_INT_RGB);

        Graphics2D gg = (Graphics2D)bimage.getGraphics();
        gg.setClip(0,0,cw,ch); // I was getting empty clip bounds I don't know why
        int x , y ,w , h;

        x = (int)gg.getClipBounds().getX();

        y = (int)gg.getClipBounds().getY();
        w = (int)gg.getClipBounds().getWidth();
        h = (int)gg.getClipBounds().getHeight();
        gg.setColor(Color.BLACK);
        gg.fillRect(x,y,w,h);
        int ix, iy;
        Color color;
        int red , green, blue;
        red = shadeColor.getRed();
        green = shadeColor.getGreen();
        blue = shadeColor.getBlue();
        ix = x + cw/2 -iw/2;
        iy = y + ch/2  -ih/2;
        gg.drawImage(image,ix,iy,iw,ih,observer);
        int alpha=255;
        double alphaDecay = 256.0 / (( this.expandTo/100.0 ) * ch);
        for ( int r = ch-2; r >=0; r--){
            color = new Color( red, green , blue , alpha);
            gg.setColor( color);
            gg.fillRect(0,r,cw,1);
            alpha = (int)(alpha - alphaDecay);
            if ( alpha <=0 )
                break;
        }
        gg.dispose();

        this.image = (Image)bimage;

    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D gg = (Graphics2D)g.create();
        int x , y , w, h;
        x = this.getInsets().left;
        y = this.getInsets().top;
        w = this.getWidth() - ( this.getInsets().left + this.getInsets().right);
        h = this.getHeight() - ( this.getInsets().top + this.getInsets().bottom);
        gg.drawImage(this.image, x,y,w,h,null);
        gg.dispose();
    }
    private class MyImageObserver implements ImageObserver{

        @Override
        public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {
            System.out.println("Image Observer called");
            if ( (infoflags & ImageObserver.FRAMEBITS) != 0)
                System.out.println("FrameBits are available");
            if ( (infoflags & ImageObserver.ALLBITS ) != 0)
                System.out.println("static image is done");
            if ( (infoflags & ImageObserver.WIDTH) != 0)
                System.out.println("Now width is available");
            if ( (infoflags & ImageObserver.HEIGHT ) != 0)
                System.out.println("Now Height is available");
            if ( (infoflags & ImageObserver.SOMEBITS) != 0)
                System.out.println("called for some bits");
            if ( (infoflags & ImageObserver.ABORT) != 0 )
                System.out.println("Abort");
            if ( (infoflags & ImageObserver.ERROR) != 0)
                System.out.println("Error");
            if (  ( (infoflags & ImageObserver.ALLBITS ) | ( infoflags & ImageObserver.FRAMEBITS) ) != 0)
                repaint();
            return true;
        }
    }
  /*  static private class CustomFilter extends ImageFilter{
        int savedWidth ,savedHeight;
        int filterWidth, filterHeight; // stands for filterWidth and filterHeight
        int[] savedPixels;
        ColorModel model;
        int hints;
        @Override
        public void setDimensions(int width, int height) {
            savedWidth = width;
            savedHeight = height;
            savedPixels = new int[ savedHeight * savedWidth];
        }

        @Override
        public void setColorModel(ColorModel model) {
            this.model = model;
        }

        @Override
        public void setHints(int hints) {
            this.hints = hints;
        }

        @Override
        public void setProperties(Hashtable<?, ?> props) {
            consumer.setProperties(props);
        }

        @Override
        public void setPixels(int x, int y, int w, int h, ColorModel model, int[] pixels, int off, int scansize) {
            //super.setPixels(x, y, w, h, model, pixels, off, scansize);
            int row, column;
            for ( int r = 0; r < h; r++){
                row = r + x;
                for ( int c = 0;  c< w; c++) {
                    column = c + y;
                    savedPixels[row* savedWidth + column] = pixels[r*scansize + c];
                }
            }

        }

        @Override
        public void setPixels(int x, int y, int w, int h, ColorModel model, byte[] pixels, int off, int scansize) {
            //super.setPixels(x, y, w, h, model, pixels, off, scansize);
            // We are ignoring for the moment the setPixels byte version of the method
        }

        @Override
        public void imageComplete(int status) {
            // This is the method where actual is taking place
            if (( ( status & ImageConsumer.IMAGEABORTED ) | ( status & ImageConsumer.IMAGEERROR) ) != 0)
                consumer.imageComplete(status);
            else{
                double ratio = savedWidth / savedHeight;
                int dw, dh; // stands for displayableWidth and displayableHeight
                dw = (int)(filterHeight/ratio);
                dh = (int)( filterWidth/ratio);
                int iw, ih;
                if ( dh < filterHeight){
                    ih = dh;
                    iw= filterWidth;
                }
                else{
                    ih= filterHeight;
                    iw= dw;
                }
                BufferedImage bimage = new BufferedImage(filterWidth, filterHeight, BufferedImage.TYPE_INT_RGB);
                Graphics2D gg = (Graphics2D)bimage.getGraphics();
                int x, y ,w , h;
                x = (int)gg.getClipBounds().getX();
                y = (int)gg.getClipBounds().getY();
                w = (int)gg.getClipBounds().getWidth();
                h = (int)gg.getClipBounds().getHeight();
                gg.setColor(Color.BLACK);
                gg.fillRect(x,y,w,h);
                int ix,iy;
                ix = x + w/2 -iw/2;
                iy= y + h/2 - ih/2;
                MemoryImageSource mis = new MemoryImageSource(savedWidth,savedHeight,savedPixels,0,savedWidth);
               // There seems to be too many problems with java
                Image image = Toolkit.getDefaultToolkit().createImage(mis);



            }
        }
    }
*/}
