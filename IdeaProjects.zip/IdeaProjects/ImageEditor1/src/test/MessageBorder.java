package test;
import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.border.*;
import java.awt.geom.*;
// This class has been tested and is ready to use.
public class MessageBorder extends EmptyBorder {
    static int arrowSize ;
    static int thickness;
    static Color backgroundColor;
    static{
        thickness  =2;
        arrowSize = 10; // all the border will use this arrow size
        backgroundColor  = new Color(0,0,0);
    }
    ;
    boolean forSender;
    private MessageBorder(int top, int left , int bottom , int right, boolean forSender){
        super(top,left, bottom, right);
        this.forSender = forSender;
    }
    @Override
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
       // super.paintBorder(c, g, x, y, width, height);
        // this method is responsible for painting the border around the component
        Graphics2D gg = (Graphics2D)g.create();
        GeneralPath exp = new GeneralPath(GeneralPath.WIND_EVEN_ODD);
        GeneralPath isp = new GeneralPath( GeneralPath.WIND_EVEN_ODD);
        int compdw, compdh; // stands for component displayable width and component displayable height
        JComponent comp = (JComponent)c;
        compdw = width - ( comp.getInsets().left + comp.getInsets().right);
        compdh = height - (comp.getInsets().top + comp.getInsets().bottom);
        if ( forSender){
            isp.moveTo(x+thickness , y + thickness);
            isp.lineTo( x + thickness + compdw , y + thickness);
            isp.lineTo(x + thickness + compdw , y+ thickness + compdh);
            isp.lineTo( x + thickness , y + thickness + compdh);
            isp.closePath();

            exp.moveTo( x + width , y);
            exp.lineTo( x ,y);
            exp.lineTo( x , y + height);
            exp.lineTo( x+width - arrowSize, y+ height);
            exp.lineTo( x + width - arrowSize , y + arrowSize);
            exp.closePath();
        }
        else{
            isp.moveTo(x+ arrowSize + thickness , y + thickness);
            isp.lineTo(x+ arrowSize + thickness + compdw,y + thickness);
            isp.lineTo( x + arrowSize + thickness + compdw, y + thickness + compdh);
            isp.lineTo( x + arrowSize + thickness , y + thickness + compdh);
            isp.closePath();

            exp.moveTo(x,y);
            exp.lineTo(x+ width , y);
            exp.lineTo( x + width , y + height);
            exp.lineTo(x+ arrowSize , y + height);
            exp.lineTo(x+arrowSize, y+ arrowSize);
            exp.closePath();
        }

        Area area = new Area(exp);
        Area internalArea = new Area(isp);
        area.subtract(internalArea);
        gg.setColor( this.backgroundColor);
        gg.fill(area);
        gg.dispose();
    }
    public static MessageBorder createBorderForSender(){
        MessageBorder b= new MessageBorder(thickness,thickness,thickness,thickness+ arrowSize , true);
        return b;
    }
    public static MessageBorder createBorderNotForSender(){
        MessageBorder b = new MessageBorder(thickness, thickness + arrowSize , thickness, thickness, false);
        return b;
    }
}
