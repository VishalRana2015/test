package test;
import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;
public class ConvolutionDemo {
    public static void main(String[] args) {
        JFrame frame  = new JFrame("Convolution Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800,700);
        frame.setLocation(50,0);
        JPanel panel = new JPanel();
        ImageIcon icon =new ImageIcon("C:\\Users\\RANA1947\\Desktop\\convo.jpg");
        MyComponent comp = new MyComponent(icon.getImage(),750,650);
        comp.setLocation(20,20);
        panel.setLayout(null);
        panel.add(comp);
        frame.setContentPane(panel);
        frame.setVisible(true);
    }
    private static class MyComponent extends JComponent{
        int ww, hh;
        Image image ;
        String status;
        public final static int ERROR = 1;
        public final static int COMPLETE = 2;
        public MyComponent(Image image , int ww, int hh ){
            this.ww = ww;
            this.hh= hh;
            this.setBorder( BorderFactory.createLineBorder(Color.BLACK));
            this.setSize(ww,hh);
            double[][] mat = { {0,0,0},{0,1,0},{0,0,0}};
            ConvolutionFilter filter = new ConvolutionFilter(mat);
            FilteredImageSource fis = new FilteredImageSource(image.getSource(),filter);
            this.image = createImage(fis);
            prepareImage(this.image, new MyImageObserver(this));
        }

        public void setStatus(String status) {
            this.status = status;
            this.repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int x, y , w, h;
            w= this.getWidth() - (this.getInsets().left + this.getInsets().right);
            h = this.getHeight() - (this.getInsets().top + this.getInsets().bottom);
            x = (int)g.getClipBounds().getX();
            y = (int)g.getClipBounds().getY();
            Graphics2D gg = (Graphics2D) g.create();
            if( image != null){
                gg.drawImage(image,x,y,w,h,null);
            }
            else{
                System.out.println("Image is null");
            }
            int mx , my;
            mx = x + w/2;
            my = y + h/2;
            gg.setColor(Color.BLACK);
            gg.setFont(new Font(Font.SERIF, Font.ITALIC, 30));
            gg.drawString(this.status, mx,my);
            gg.dispose();
        }
    }
    private static class MyImageObserver implements ImageObserver{
        MyComponent comp;
        public MyImageObserver(MyComponent comp){
            this.comp = comp;
        }
        @Override
        public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {
            System.out.println("Image Observer called : x, y , width , height :"+ x + ", " + y + ", "+ width + ", "+ height);
            String s  = "";
            if ( (infoflags &ImageObserver.ALLBITS) != 0)
                s = s + "Done";
            if ( (infoflags & ImageObserver.ABORT) != 0)
                s = s+ "Abort";
            if ( (infoflags & ImageObserver.ERROR) != 0)
                s = s + "Error";
            if ( (infoflags & ImageObserver.FRAMEBITS) != 0)
                s = s + "FrameBits";
            if ( (infoflags & ImageObserver.HEIGHT) != 0)
                s = s + "height";
            if ( (infoflags & ImageObserver.PROPERTIES) != 0)
                s = s+ "Properties";
            if ( (infoflags & ImageObserver.WIDTH ) != 0)
                s = s+ "Width";
            if ( (infoflags & ImageObserver.SOMEBITS ) != 0)
                s = s+ "SomeBits";
            System.out.println("s :"+ s);
            comp.setStatus(s);
            return true;
        }
    }
    private static class ConvolutionFilter extends ImageFilter{
        int savedWidth, savedHeight;
        int hints;
        int [] pixels;
        double[][] convolutionMatrix ;
        ColorModel model ;
        int size;
        ConvolutionFilter(double[][] matrix){
            int size = matrix.length;
            if ( size%2 == 0)
                convolutionMatrix = new double[size+1][size+1];
            else
                convolutionMatrix = new double[size][size];
            for ( int i =0;i < size; i++)
                for (int j =0; j < size; j++)
                    convolutionMatrix[i][j] = matrix[i][j];
            this.size = size;
        }

        @Override
        public void setDimensions(int width, int height) {
            this.savedHeight = height;
            this.savedWidth = width;
            System.out.println("SavedWidth :"+ savedWidth + " savedHeight :"+ savedHeight);
            pixels = new int[width * height];
            consumer.setDimensions(width, height);
        }

        @Override
        public void setProperties(Hashtable<?, ?> props) {
            consumer.setProperties(props);
        }

        @Override
        public void setColorModel(ColorModel model) {
            consumer.setColorModel(model);
            this.model = model;
        }
        static int count = 0;
        @Override
        public void setHints(int hints) {
            String s = "";
            if (( hints & ImageConsumer.SINGLEFRAME) != 0)
                s= s+ " SingleFrame";
            if ( (hints& ImageConsumer.TOPDOWNLEFTRIGHT ) != 0)
                s =s + " TopDownLeftRight";
            if ( (hints & ImageConsumer.SINGLEPASS) != 0)
                s = s+ " SinglePass";
            if ( (hints & ImageConsumer.COMPLETESCANLINES) != 0)
                s = s + "CompleteScanLines";
            if ( (hints & ImageConsumer.RANDOMPIXELORDER) != 0)
                s = s+ "RandomPixelOrder";
            System.out.println("hints by ImageProducer :"+ s);
            consumer.setHints( ImageConsumer.COMPLETESCANLINES| ImageConsumer.SINGLEFRAME | ImageConsumer.TOPDOWNLEFTRIGHT);
            this.hints = hints;
        }

        @Override
        public void setPixels(int x, int y, int w, int h, ColorModel model, byte[] pixels, int off, int scansize) {
            //super.setPixels(x, y, w, h, model, pixels, off, scansize);
           // System.out.println("setPixels byte version called for "  + count++);
            int row, column;

            for ( int r =0; r < h ; r++){
                row = r + y;
                for ( int c =0; c < w ; c++){
                    column = c + x;
                    this.pixels[row*savedWidth + column] = pixels[r*scansize + c];
                }
            }

        }

        @Override
        public void setPixels(int x, int y, int w, int h, ColorModel model, int[] pixels, int off, int scansize) {
            //super.setPixels(x, y, w, h, model, pixels, off, scansize);
            int row, column;
            //System.out.println("setPixels int version called for "  + count++);

            for ( int r =0; r < h ; r++){
                row = r + y;
                for ( int c =0; c < w ; c++){
                    column = c + x;
                    this.pixels[row*savedWidth + column] = pixels[r*scansize + c];
                }
            }
        }

        @Override
        public void imageComplete(int status) {
            //super.imageComplete(status);
            System.out.println("status :"+ status);
            if ( ((status == ImageConsumer.IMAGEABORTED ) | ( status ==  ImageConsumer.IMAGEERROR)) ) {
                consumer.imageComplete(status);
                System.out.println("Image Error" + status);
            }
            else {
                System.out.println("In else part");
                double[][] B = new double[this.size][this.size]; // for Blue
                double[][] R= new double[this.size][this.size]; // for Red
                double[][] G = new double[this.size][this.size]; // for Green
                int[] newPixels = new int[savedWidth* savedHeight];
                int red, green , blue , colorValue;
                int tempr, tempc, ac;
                int k = size/2;
                int [] temp = new int[savedWidth];
                System.out.println("size , k : "+ size + ", "+ k);
                for (int r = 0; r < savedHeight ; r++){
                    for (int c =0; c < savedWidth ; c++){
                        // Build Matrix B
                        temp[c] = pixels[r*savedWidth + c];
                        for ( int br =0; br < size ; br++) {
                            for (int bc = 0; bc < size; bc++) {
                                tempr = r + br - k;
                                tempc = c + bc - k;
                                if ((tempr >= 0 && tempr < savedHeight) && (tempc >= 0 && tempc < savedWidth)) {
                                    colorValue= pixels[tempr * savedWidth + tempc];
                                    Color color = new Color(colorValue);
                                    B[br][bc] = color.getBlue();
                                    R[br][bc] = color.getRed();
                                    G[br][bc] = color.getGreen();
                                }
                                else {
                                    B[br][bc] = 0;
                                    R[br][bc] = 0;
                                    G[br][bc] = 0;
                                }

                            }
                        }
                        blue = convolute(convolutionMatrix, B) % 256;
                        red = convolute( convolutionMatrix, R) %256;
                        green = convolute(convolutionMatrix, G) % 256;
                        colorValue = ( 0xff << 24) | ( red << 16 ) | ( green << 8  )  | ( blue);
                        Color color = new Color(red,green,blue);
                        newPixels[r*savedWidth + c] = color.getRGB();
                    }
                    consumer.setPixels(0,r,savedWidth,1,this.model,temp,0,savedWidth);
                }
                consumer.imageComplete(ImageConsumer.STATICIMAGEDONE);
                // New Pixels have been set
                System.out.println("New Pixels have been set");

            }
            System.out.println("Function executed");
        }


        private int convolute(double[][] convolutionMatrix , double[][] B){
            double ac  =0;
            for (int i =0; i < size; i++){
                for (int j =0; j < size; j++){
                    ac += convolutionMatrix[i][j]*B[i][j];
                }
            }
            return (int)ac;
        }
    }

}
