package test;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.event.*;
public class test1 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Image Filter Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocation(50,0);
        frame.setSize(500,500);
        MyComponent comp =new MyComponent(200,200);
        JPanel panel =new JPanel();
        panel.setLayout(null);
        panel.add(comp);
        frame.setContentPane(panel);
        frame.setVisible(true);
    }

    public static class MyComponent extends JComponent{
        Image image;
        int ww , hh;
        Color[] colorArray = {Color.RED , Color.GREEN, Color.BLUE , Color.YELLOW , Color.CYAN, Color.MAGENTA};
        public MyComponent(int width , int height){
            this.ww  = width;
            this.hh= height;
            this.setPreferredSize(new Dimension(width,height));
            this.setMinimumSize(new Dimension(width, height));
            this.setMaximumSize(new Dimension(width, height));
            this.setSize(new Dimension(width, height));
            init();
        }
        public void init(){
            int rangeSize;
            rangeSize = this.ww / colorArray.length;
            int[] pixels = new int[ww*hh];
            int pindex , cindex;
            pindex = 0;
            cindex = 0;
            for ( int y = 0; y < hh ; y++){
                for (int x= 0; x < ww ; x++){
                    for ( int i = 0 ; i < colorArray.length; i++){
                        if ( x <= (i+1)*rangeSize){
                            cindex = i;
                            break;
                        }
                        else
                            cindex = i -1;
                    }
                    pixels[pindex++] = colorArray[cindex].getRGB();
                }
            }
            ImageProducer ip = new MemoryImageSource(this.ww , this.hh,pixels,0,this.ww);
            image = createImage(ip);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            System.out.println("In PaintComponent method");
            if ( image == null){
                System.out.println("Image is null");
            }
            else
                System.out.println("Image is not null");
            Graphics2D gg = (Graphics2D)g.create();
            int x, y , w, h;
            x= g.getClipBounds().x + this.getInsets().left;
            y= g.getClipBounds().y + this.getInsets().top;
            w = this.getWidth()- (this.getInsets().left + this.getInsets().right);
            h = this.getHeight() - (this.getInsets().top + this.getInsets().bottom);
            gg.drawImage(image,x,y,w,h,0,0,image.getWidth(null),image.getHeight(null),null);
            gg.dispose();
            System.out.println("Image Painted");
        }
    }


}
