package test;
import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.beans.PropertyChangeListener;
import java.util.*;
public class ActionTest {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Action Test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JMenuBar bar = new JMenuBar();
        JMenu menu = new JMenu("Menu");
        ImageIcon icon = new ImageIcon("C:\\Users\\RANA1947\\Desktop\\logo.jpg");
        AbstractAction a = new MyAction("Action Object ",icon);
        JMenuItem item = new JMenuItem(a);
        JButton button = new JButton(a);
        bar.add(menu);
        menu.add(item);
        frame.setJMenuBar(bar);
        JPanel panel = new JPanel();
        panel.add(button);
        JButton toggle = new JButton("Disable button");
        toggle.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton button = (JButton)e.getSource();
                if ( a.isEnabled()){
                    a.setEnabled(false);
                    button.setText("Enable");
                }
                else{
                    a.setEnabled(true);
                    button.setText("Disable");
                }
            }
        });
        panel.add(toggle);
        frame.setContentPane(panel);

        frame.setVisible(true);
    }
    static class MyAction extends AbstractAction{
        public MyAction( String name , Icon icon){
            super(name,icon);
        }
        @Override
        public void actionPerformed(ActionEvent e) {
            if ( e.getSource() instanceof JMenuItem)
                System.out.println("Action performed by JMenuItem");
            else
                System.out.println("Action Performed by AbstractAction");
        }


    }

}
