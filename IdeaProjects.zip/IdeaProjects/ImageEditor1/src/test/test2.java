package test;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.PropertyChangeListener;
import java.util.*;
public class test2 {
    private static VTextField field1, field2;
    public static void main(String[] args) {
        JFrame frame= new JFrame("KeyListener test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel = new JPanel();
        MyComponent comp1 = new MyComponent("Comp1");
        MyComponent comp2 = new MyComponent("Comp2");
        comp1.setBackground( new Color(120,120,0));
        comp2.setBackground(new Color(0,120,120));
        comp1.setPreferredSize(new Dimension(100,100));
        comp2.setPreferredSize(new Dimension(100,100));
        //panel.setLayout(null);
        comp1.setSize(100,100);
        comp2.setSize(100,100);
        comp1.setLocation(50,50);
        comp2.setLocation(200,50);
        comp1.setFocusable(true);
        comp2.setFocusable(true);
        MyListener listener = new MyListener();
        //comp1.addKeyListener(listener);
        //comp2.addKeyListener(listener);
        //panel.add(comp2);
        panel.add(comp1);
        frame.setContentPane(panel);
        FocusTraversalPolicy p  = new LayoutFocusTraversalPolicy();
        //SortingFocusTraversalPolicy s = new SortingFocusTraversalPolicy();
        panel.setFocusTraversalPolicy(p);
        field1 = new VTextField("Field 1");
        field2 = new VTextField("Field 2");
        panel.add(field1);
        panel.add(field2);
        frame.setVisible(true);
        panel.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                System.out.println("filed1.hasFocus() :"+ field1.hasFocus());
                System.out.println("field2.hasFocus() :"+ field2.hasFocus());
            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
        panel.getInputMap().put(KeyStroke.getKeyStroke("SPACE"),"action");
        panel.getActionMap().put("action", new Action() {
            @Override
            public Object getValue(String key) {
                return null;
            }

            @Override
            public void putValue(String key, Object value) {

            }

            @Override
            public void setEnabled(boolean b) {

            }

            @Override
            public boolean isEnabled() {
                return false;
            }

            @Override
            public void addPropertyChangeListener(PropertyChangeListener listener) {

            }

            @Override
            public void removePropertyChangeListener(PropertyChangeListener listener) {

            }

            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("field1.hasFocus() :: "+field1.hasFocus());
                System.out.println("field2.hasFocus() :: "+ field2.hasFocus());
            }
        });

        System.out.println("Is panel focusable :"+ panel.isFocusable());
        panel.setFocusable(true);
        System.out.println("panel travesla policy :"+ panel.getFocusTraversalPolicy());
        System.out.println("In comp1 is accepted as a focus owner by the container panel : "+ p.getFirstComponent(panel));
    }
    private static class MyComponent extends JComponent{
        private static FocusBorder border;
        static {
            border = new FocusBorder(2,2,2,2,Color.BLACK,Color.BLUE);
        }

        String componentName;

        public  MyComponent(String name){
            super();
            this.componentName =name;
            this.setBorder(border);
            this.getInputMap().put(KeyStroke.getKeyStroke("S") , "Hello world");
         }

        @Override
        public String toString() {
            return "MyComponent{" +
                    "componentName='" + componentName + '\'' +
                    '}';
        }

        public String getComponentName() {
            return componentName;
        }

        @Override
        public boolean requestFocus(boolean temporary) {
            System.out.println("request focus called");
            return super.requestFocus(temporary);
        }

        @Override
        public void grabFocus() {
            System.out.println("Grab Focus called");
            super.grabFocus();
        }

        @Override
        public void requestFocus() {
            System.out.println("Request focus called ");
            super.requestFocus();
        }

        @Override
        public boolean hasFocus() {
            System.out.println("hasfocus called");

            System.out.println("hasFocus :"+ super.hasFocus());
            return super.hasFocus();
        }

        @Override
        public void transferFocus() {
            System.out.println("transferFocus called");
            super.transferFocus();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            //System.out.println("Paint component method called");
            int x,y , w, h;
            x = (int)g.getClipBounds().getX();
            y = (int)g.getClipBounds().getY();
            w = (int)g.getClipBounds().getWidth();
            h= (int)g.getClipBounds().getHeight();
            Graphics2D gg = (Graphics2D)g.create();
            gg.setColor(this.getBackground());
            gg.fillRect(x,y,w,h);
            gg.dispose();
        }
    }

    static class MyListener implements KeyListener{
        public MyListener(){

        }

        @Override
        public void keyTyped(KeyEvent e) {

         if ( !(e.getSource() instanceof MyComponent))
             return;
         MyComponent comp = (MyComponent)e.getSource();

        // System.out.println("hasfocus :"+ comp.hasFocus());
         System.out.println("KeyTyped for :"+ comp.getComponentName());

        }

        @Override
        public void keyPressed(KeyEvent e) {

        }

        @Override
        public void keyReleased(KeyEvent e) {

        }
    }
    private static class FocusBorder extends EmptyBorder {
        Color coolor, focusColor;
        FocusBorder(int top , int left , int bottom, int right ,Color color){
            super(top ,left, bottom, right);
            this.coolor= color;
            this.focusColor= new Color(120,0,0);
        }
        public FocusBorder( int top , int left , int bottom , int right , Color color , Color focusColor){
            super(top,left, bottom, right);
            this.coolor = color;
            this.focusColor = focusColor;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            super.paintBorder(c, g, x, y, width, height);
            int top , left , bottom , right;
            top =this.getBorderInsets().top;
            left = this.getBorderInsets().left;
            bottom = this.getBorderInsets().bottom;
            right = this.getBorderInsets().right;
            Graphics2D gg = (Graphics2D)g.create();
            if ( c.hasFocus()) {
                gg.setColor(focusColor);
            }else {
                gg.setColor(this.coolor);
            }
            gg.fillRect(x,y,width,top);
            gg.fillRect(x,y,left,height);
            gg.fillRect(x,y+height-bottom,width,bottom);
            gg.fillRect(x+width-right,y,right,height);
            gg.dispose();
        }
    }
    private static class MyFocusTraversal extends FocusTraversalPolicy{
        Vector<JComponent> order;
        public MyFocusTraversal(){

        }
        @Override
        public Component getComponentAfter(Container aContainer, Component aComponent) {
            return null;
        }

        @Override
        public Component getComponentBefore(Container aContainer, Component aComponent) {
            return null;
        }

        @Override
        public Component getDefaultComponent(Container aContainer) {
            return null;
        }

        @Override
        public Component getFirstComponent(Container aContainer) {
            return null;
        }

        @Override
        public Component getLastComponent(Container aContainer) {
            return null;
        }

    }

    private static class VTextField extends JTextField{
        String s ;
        VTextField(String s){
            super(s);
            this.s =s;
        }
        VTextField(){
            super();
            this.s = "empty ";
        }

        @Override
        public boolean hasFocus() {

//            System.out.println("HasFocus called for VTextField :" + ((this.getText() == null)?" ":this.getText() ) );
            //System.out.println( this.s+super.hasFocus());
            return super.hasFocus();
        }

        @Override
        public void grabFocus() {
            System.out.println("GrabFocus called for VTextField" + this.s + "," + this.hasFocus());
            super.grabFocus();
            System.out.println("After GrabFocus called focus status :" +this.s + "," +   this.hasFocus());
        }

        @Override
        public void requestFocus() {
            System.out.println("RequestFocus called for the VTextField " + this.s + ", "+ this.hasFocus());
            super.requestFocus();
            System.out.println("After requestFocus called for the VTextField, focus Status :" + this.s + ","+ this.hasFocus());
        }

        @Override
        public void transferFocus() {
            System.out.println("transferFocus called for the VTextField " + this.s + "," + this.hasFocus());
            System.out.println("Field1.hasFocus ::: "+ field1.hasFocus());
            System.out.println("Field2.hasFoucs ::: " +field2.hasFocus());
            super.transferFocus();
            System.out.println("After TransferFocus called for the VTextField :"+ this.s  + " ,"+ this.hasFocus());
        }

        @Override
        protected boolean requestFocusInWindow(boolean temporary) {
            System.out.println("Before requestFocusInWindow called for "+ this.s  + ","+ this.hasFocus());
            boolean value =  super.requestFocusInWindow(temporary);
            System.out.println("After requestFocusInWindow called for "+ this.s  + ","+ this.hasFocus());
            return value;
        }
    }
}
