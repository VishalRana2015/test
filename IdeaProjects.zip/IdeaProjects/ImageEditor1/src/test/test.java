package test;

public class test {
    public static void main(String[] args) {
        String s = "My Name   is vishal rana.\nI am 24 years old.\n\nI Love playing football.\nI am pursuing MCA.";
        /*String[] ss = s.split("[\n]");
        String[] temp = new String[2*ss.length];
        int l =0;
        boolean flag ;
        for (int k =0; k < ss.length; k++){
            temp[l] = ss[k];
            if ( temp[l].equalsIgnoreCase("\n") || temp[l].equalsIgnoreCase("")) {
                flag = true;
            }
            else {
                flag = false;
            }
            l++;
            if ( !flag && k!=(ss.length-1)){
                temp[l] = "\n";
                l++;
            }
        }
        String[] p = new String[l]; // l stands for the paragraphs
        for (int i =0; i < l ; i++)
            p[i] = temp[i];

        String[][] pw = new String[p.length][];
        String[]  temp1;
        for (int i =0; i < p.length; i++){
            temp1 = p[i].split(" ");
            l =0;
            temp = new String[2*temp1.length];
            for ( int j =0; j < temp1.length; j++){
                temp[l] = temp1[j];
                if ( temp[l].equalsIgnoreCase(" ") || temp[l].equalsIgnoreCase("")) {
                    flag = true;
                }
                else {
                    flag = false;
                }
                l++;
                if ( !flag && j != ( temp1.length -1) ){
                    temp[l] = " ";
                    l++;
                }
            }
            // l is keeping track of the length of the pw[i] String array
            pw[i] = new String[l];
            for (int j =0; j < l;j ++){
                pw[i][j]  = temp[j];
            }
        }

        for (int i =0; i < pw.length; i++){
            System.out.println((i+1) + "th paragraph");
            for ( int j =0; j < pw[i].length; j++){
                System.out.println("pw["+i+"]["+j+"] :"+pw[i][j]);
            }
        }*/
        String[][] pw = getParaWord(s);

    }

    private static String[] getStringArray(String[] ss , String seperator){
        int l =0;
        String temp[] , temp2[];
        boolean flag ;
        temp = new String[2*ss.length];
        for (int k =0; k < ss.length; k++){
            temp[l] = ss[k];
            if ( temp[l].equalsIgnoreCase(seperator) || temp[l].equalsIgnoreCase("")) {
                flag = true;
                temp[l] = seperator;
            }
            else {
                flag = false;
            }
            l++;
            if ( !flag && k!=(ss.length-1)){
                temp[l] = seperator;
                l++;
            }
        }
        temp2 = new String[l];
        for (int i =0; i <l ;i ++){
            temp2[i] = temp[i];
        }
        return temp2;
    }
    private static  String[][] getParaWord(String s ){
        String[] ss = s.split("[\n]");
        String[] p = getStringArray(ss,"\n");

        String[][] pw = new String[p.length][];
        String[] temp;

        for (int i =0; i < p.length; i++){
            temp = p[i].split(" ");
            pw[i] = getStringArray(temp," ");
        }
        return pw;
    }

}
