package test;
import javax.swing.*;
import java.awt.*;
public class test3  extends JComponent{
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        test3 t = new test3();
        t.setSize(100,100);
        t.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        t.setLocation(10,10);
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.add(t);
        frame.setContentPane(t);
        t.ggg();
        frame.setVisible(true);
    }
    private void ggg(){
        Graphics g= getGraphics();
        if ( g == null)
            System.out.println("g is null");
        else
            System.out.println("g is not null");
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        System.out.println("sw this.getFontMetrics :"+ this.getFontMetrics(this.getFont()).stringWidth("Hello World"));
        g.setFont(this.getFont());
        System.out.println("sw g.getFontMetrics :"+ g.getFontMetrics(g.getFont()).stringWidth("Hello World"));
    }
}
