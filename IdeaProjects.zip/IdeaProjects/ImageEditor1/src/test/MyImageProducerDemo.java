package test;


import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.image.ColorModel;
import java.awt.image.ImageConsumer;
import java.awt.image.ImageProducer;
import java.awt.image.MemoryImageSource;
import java.util.*;
import java.lang.*;
import java.io.*;
public class MyImageProducerDemo {
    public static void main(String[] args) {
        String filename = "C:\\Users\\RANA1947\\Desktop\\myfile2.vpg";
        createVPGImage(filename, 200, 200);
        System.out.println("Image file created");
        JFrame frame = new JFrame("MyProducer Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel = new JPanel();
        MyComponent comp = new MyComponent(filename);
        comp.setSize(200,200);
        //comp.setImage2(200,200);
        comp.setLocation(50,50);
        panel.setLayout(null);
        panel.add(comp);
        frame.setContentPane(panel);
        frame.setVisible(true);
    }
    private static class MyComponent extends JComponent{
        Image image;
        Image image2;
        public MyComponent(String filename){
            MyImageProducer producer = new MyImageProducer(filename);
            image = createImage(producer);
        }

        public void setImage2(int iw, int ih) {
            int[] pixels = new int[iw * ih];
            int index = 0;
            int rangeSize = iw/3;
            for (int i = 0; i < iw; i++){
                for (int j =0; j < ih; j++){
                    if ( j < rangeSize )
                        pixels[index++] =Color.RED.getRGB();
                    else if ( j < 2*rangeSize)
                        pixels[index++] = Color.GREEN.getRGB();
                    else
                        pixels[index++] = Color.BLACK.getRGB();
                }
            }
            MemoryImageSource mis = new MemoryImageSource(iw, ih, ColorModel.getRGBdefault(),pixels,0,iw);
            image2 = createImage(mis);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int x, y , w, h;
            x = (int)g.getClipBounds().getX();
            y = (int)g.getClipBounds().getY();
            w = this.getWidth();
            h = this.getHeight();
            Graphics2D gg = (Graphics2D)g.create();
            if (image != null)
                gg.drawImage(image,0,0,image.getWidth(null), image.getHeight(null), null);
            if ( image2 != null)
                gg.drawImage(image2,0,0,image2.getWidth(null), image2.getHeight(null), null);

        }
    }
    public static void createVPGImage (String filename , int w, int h){
        File file= new File(filename);
        if ( !file.exists() ){
            try {
                file.createNewFile();
            }catch( Exception e){
                System.out.println("Excpetion caught while creating file:"+ e.getMessage());
            }
        }
        int[] pixels = new int[w* h];
        int rangeSize = w/3;
        int index =0;
        for (int i =0; i < w;i++){
            for (int j=0; j < h; j++){
                if ( j < rangeSize){
                    pixels[index++] = Color.RED.getRGB();
                }
                else if ( j < rangeSize*2)
                    pixels[index++] = Color.GREEN.getRGB();
                else
                    pixels[index++] = Color.BLUE.getRGB();
            }
        }

        String format = "VPG";
        try {
            FileOutputStream output = new FileOutputStream(file);
            BufferedOutputStream boutput = new BufferedOutputStream(output);
            DataOutputStream dos = new DataOutputStream(output);
            ObjectOutputStream ooutput = new ObjectOutputStream(dos);
            ooutput.writeUTF("VPG");
            ooutput.writeInt(w);
            ooutput.writeInt(h);
            //ooutput.writeObject(ColorModel.getRGBdefault());
            for (int i = 0; i < pixels.length; i++){
                ooutput.writeInt(pixels[i]);
            }
            ooutput.close();
            dos.close();
            boutput.close();
            output.close();
            // written to file successfully
        }
        catch( Exception e){
            System.out.println("Exception caught while creating file . " + e.getMessage());
        }
        // taking exit from the function
    }

    static class MyImageProducer implements ImageProducer{
        ImageConsumer ic ;
        int[] pixels;
        int[][] store;
        String filename;
        int hints;
        ColorModel model;
        int iw, ih;
        Hashtable properties;
        public MyImageProducer(String filename) {
            this.filename = filename;
            hints = ( ImageConsumer.SINGLEFRAME | ImageConsumer.SINGLEPASS | ImageConsumer.TOPDOWNLEFTRIGHT | ImageConsumer.COMPLETESCANLINES );
            properties = null;
            readImage();
        }
        private void readImage() {
            try{
                File file = new File(this.filename);
                FileInputStream input = new FileInputStream(file);
                BufferedInputStream binput = new BufferedInputStream(input);
                DataInputStream dinput = new DataInputStream(binput);
                ObjectInputStream oinput =new ObjectInputStream(dinput);
                String format = oinput.readUTF();
                if ( !format.equalsIgnoreCase("vpg") )
                    throw new Exception("Invalid Image Type");
                iw = oinput.readInt();
                ih = oinput.readInt();
                System.out.println("iw : "+ iw + " ih :" + ih);
                //model = (ColorModel)oinput.readObject();
                store= new int[ih][iw];
                pixels = new int[iw*ih];
                int index = 0;
                int t;
                for ( int i=0; i < ih ;i++){
                    for (int j =0; j < iw; j++){
                        t= oinput.readInt();
                        pixels[index++] = t;
                        store[i][j] =t;
                    }
                }
                oinput.close();
                dinput.close();
                binput.close();
                input.close();
            }
            catch(Exception e){
                System.out.println("Exception caught  In ReadImage:"+ e.getMessage());
                pixels = null;
            }
        }
        @Override
        public synchronized void addConsumer(ImageConsumer ic) {
            this.ic = ic;
            if ( pixels == null){
                ic.imageComplete(ImageConsumer.IMAGEERROR);
                return;
            }
            try{
                ic.setDimensions(iw,ih);
                ic.setColorModel(ColorModel.getRGBdefault());
                ic.setHints(hints);
                ic.setProperties(properties);
                // sending one line at a time ;
                for ( int r = 0; r < ih ; r++) {
                    ic.setPixels(0, r , iw, 1, ColorModel.getRGBdefault(), store[r], 0, iw);
                }
                ic.imageComplete(ImageConsumer.STATICIMAGEDONE);
            }
            catch(Exception e){
                System.out.println("Exception thrown: while setting pixels "+ e.getMessage());
                ic.imageComplete(ImageConsumer.IMAGEERROR);
            }
        }

        @Override
        public synchronized void removeConsumer(ImageConsumer ic) {
            if ( this.ic == ic){
                ic = null;
            }
        }

        @Override
        public synchronized boolean isConsumer(ImageConsumer ic) {
            if ( this.ic == ic)
                return true;
            return false;
        }

        @Override
        public synchronized void startProduction(ImageConsumer ic) {
            this.addConsumer(ic);
        }

        @Override
        public void requestTopDownLeftRightResend(ImageConsumer ic) {
            // ignore this one
        }
    }
}
