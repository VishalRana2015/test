package test;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.*;
import javax.swing.event.*;
import java.util.*;
import java.io.*;


public class FileMessage extends JComponent {
    static private int staticHeight , staticGap ;
    static private HashMap<String , ImageIcon>  extmap;
    static ClickListener listener;
    static FileMessageLayoutManager layoutManager ;
    static {
        staticHeight = 50;
        staticGap = 2;
        listener = new ClickListener();
        extmap = new HashMap();
        extmap.put("default",new ImageIcon("C:\\Users\\RANA1947\\IdeaProjects\\ImageEditor\\Images\\file.jpg"));
        layoutManager = new FileMessageLayoutManager();
    }

    private static class  FileMessageLayoutManager implements LayoutManager2{
        public FileMessageLayoutManager(){
            super();
        }
        @Override
        public void invalidateLayout(Container target) {
            // do nothing
        }

        @Override
        public float getLayoutAlignmentX(Container target) {
            return 0;
        }

        @Override
        public float getLayoutAlignmentY(Container target) {
            return 0;
        }

        @Override
        public void addLayoutComponent(Component comp, Object constraints) {

        }

        @Override
        public void addLayoutComponent(String name, Component comp) {

        }

        @Override
        public void removeLayoutComponent(Component comp) {

        }

        @Override
        public void layoutContainer(Container parent) {
            // This method is responsible for setting the boudns and location for the container 'parent'
            FileMessage message = (FileMessage)parent;
            int sh = message.getStaticHeight();
            int gap = message.getStaticGap();
            Dimension size = message.getSize();
            int width , height;
            int x, y;
            int ncomps = message.getComponentCount();
            Component comp;
            if ( ncomps > 0) {
                comp = message.getComponent(0);
                x = 2*gap + ( sh - 2*gap);
                y = 4*gap;
                width = ((int)size.getWidth() - message.getInsets().left - message.getInsets().right) - x - gap;
                height = (int)comp.getPreferredSize().getHeight();
                comp.setBounds(x, y, width, height);
            }
            System.out.println("layout done");
        }

        @Override
        public Dimension minimumLayoutSize(Container parent) {
            FileMessage message = (FileMessage)parent;
            Class c = parent.getClass();
            int h =message.getStaticHeight();
            return new Dimension(h*3,h);
        }

        @Override
        public Dimension maximumLayoutSize(Container target) {
            return preferredLayoutSize(target);
        }

        @Override
        public Dimension preferredLayoutSize(Container parent) {
            FileMessage message = (FileMessage)parent;
            int h = message.getStaticHeight();
            int ncomps = message.getComponentCount();
            int w =0;
            System.out.println("ncomps :"+ ncomps);
            for ( int i =0; i <ncomps ; i++){
                Dimension d =  message.getComponent(i).getPreferredSize();
                System.out.println("d :"+ d);
                w =w +  (int)d.getWidth();
            }
            int gap = message.getStaticGap();
            w = w + h;
            w = w + message.getInsets().left + message.getInsets().right + gap;
            h= h + message.getInsets().top + message.getInsets().bottom;
            return new Dimension(w,h);
        }

    }
    static public void setIconFor(String extension , ImageIcon icon)  throws NullPointerException, IllegalArgumentException{
        if ( extension == null || icon == null)
            throw new NullPointerException("One of the arguments is null");
        char ch = extension.charAt(0);
        if ( ch  != '.')
            throw new IllegalArgumentException("Not a valid extension format (Hint: It must start with .)");
        extmap.put(extension,icon);
    }

    static public  ImageIcon getIconFor(String extension){
        ImageIcon icon = extmap.get(extension);
        if ( icon == null){
            System.out.println("icon is null");
            icon = extmap.get("default");
        }
        return icon;
    }
    static public int getStaticHeight(){
        return staticHeight;
    }
    static public int getStaticGap(){
        return staticGap;
    }

    public static void setStaticHeight(int height){
        if ( staticHeight < 50)
            staticHeight = 50;
        else
            staticHeight = height;
    }
    public static void setStaticGap(int gap){
        if ( gap < 0)
            staticGap = 0;
        else
            staticGap = gap;
    }
    static class ClickListener implements MouseListener{
        public ClickListener(){
            System.out.println("Listener created");
        }
        @Override
        public void mouseClicked(MouseEvent e) {
            System.out.println("Mouse Clicked");
            Component comp = (Component)e.getSource();
            Container container = comp.getParent();
            if ( container instanceof FileMessage){
                System.out.println("container is an instance of FileMessage Class");
                FileMessage message = (FileMessage)container;
                File file = message.getFile();
                if ( Desktop.isDesktopSupported() ){
                    Desktop desktop = Desktop.getDesktop();
                    if ( file.exists())
                        try {
                            desktop.open(file);
                        }catch( Exception exp){
                            System.out.println("Exception caught :"+ exp.getMessage());
                        }
                    else{
                        JOptionPane.showMessageDialog(message,"File Does not exists","Error Message",JOptionPane.ERROR_MESSAGE);
                    }
                }
            }

        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }

        @Override
        public void mousePressed(MouseEvent e) {

        }

        @Override
        public void mouseReleased(MouseEvent e) {

        }
    }

    File file;
    String filename;
    String extension;
    public FileMessage (File file){
        this.file = file;
        this.filename = file.getName();
        super.setLayout( layoutManager);
        JLabel label = new JLabel(filename);
        int index = filename.lastIndexOf('.');
        extension = filename.substring(index);
        this.add(label);
        label.addMouseListener(listener);
    }

    @Override
    public void setLayout(LayoutManager mgr) {
        //super.setLayout(mgr);
    }

    public File getFile() {
        return file;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D gg = (Graphics2D)g.create();
        int x, y, w,h;
        x = this.getInsets().left;
        y = this.getInsets().top;
        w = this.getWidth() - ( this.getInsets().left + this.getInsets().right);
        h = this.getHeight() - ( this.getInsets().top + this.getInsets().bottom);
        ImageIcon icon = getIconFor(this.extension);
        gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        gg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        gg.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        int ix, iy , iw, ih;
        ix = staticGap;
        iy= staticGap;
        iw = (staticHeight - 2*staticGap);
        ih = iw;
        gg.setColor(this.getBackground());
        gg.drawRect(x,y,w,h);
        gg.drawImage(icon.getImage(),ix,iy,iw,ih,null);
        System.out.println("Image Drawned");
        gg.dispose();
    }
}