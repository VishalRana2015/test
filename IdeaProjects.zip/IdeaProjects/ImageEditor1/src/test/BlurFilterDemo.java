package test;
import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;
import java.awt.image.*;
public class BlurFilterDemo {
    public static void main(String[] args) {
        JFrame frame =new JFrame("BlurFilter Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel = new JPanel();
        MyComponent comp = new MyComponent(200,200);
        comp.setSize(200,200);
        comp.setLocation(20,20);
        comp.setBorder(BorderFactory.createLineBorder(Color.GREEN));
        panel.setLayout(null);
        panel.add(comp);
        frame.setContentPane(panel);
        frame.setVisible(true);
    }
    public static class BlurFilter extends ImageFilter {
        private int savedWidth, savedHeight, savedPixels[];
        private static  ColorModel defaultCM = ColorModel.getRGBdefault();
        public BlurFilter(){
            super();
        }
        @Override
        public void setDimensions (int width, int height) {
            savedWidth=width; savedHeight=height;
            savedPixels=new int [width*height];
            consumer.setDimensions (width, height);
    }
        @Override
        public void setColorModel (ColorModel model) {
            // Change color model to model you are generating
            consumer.setColorModel (defaultCM);
        }
        @Override
        public void setHints (int hintflags) {
            // Set new hints, but preserve SINGLEFRAME setting
            consumer.setHints (TOPDOWNLEFTRIGHT | COMPLETESCANLINES | SINGLEPASS | (hintflags & SINGLEFRAME));
        }

        @Override
        public void setPixels(int x, int y, int w, int h, ColorModel model, int[] pixels, int off, int scansize) {

            System.out.println("setPixels called");
            setThePixels(x,y,w,h,model,pixels,off,scansize);
        }

        @Override
        public void setPixels(int x, int y, int w, int h, ColorModel model, byte[] pixels, int off, int scansize) {

            System.out.println("setPixels called byte version");
            setThePixels(x,y,w,h,model,pixels,off,scansize);
        }
        // The set the Pixels is responsiible for the setting the width and height of the m
        private void setThePixels (int x, int y, int width, int height, ColorModel cm, Object pixels, int offset, int scansize) {
            int sourceOffset = offset;
            int destinationOffset = y * savedWidth + x;
            boolean bytearray = (pixels instanceof byte[]);
            for (int yy = 0; yy < height; yy++) {
                for (int xx = 0; xx < width; xx++) {
                    if (bytearray)
                        savedPixels[destinationOffset++] = cm.getRGB(((byte[]) pixels)[sourceOffset++] & 0xff);
                    else
                        savedPixels[destinationOffset++] = cm.getRGB(((int[]) pixels)[sourceOffset++]);
                    sourceOffset += (scansize - width);
                    destinationOffset += (savedWidth - width);
                }
            }
        }
        @Override
        public void setProperties(Hashtable<?, ?> props) {
            if ( consumer != null)
            consumer.setProperties(props);
            System.out.println("setProperties called");
        }


        @Override
        public void imageComplete( int status){
            if ( (status == IMAGEABORTED) || (status == IMAGEERROR) ){
                consumer.imageComplete(status);
            }
            else{
                int pixels[] =new int[savedWidth];
                int position , sumArray[] , sumIndex;
                sumArray = new int[9]; // maxsize = vs. Vector for performance
                for (int yy =0; yy < savedHeight ; yy++){
                    position =0;
                    int start = yy * savedWidth;
                    for (int xx =0; xx < savedWidth ; xx++){
                        sumIndex =0;
                        sumArray[sumIndex++] = savedPixels[start+xx];
                        if ( yy != (savedHeight -1))
                            sumArray[sumIndex++] = savedPixels[start + xx + savedWidth];
                        if ( yy != 0 )
                            sumArray[sumIndex++] = savedPixels[start+ xx - savedWidth];
                        if ( xx != (savedWidth -1))
                            sumArray[sumIndex++] = savedPixels[start + xx + 1];
                        if ( xx != 0)
                            sumArray[sumIndex++] = savedPixels[start + xx -1];
                        if ( ( yy != 0 ) && ( xx != 0))
                            sumArray[sumIndex++] = savedPixels[start+ xx -savedWidth -1];
                        if ( (yy != ( savedHeight -1) && ( xx != (savedWidth -1))))
                            sumArray[sumIndex++] = savedPixels[start + xx + savedWidth + 1];
                        if ( ( yy != 0) && ( xx != 0))
                            sumArray[sumIndex++] = savedPixels[start+xx - savedWidth +1];
                        if ( ( yy != (savedHeight -1) && ( xx != 0)))
                            sumArray[sumIndex++] = savedPixels[start + xx + savedWidth -1];
                        pixels[position ++] = avgPixels(sumArray, sumIndex);
                    }
                    consumer.setPixels(0,yy,savedWidth,1,defaultCM, pixels,0,savedWidth);
                }
                consumer.imageComplete(status);
            }

        }
        private int avgPixels( int pixels[] , int size){
            float redSum = 0, greenSum=0, blueSum =0, alphaSum= 0;
            int redAvg , greenAvg , blueAvg , alphaAvg;
            redAvg = greenAvg  = blueAvg = alphaAvg= 0;
            for ( int i =0; i < size ; i++){
                try{
                    int pixel = pixels[i];
                    redSum += defaultCM.getRed(pixel);
                    greenSum += defaultCM.getGreen(pixel);
                    blueSum += defaultCM.getBlue(pixel);
                    alphaSum += defaultCM.getAlpha(pixel);
                }
                catch( ArrayIndexOutOfBoundsException e){
                    System.out.println("oops");
                }
                redAvg = (int) ( redSum / size);
                greenAvg = (int) (greenSum / size);
                blueAvg = (int) ( blueSum /size);
                alphaAvg = (int)(alphaSum / size);
            }
            return ( (0xff << 24 ) | ( redAvg << 16 ) | ( greenAvg << 8 ) | ( blueAvg << 0));
        }

    }

    private static class MyComponent extends JComponent{
        int width, height;
        Image image;
        public MyComponent(int width , int height){
            this.width = width;
            this.height = height;
            BlurFilter bf = new BlurFilter();
            int[] pixels = new int[width*height];
            for (int i =0; i < pixels.length; i++){
                pixels[i] = Color.GREEN.getRGB();
            }
            MemoryImageSource mis = new MemoryImageSource(width,height,pixels,0,width);
            ImageIcon icon = new ImageIcon("C:\\Users\\RANA1947\\Desktop\\logo.jpg");
            FilteredImageSource fis = new FilteredImageSource(icon.getImage().getSource() ,bf);
            image =createImage(fis);
            MyImageObserver observer = new MyImageObserver(this);
            prepareImage(image,observer);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int x, y , w, h;
            w= (int)this.getWidth() - (this.getInsets().left + this.getInsets().right);
            h = (int)this.getHeight() - (this.getInsets().top + this.getInsets().bottom);
            x = (int)g.getClipBounds().getX();
            y = (int)g.getClipBounds().getY();
            Graphics2D gg = (Graphics2D)g.create();
            gg.drawImage(image,0,0,w,h,null);
            gg.dispose();
        }
    }
    static class MyImageObserver implements ImageObserver{
        MyComponent comp ;
        public MyImageObserver( MyComponent comp){
            this.comp = comp;
        }
        @Override
        public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {
            System.out.println("Image Observer called " + img.toString() + " x, y , width , height "+ x + ", " + y + ", "+width + ", "+ height);
            comp.repaint();
            System.out.println("current Thread :"+ Thread.currentThread().toString());
            return true;
        }
    }
}
