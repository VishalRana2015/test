package test;
import javax.imageio.ImageIO;
import javax.imageio.stream.ImageInputStream;
import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.*;
import java.awt.image.*;
public class GrayImageFilterDemo {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Gray Scale Filter Demo");
        frame.setSize(600,600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocation(50,0);
        JPanel panel =new JPanel();
        panel.setLayout(null);
        ImageIcon icon =new ImageIcon("F:\\PICS\\Wallpapers\\Tulips.jpg");
        MyComponent comp = new MyComponent(icon.getImage());
        comp.setSize(300,500);
        comp.setLocation(20,20);
        panel.add(comp);
        frame.setContentPane(panel);
        frame.setVisible(true);
    }
    private static class MyComponent extends JComponent{
        Image image ;
        MyImageObserver observer ;
        public MyComponent(Image image){
            super();
            this.image = image;
            GrayScaleFilter filter = new GrayScaleFilter(GrayScaleFilter.NEGATIVEIMAGE);
            GrayScaleFilter2 filter2 = new GrayScaleFilter2 ( );
            FilteredImageSource fis  = new FilteredImageSource(image.getSource(),filter2);
            this.image = createImage(fis);
            observer = new MyImageObserver(this);
            prepareImage(this.image,observer);
            this.addMouseListener(new MouseListener() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    MyComponent comp = (MyComponent)e.getSource();
                    comp.repaint();
                }

                @Override
                public void mousePressed(MouseEvent e) {

                }

                @Override
                public void mouseReleased(MouseEvent e) {

                }

                @Override
                public void mouseEntered(MouseEvent e) {

                }

                @Override
                public void mouseExited(MouseEvent e) {

                }
            });
            this.setBorder( BorderFactory.createLineBorder(Color.RED));
        }

        @Override
        protected void paintComponent(Graphics g) {
            //System.out.println("paint called");
            super.paintComponent(g);
            int x, y , w,h;
            w = (this.getWidth()) - ( this.getInsets().left + this.getInsets().right);
            h = this.getHeight() - ( this.getInsets().top + this.getInsets().bottom);
            x = (int)g.getClipBounds().getX();
            y = (int)g.getClipBounds().getY();
            Graphics2D gg = (Graphics2D)g.create();
            MediaTracker tracker = new MediaTracker(this);
            tracker.addImage(this.image,1);
            if ( image != null){
                gg.drawImage(image,x,y,w, h, null);
                System.out.println("Image is not null");
                System.out.println("tracker.statusID(1) :"+ tracker.statusID(1,false));
                int status = tracker.statusID(1,true);
                if ( (status & MediaTracker.ABORTED)  != 0){
                    System.out.println("aborted");
                }
                if ( (status & MediaTracker.COMPLETE) != 0) {
                    System.out.println("Complelete");
                    System.out.println("Abordted :" + MediaTracker.ABORTED);
                    System.out.println("Complete  :" + MediaTracker.COMPLETE);
                    System.out.println("Loading : " + MediaTracker.LOADING);
                    System.out.println("Errored :" + MediaTracker.ERRORED);
                }
                if ( (status & MediaTracker.ERRORED ) != 0)
                    System.out.println("Errored");
                if ( (status & MediaTracker.LOADING ) != 0)
                    System.out.println("Loading");
            }
            else{
                   int mx , my, sw, sh;
                   gg.setFont(new Font(Font.SERIF,Font.ITALIC, 20));
                   sw = gg.getFontMetrics(gg.getFont()).stringWidth("Loading...");
                   sh = gg.getFont().getSize();
                   mx = x + w/2 - sw/2;
                   my = y + h/2 + sh/2;
                   gg.setColor(Color.BLACK);
                   gg.drawString("Loading...",mx,my);
            }
            gg.dispose();
        }

    }
    private static class MyImageObserver implements ImageObserver{
        MyComponent comp;
        public MyImageObserver(MyComponent comp){
            this.comp = comp;
        }
        @Override
        public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {
            //System.out.println("Image Update called x ,y , width , height :"+ x+ ", "+ y + ", "+ width + ", "+ height);
            if ( (ImageObserver.ABORT & infoflags) != 0)
                System.out.println("ABORT");
            if ( (ImageObserver.ALLBITS & infoflags) != 0)
                System.out.println("ImageObserver.ALLBITS");
            if ( (ImageObserver.ERROR & infoflags) != 0)
                System.out.println("ImageObserver.Error");
            if ( (ImageObserver.FRAMEBITS & infoflags)  != 0)
                System.out.println("ImageObserver.FrameBits");
            if ( (ImageObserver.SOMEBITS & infoflags ) != 0)
                System.out.println("ImageObserver.SomeBits");
            if ( (ImageObserver.HEIGHT & infoflags) != 0)
                System.out.println("ImageObserver.HEIGHT");
            if ( (ImageObserver.WIDTH & infoflags) != 0)
                System.out.println("ImageObserver.WIDTH");
            if ( (ImageObserver.PROPERTIES & infoflags) != 0)
                System.out.println("ImageObserver.Properties ");
            comp.repaint();
            try{
                //Thread.currentThread().sleep(20);
            }
            catch(Exception e){
                System.out.println("Exception cuaght :"+ e.getMessage());
            }

            return true;
        }

    }
    private static class GrayScaleFilter extends RGBImageFilter{
        public static int GRAYSCALEIMAGE = 1;
        public static int NEGATIVEIMAGE = 2;
        int type;
        public GrayScaleFilter(int type ) {
            this.type = type;
        }
        @Override
        public int filterRGB(int x, int y, int rgb) {
            int red , green , blue;
            red = (rgb>>16) & 0xff;
            green = (rgb >> 8)& 0xff;
            blue = (rgb >> 0) & 0xff;
            int val =0;
            if (this.type == GRAYSCALEIMAGE ) {
                int max;
                max = (red > green) ? (red > blue ? red : blue) : ((green > blue) ? green : blue);
                System.out.println("max :" + max);
                //Color color = new Color(max,max,max,255);
                val = (0xff << 24) | (max << 16) | (max << 8) | max;
            }
            else if ( this.type == NEGATIVEIMAGE){
                red = 255-red;
                blue =255-blue;
                green = 255 - green;
                val = (0xff << 24) | ( red << 16 ) | ( green << 8 ) | blue ;
            }
            return val;
        }
    }
    private static class GrayScaleFilter2 extends ImageFilter{
        static int count = 0;
        public GrayScaleFilter2(){

        }

        @Override
        public void imageComplete(int status) {
            consumer.imageComplete(status);
        }

        @Override
        public void setPixels(int x, int y, int w, int h, ColorModel model, int[] pixels, int off, int scansize) {
            //System.out.println("x,y,w,h, pixels.length , scansize , off "+ x + ", "+ y + ", "+ w +", "+ h + ", "+ pixels.length + ", "+ off + ", "+scansize);
            //System.out.println("count :"+ count++);
            int  red , green, blue, color , max;
            for ( int r = 0 ; r < h; r++){
                for ( int c = 0 ; c < scansize; c++){
                    if ( c < w){
                        //convert it to gray image
                        red = model.getRed(pixels[ r*scansize + c + off]);
                        green = model.getBlue( pixels[ r*scansize + c + off]);
                        blue = model.getBlue( pixels[ r*scansize + c + off]);
                        max = ((red > green) ? (red > blue ? red : blue) : ((green > blue) ? green : blue)) & 0xff;
                        color = (0xff << 24) | ( max << 16 ) | ( max << 8 )| max;
                        pixels[r*scansize + c + off] = color;
                        Color cc = new Color(color);
      //                  System.out.println("cc :"+ cc);
                    }

                }
            }

            if ( count == 2  || count == 1){
                for (int i = 0; i < pixels.length; i++){
                    Color cc = new Color(pixels[i]);
                    //System.out.println("Pixels["+ i+ "] :" + cc);

                }
            }
            consumer.setPixels(x,y,w,h,model,pixels,off,scansize);
        }

        @Override
        public void setPixels(int x, int y, int w, int h, ColorModel model, byte[] pixels, int off, int scansize) {
  //          System.out.println("x,y,w,h, pixels.length , scansize , off "+ x + ", "+ y + ", "+ w +", "+ h + ", "+ pixels.length + ", "+ off + ", "+scansize);
            int  red , green, blue, color , max;
            for ( int r = 0 ; r < h-y; r++){
                for ( int c = 0 ; c < scansize - x; c++){
                    if ( (c-x) < scansize){
                        System.out.println("\n\n");
                        //convert it to gray image
                        red = model.getRed(pixels[ r*scansize + c]);
                        green = model.getBlue( pixels[ r*scansize + c]);
                        blue = model.getBlue( pixels[ r*scansize + c]);
                        max = ((red > green) ? (red > blue ? red : blue) : ((green > blue) ? green : blue)) & 0xff;
                        color = (0xff << 24) | ( max << 16 ) | ( max << 8 )| max;
                        pixels[r*scansize + c] = ( byte)color;
                        Color cc = new Color(color);
//                        System.out.println("cc :"+ cc);
                    }

                }
            }
            consumer.setPixels(x,y,w,h,model,pixels,off,scansize);
        }

        @Override
        public void setColorModel(ColorModel model) {
            consumer.setColorModel(model);
        }

        @Override
        public void setDimensions(int width, int height) {
            consumer.setDimensions(width, height);
        }

        @Override
        public void setHints(int hints) {
            consumer.setHints(hints);
        }

        @Override
        public void setProperties(Hashtable<?, ?> props) {
            consumer.setProperties(props);
        }
    }

}
