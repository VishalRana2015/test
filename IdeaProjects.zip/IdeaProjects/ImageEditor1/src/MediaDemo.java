
public class MediaDemo {
    public static void main(String[] args) {

    }
}
