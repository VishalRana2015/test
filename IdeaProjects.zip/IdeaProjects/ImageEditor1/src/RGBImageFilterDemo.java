import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.image.*;
import javax.imageio.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

public class RGBImageFilterDemo {
    public static void main(String[] args) {
        JFrame frame = new JFrame("RGBImageFilter Demo");
        frame.setSize(500,500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocation(50,0);
        JPanel panel = new JPanel();
        panel.setLayout(null);
        String filename = "C:\\Users\\RANA1947\\Desktop\\testimage.gif";
        ImageIcon icon = new ImageIcon(filename);
        if ( icon == null){
            System.out.println("icon is null");
        }
        MyComponent comp = new MyComponent(icon.getImage());
        comp.setLocation(20,20);
        comp.setBorder( BorderFactory.createLineBorder(Color.BLACK));
        panel.add(comp);
        panel.setBackground(new Color(255,0,120));
        frame.setContentPane(panel);
        frame.setVisible(true);
    }

    private static class MyComponent extends JComponent{
        int ww, hh;
        Image image ;
        public MyComponent(Image image ){
            this.ww = image.getWidth(null);
            this.hh= image.getHeight(null);
            this.setSize(ww,hh);
            this.image = image;
            MyFilter filter = new MyFilter(Color.WHITE,0.0f);
            FilteredImageSource fis = new FilteredImageSource(image.getSource(),filter);
            MyImageObserver observer = new MyImageObserver(this);
            this.image = createImage(fis);
            prepareImage(this.image,observer);
            // For the current situations prepareImage is better option
           /* MediaTracker tracker = new MediaTracker(this);
            tracker.addImage(this.image,1);
            try{
                tracker.waitForID(1);
            }catch( Exception e){
                System.out.println("Exception caught :"+ e.getMessage());
            }
           */ System.out.println("count : "+MyFilter.csount);
            System.out.println("ww : "+ ww + " hh :"+ hh);
            this.addMouseListener(new MouseListener() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    MyComponent comp = (MyComponent) e.getSource();
                    comp.repaint();
                    File file = new File("C:\\Users\\RANA1947\\Desktop\\testimagep.png");
                    if (!file.exists()) {
                        try {
                            file.createNewFile();
                        } catch (Exception exp) {
                            System.out.println("Exception caught :" + exp.getMessage());
                        }
                    }
                    BufferedImage bimage = new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_RGB);
                    Graphics2D gg = (Graphics2D)bimage.getGraphics();
                    gg.drawImage(image, 0 , 0 , image.getWidth(null), image.getHeight(null), null);
                    gg.dispose();
                    try{
                        ImageIO.write(bimage,"png",file);
                        file = new File("C:\\Users\\RANA1947\\Desktop\\testimageg.gif");
                        if ( !file.exists())
                            file.createNewFile();
                        ImageIO.write(bimage,"gif",file);
                        file = new File("C:\\Users\\RANA1947\\Desktop\\testimagej.jpg");
                        if ( !file.exists())
                            file.createNewFile();
                        ImageIO.write(bimage,"jpg",file);
                    }
                    catch(Exception exp){
                        System.out.println("Excepton caught :"+ exp.getMessage());
                    }
                }

                @Override
                public void mousePressed(MouseEvent e) {

                }

                @Override
                public void mouseReleased(MouseEvent e) {

                }

                @Override
                public void mouseEntered(MouseEvent e) {

                }

                @Override
                public void mouseExited(MouseEvent e) {

                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int x, y , w, h;
            w = this.ww - (this.getInsets().left + this.getInsets().right);
            h = this.hh - (this.getInsets().top + this.getInsets().bottom);
            x = (int)g.getClipBounds().getX();
            y = (int)g.getClipBounds().getY();
            Graphics2D gg = (Graphics2D)g.create();
            try{
                gg.drawImage(image , x,y, w, h , null);
            }
            catch(Exception e){
                System.out.println("Exception Image is null");
            }
            gg.dispose();
        }
    }
    private static class MyFilter extends RGBImageFilter{
        Color color ;// Color to make transparent
        float alpha;
        public MyFilter( Color color, float alpha ) throws IllegalArgumentException {
            this.color = color;
            if ( alpha < 0.0f & alpha > 1.0f)
                throw new IllegalArgumentException("alpha should be in the range 0.0f to 1.0f");
            this.alpha = alpha;
            canFilterIndexColorModel = true;

        }
        public static int csount = 0;
        @Override
        public int filterRGB(int x, int y, int rgb) {
            if ( csount == 0 ) {
                System.out.println("filter method called for the first time");
                csount++;
            }
            else
                csount ++;
            int alphatemp , c;
            System.out.println("rgb :"+ rgb);
            c = color.getRGB();
            if ( rgb == c){
                System.out.println("rgb = c for (x,y) : "+ x + ","+ y );
                alphatemp = (c>>24)&0xff;
                alphatemp = (int)(this.alpha * alphatemp);
                c = ((alphatemp<<24) & 0xff000000) |  ( c & 0x00ffffff) ;

            }
            else
                c = rgb;
            csount  = csount + 1;
            return c;
        }

        @Override
        public void imageComplete(int status) {
            super.imageComplete(status);
            consumer.imageComplete(status);
            System.out.println("Image has been loaded" + Thread.currentThread().toString());
        }
    }
    static class MyImageObserver implements ImageObserver{
        MyComponent comp ;
        public MyImageObserver( MyComponent comp){
            this.comp = comp;
        }
        @Override
        public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {
            System.out.println("Image Observer called " + img.toString() + " x, y , width , height "+ x + ", " + y + ", "+width + ", "+ height);
            comp.repaint();
            System.out.println("current Thread :"+ Thread.currentThread().toString());
            try{
                Thread.currentThread().sleep(20);
            }
            catch(Exception e){
                System.out.println("Exception thrown :"+ e.getMessage());
            }
            return true;
        }
    }

}
