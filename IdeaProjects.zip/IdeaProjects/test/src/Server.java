import java.net.*;
import java.io.*;

public class Server {
    public static void main(String[] args) {
        try{
            ServerSocket ss = new ServerSocket(20000);
            int i =1;
            System.out.println("Server started to listen at port 20000");
            while( true){
                // infinite loop
                Socket socket = ss.accept();
                MyThread runn = new MyThread("Client" +i,socket);
                i = i++;
                Thread thread = new Thread(runn);
                thread.start();
                System.out.println("Thread started");
            }
        }
        catch( Exception e){
            System.out.println("Exception caugth :"+ e.getMessage());
        }
    }
    public static class MyThread implements Runnable{
        String name;
        Socket socket;
        MyThread(String name , Socket socket){
            this.name = name;
            this.socket = socket;
        }
        @Override
        public void run() {
            System.out.println("run method invoked for client :"+ name);
            try{
                InputStream in = socket.getInputStream();
                OutputStream out =socket.getOutputStream();
                ObjectInputStream oin = new ObjectInputStream ( in);
                Message m;
                while (  (m = (Message)oin.readObject() ) != null){
                    System.out.println("Something is readed");
                    System.out.println(m);
                }
            }
            catch( Exception e){
                System.out.println("Exception caught " + e.getMessage());
            }
            System.out.println("Getting out of run method");
        }
    }
}
