import java.net.*;
import java.io.*;
// This method clearly demonstrate how the objectInputStream can be used to read objects sent by the user in blocking mode.
public class Client {
    public static void main(String[] args) {
        try{
            Socket socket = new Socket("localhost",20000);
            System.out.println("Connection established");
            System.out.println("Writing a message object to the socket stream");
            Message m1 = new Message("This is Message 1 object");
            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
            oos.writeObject(m1);
            System.out.println("Object written");
            System.out.println("Now sleeping for 10 seconds");
            Thread.sleep(10000);
            System.out.println("After waking up");
            Message m2 = new Message("Writing another message to the socket output stream");
            oos.writeObject(m2);
            System.out.println("Written");
            System.out.println("Now closing the connection");
        }
        catch (Exception e){
            System.out.println("Exception caught :"+ e.getMessage());
        }
        System.out.println("Closed");
    }
}
