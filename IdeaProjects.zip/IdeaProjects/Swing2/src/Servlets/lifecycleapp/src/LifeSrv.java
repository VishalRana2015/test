package Servlets.lifecycleapp.src;

import java.io.*;
import java.sql.SQLException;
import javax.servlet.*;

public class  LifeSrv implements Servlet{
    public void init(ServletConfig config) throws ServletException{
        System.out.println("I am the init method");

    }
    public void service(ServletRequest reg, ServletResponse res) throws ServletException,IOException{
        System.out.println("I am the Service method");
    }
    public void destroy(){
        System.out.println("I am the destroy method");
    }
    public String getServletInfo(){
        return "servlet Version 3.x";
    }
    public ServletConfig getServletConfig( ){
        return null;
    }
}