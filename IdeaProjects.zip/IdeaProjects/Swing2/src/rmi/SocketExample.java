package rmi;
import java.rmi.*;

public class SocketExample {
}
