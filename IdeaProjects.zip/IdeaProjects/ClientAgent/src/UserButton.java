import javax.swing.*;

public class UserButton {
    private JButton userButtonButton;
    private JPanel panel1;

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
