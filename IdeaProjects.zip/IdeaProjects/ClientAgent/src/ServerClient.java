import java.awt.event.KeyEvent;
import java.net.*;
import java.io.*;
import java.util.*;
public class ServerClient implements Runnable {
    private Socket socket;
    private int num;

    ServerClient( Socket socket , int num ){
        this.num = num;
        this.socket = socket;

        Thread thread= new Thread(this, "Client "+ num);
        thread.start();
    }

    public void run(){
        String line;
        System.out.println("New Connection to the client established " + num);

        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            OutputStreamWriter ow = new OutputStreamWriter(socket.getOutputStream());
            ow.write("Welcome Client " + num);
            ow.write( "You are sending output to port " + socket.getLocalPort() + " on server from "+ socket.getPort() + " from your machine.");
            ow.write("YOur IP address :" + socket.getRemoteSocketAddress());
            ow.write("Server Socket Address :"+ socket.getLocalSocketAddress());
            ow.flush();
            while ( true){
               // Always in mode or reading something from the clinet
                line = br.readLine();
                if ( line == null){
                    System.out.println(num + "Closed.");
                    ow.write(KeyEvent.CTRL_DOWN_MASK + KeyEvent.VK_CLOSE_BRACKET);
                    ow.flush();
                    return;
                }
                else{
                    if ( line.equalsIgnoreCase("exit") ){
                        System.out.println(num + "Closed.");
                        ow.write(KeyEvent.CTRL_DOWN_MASK + KeyEvent.VK_C);
                        ow.flush();
                        return;
                    }
                    else{
                        System.out.println(num + " echo Client : " + line);
                        ow.write("Waiting for next line \n");
                        ow.flush();
                    }
                }
            }
        }catch( Exception e){
            System.out.println("Exception caught : "+ e.getMessage());

        }
    }

    public static void main(String[] args) {
        ServerSocket ss;
        int num = 0;
        try{
            ss= new ServerSocket(20000);
            // ServerSocket is listening for new connections at port 20000
            while ( true){
                // listening for the new connections until the program stopped

                Socket socket = ss.accept();
                num = num+1;
                System.out.println("Socket made for :"+ num);
                new ServerClient(socket, num);
            }
        }
        catch ( Exception e){
            System.out.println("Exception caught : "+ e.getMessage());
        }
    }
}
