import javax.imageio.ImageIO;
import java.awt.*;
import java.io.*;
import java.awt.image.*;
import java.awt.event.*;
// Robot class is used to give you control over keyboard and mouse.
public class CaptureScreenshotExample {
    public static void main(String[] args) {
        try {
            /*Robot robot = new Robot();
            Process p  = Runtime.getRuntime().exec("notepad.exe abc.txt");
            robot.keyPress(KeyEvent.VK_V);
            robot.keyPress(KeyEvent.VK_I);
            robot.keyPress(KeyEvent.VK_S);
            robot.keyPress(KeyEvent.VK_H);
            robot.keyPress(KeyEvent.VK_A);
            robot.keyPress(KeyEvent.VK_L);
            robot.keyPress(KeyEvent.VK_SPACE);
            robot.keyPress(KeyEvent.VK_R);
            robot.keyPress(KeyEvent.VK_A);
            robot.keyPress(KeyEvent.VK_N);
            robot.keyPress(KeyEvent.VK_A);
            */
            Robot robot = new Robot();
            double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
            double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
            Rectangle r   = new Rectangle(0,0,(int)width,(int)height);
            BufferedImage image  = robot.createScreenCapture(r);
            File file = new File("C:\\Users\\RANA1947\\Desktop\\image.png");
            ImageIO.write(image,"png",file);


        }catch ( Exception e ){
            System.out.println("Exception caught : "+e.getMessage());
        }
    }
}


class CaptureScreenshot{

}