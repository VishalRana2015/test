package Tools;

import com.sun.deploy.util.WinRegistry;
import javax.swing.*;
import java.awt.geom.AffineTransform;
import java.io.Serializable;
import java.time.*;
import java.util.*;
// Model of the ClientAgent application
public class TakeAction {
    public static void main(String[] args) {
        // boli orr log hain jo tujmein or mujmein

    }

}

interface Message extends Serializable  {
    // All constants have been defined here
    enum MessageType{
        LoginMessage,
        SignUpMessage,
        IAmOnlineMessage,
        IsUserOnlineMessage,
        UploadImageMessage,
        DownloadImageRequestMessage,
        AckMessage,
        UserMessage
    }
    enum Status{
        Seen,
        Deliverd,
        Send
    }
}


class Login implements  Serializable {
    String userId;
    String password;
    Message.MessageType messageType ;
    Login ( String userId, String password){
        this.userId  = userId;
        this.password = password;
        messageType = Message.MessageType.LoginMessage;
    }
}

class SignUp implements  Serializable{
    String userId;
    String password;
    Message.MessageType messageType;
    SignUp(String userId, String password ){
        this.userId = userId;
        this.password = password;
        messageType = Message.MessageType.SignUpMessage;

    }
}


class IAmOnline implements Serializable{
    String userId;
    Calendar calendar ;
    Message.MessageType messageType;
    IAmOnline(String userId,Calendar calendar){
        this.userId = userId;
        this.calendar = calendar;
        messageType = Message.MessageType.IAmOnlineMessage;
    }
}

class IsUserOnline implements Serializable{
    String userId;
    String querUsedId;
    Message.MessageType  messageType;
    IsUserOnline(String userId, String querUsedId){
        this.userId = userId;
        this.querUsedId = querUsedId;
        messageType = Message.MessageType.IsUserOnlineMessage;
    }
}

class UploadPic implements Serializable{
    String userId;
    ImageIcon icon ;
    Message.MessageType  messageType ;
    UploadPic ( String userId , ImageIcon icon ){
        this.userId = userId;
        this.icon = icon;
        messageType = Message.MessageType.UploadImageMessage;

    }
}


class DownloadPic implements Serializable{
    String userId;
    String queryUserId;
    Message.MessageType messageType ;
    DownloadPic( String userId , String queryUserId){
        this.userId = userId;
        this.queryUserId = queryUserId;
        messageType = Message.MessageType.DownloadImageRequestMessage;
    }
}

class UserMessage implements Serializable{
    String userId;
    String recepientId;
    int messageId;
    Calendar timestamp;
    byte[] messageBody;
    Message.MessageType messageType;
    Message.Status status;
    UserMessage( String userId, String recepientId, int messageId, Calendar timestamp, byte[] messageBody, Message.Status status ){
        this.userId = userId;
        this.recepientId = recepientId;
        this.messageId = messageId;
        this.timestamp = timestamp;
        this.messageBody = messageBody;
        this.status = status;
        messageType = Message.MessageType.UserMessage;
    }
}

class Acknowledgement implements Serializable{
    String senderId;
    String recepientId;
    int messageId;
    int partNo;
    Message.Status status;
    Message.MessageType messageType;
    Acknowledgement(String senderId, String recepientId, int messageId, int partNo, Message.Status status){
        this.senderId  = senderId;
        this.recepientId = recepientId;
        this.messageId = messageId;
        this.partNo = partNo;
        this.status = status;
        this.messageType  = Message.MessageType.AckMessage;
    }
}