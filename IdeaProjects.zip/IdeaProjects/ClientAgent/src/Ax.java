import java.nio.file.Files;
import java.util.*;
import java.awt.*;
import java.io.*;
import java.nio.file.*;
import javax.crypto.*;
import java.security.*;
public class Ax {
    public static void main(String[] args) {
        try{
            File file = new File("C:\\Users\\RANA1947\\IdeaProjects\\ClientAgent\\Images\\pic.jpeg");

            File file2 = new File("C:\\Users\\RANA1947\\IdeaProjects\\ClientAgent\\Images\\pic2.jpg");
            file2.createNewFile();
            FileOutputStream fos = new FileOutputStream ( file2);
            FileInputStream fis = new FileInputStream(file);
            InputStream ifis = fis;

            KeyGenerator keygen = KeyGenerator.getInstance("AES");
            Key key = keygen.generateKey();
            System.out.println(key.getAlgorithm());
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE,key);
            cipher.update("Hello world".getBytes());
            byte[] encrypted = cipher.doFinal();
            System.out.println(Arrays.toString(encrypted));
            cipher.init(Cipher.DECRYPT_MODE,key);
            System.out.println(cipher.update(encrypted));
            System.out.println(new String(cipher.doFinal()));
            System.out.println(key.toString().getBytes("UTF-8"));
            System.out.println("\n\nWorking with RSA in java");
            KeyPairGenerator keypairgen = KeyPairGenerator.getInstance("RSA");
            keypairgen.initialize(512);
            KeyPair keypair = keypairgen.generateKeyPair();
            Key prv = keypair.getPrivate();
            Key pub = keypair.getPublic();
            System.out.println("private key = "+prv.toString());
            System.out.println("public key = " +pub.toString());
            Cipher cipherrsa = Cipher.getInstance("RSA");
            cipherrsa.init(Cipher.ENCRYPT_MODE,pub);
            byte[] e1, e2, e3, e4;
            e1 = cipherrsa.update("Hello world ".getBytes());
            System.out.println("encrypted = " +new String(e1));
            e2 = cipherrsa.doFinal();
            System.out.println("encrypted = "+ new String(e2));

            cipherrsa.init(Cipher.DECRYPT_MODE,prv);
            e3 = cipherrsa.update(e2);
            System.out.println("e3 = "+ new String(e3));

            e4 = cipherrsa.doFinal();
            System.out.println("e4 = "+ new String(e4));

            fos.close();
            fis.close();
        }catch ( Exception e ){
            System.out.println("Exception caught : " + e.getMessage());
        }
    }
}
