import javax.swing.*;
import javax.swing.border.BevelBorder;
import java.awt.*;
public class DisplayFrame {
    public static void displayFrame(){
        JFrame frame = new JFrame("Monitering Service ");
        frame.setSize(1200,700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setContentPane(makeTabbedPane());
        frame.setVisible(true);

    }
    public static  JTabbedPane makeTabbedPane(){
        JTabbedPane tabPane = new JTabbedPane();
        JPanel toolPanel = MakeToolPane();
        tabPane.add("Tools and Restriction ", toolPanel);
        return tabPane;
    }
    public static JPanel MakeToolPane(){
        JPanel toolPanel = new JPanel();
        toolPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        Box box = new Box(BoxLayout.Y_AXIS);
        box.setAlignmentX(0.0f);
        JLabel systemActionLabel = new JLabel("System Actions ");
        box.setAlignmentX(0.0f);
        box.add(systemActionLabel);
        box.setAlignmentX(0.0f);
        box.add(Box.createVerticalStrut(5));
        JPanel systemActionPanel = makeSystemActionPanel();
        box.add(systemActionPanel);
        box.add( Box.createVerticalStrut(20));
        JLabel websiteActionLabel  = new JLabel("Open Website");
        box.add(websiteActionLabel);
        box.add( Box.createVerticalStrut(4));
        JPanel websitePanel = makeWebsitePanel();
        box.add(websitePanel);
        box.add(Box.createVerticalStrut(20));
        toolPanel.add(box);
        return toolPanel;
    }
    public static JPanel makeWebsitePanel(){
        JPanel websitePanel = new JPanel();
        Box box = new Box(BoxLayout.Y_AXIS);
        JLabel labelinfo = new JLabel();
        labelinfo.setText("Open a webiste on remote computer. Enter full URL ");
        JTextField urlField = new JTextField(80);
        box.add(urlField);
        JButton openWebsiteButton = new JButton("Open");
        box.add(openWebsiteButton);
        websitePanel.add(box);
        return websitePanel;
    }
    public static JPanel makeSystemActionPanel( ){
        JPanel systemActionPanel = new JPanel();
        systemActionPanel.setBorder( BorderFactory.createBevelBorder(BevelBorder.RAISED));
        systemActionPanel.setLayout(new GridLayout(4,4));
        //Box box = Box.createHorizontalBox();

        JButton powerOffButton = new JButton("Shutdown");
        JButton rebootButton = new JButton( "Reboot");
        JButton hibernateButton = new JButton("Hibernate");
        JButton logOffButton = new JButton("Log Off");
        JButton lockUSBButton = new JButton ("Lock USB");
        JButton unlockUSBButton = new JButton ("Unlock USB");
        JButton lockDVDRomButton = new JButton("Lock CD/DVD ROM ");
        JButton unlockDVDRomButton = new JButton("Unlock CD/DVD Rom");
        JButton disableTaskMgrButton = new JButton ("Disable Task Manager ");
        JButton enableTaskMgrButton = new JButton("Enable Task Manager");

        GridLayout layout =new GridLayout(4,4);
        layout.setHgap(10);
        layout.setVgap(5);
        systemActionPanel.setLayout( layout);
        systemActionPanel.add(powerOffButton);
        systemActionPanel.add(rebootButton);
        systemActionPanel.add(hibernateButton);
        systemActionPanel.add(logOffButton);
        systemActionPanel.add(lockUSBButton);
        systemActionPanel.add(unlockUSBButton);
        systemActionPanel.add(lockDVDRomButton);
        systemActionPanel.add(unlockDVDRomButton);
        systemActionPanel.add(disableTaskMgrButton);
        systemActionPanel.add(enableTaskMgrButton);

        return systemActionPanel;
    }
}
