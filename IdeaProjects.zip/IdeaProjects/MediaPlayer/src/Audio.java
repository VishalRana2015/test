import sun.audio.AudioStream;
import sun.security.tools.keytool.Main;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.*;
import java.net.URL;
import java.io.*;

public class Audio {
    public static Mixer mixer;
    public static Clip clip;
    public static void main(String[] args) {
        Mixer.Info[] mixinfos = AudioSystem.getMixerInfo();
        for ( Mixer.Info info : mixinfos){
            System.out.println(info.getName() + " --- " + info.getDescription());
        }

       mixer = AudioSystem.getMixer(mixinfos[0]);
       System.out.println("Mixer created");
       DataLine.Info dataInfo  = new DataLine.Info(Clip.class,null);
       System.out.println("data line generated");
       try {
           clip  = (Clip)mixer.getLine(dataInfo);
           System.out.println("clip generated");
       }
       catch( Exception e){
           System.out.println("Exception cuaght :"+ e.getMessage());
           System.out.println("e.stacktrace ");
           e.printStackTrace();
       }

       try{
           URL soundurl  = Main.class.getResource("F:\\Vishal\\Downloads\\Sai.mp3");
           if ( soundurl == null){
               System.out.println("url is empty");
           }
           else
               System.out.println("URL is not empty");
           System.out.println("URL created");
           File file = new File("F:\\Vishal\\Downloads\\ss.wav");
           AudioInputStream audioinputstream = AudioSystem.getAudioInputStream(file);

           System.out.println("audioinputStream created");

           System.out.println("clip generated from AudioSystem");
           clip.open(audioinputstream);
           System.out.println("Clip opened");
           clip.start();
           System.out.println("Clip started");
       }
       catch( Exception e){
           System.out.println("Exception caught :"+ e.getMessage());
           e.printStackTrace();
       }

    }
}
