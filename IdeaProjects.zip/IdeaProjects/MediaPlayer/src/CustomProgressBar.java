import javax.swing.event.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.*;

public class CustomProgressBar extends JProgressBar{
    int gap = 4;
    static Handle handle;
    private boolean hover = false;
    static {
        handle = new Handle();
    }
    protected boolean isHover(){
        return hover;
    }

    protected void setHover(boolean hover) {
        this.hover = hover;
    }

    public CustomProgressBar (){
        super();
        this.addMouseListener(handle);
        this.addMouseMotionListener(handle);
    }
    public CustomProgressBar(int orient , int min , int max){
        super(orient,min,max);
        this.addMouseListener(handle);
        this.addMouseMotionListener(handle);
    }
    public CustomProgressBar( BoundedRangeModel model){
        super(model);
        this.addMouseListener(handle);
        this.addMouseMotionListener(handle);
    }
    public CustomProgressBar ( int min, int max){
        super(min,max);
        this.addMouseListener(handle);
        this.addMouseMotionListener(handle);
    }

    public void setGap(int gap) {
        this.gap = gap;
    }

    public int getGap() {
        return gap;
    }

    @Override
    protected void paintComponent(Graphics g) {
        //super.paintComponent(g);
       // System.out.println("Paint component called");
        Graphics2D gg = (Graphics2D)g.create();
        int x, y , w, h;

        x = (int)gg.getClipBounds().getX() + this.getInsets().left ;
        y = (int)gg.getClipBounds().getY() + this.getInsets().top;
        w = (int)gg.getClipBounds().getWidth() -(this.getInsets().left + this.getInsets().right);
        h = (int)gg.getClipBounds().getHeight() - (this.getInsets().top + this.getInsets().bottom);
        //System.out.println("x,y,w,h :"+x+","+y+","+w+","+h);
        gg.setColor(this.getBackground());
        gg.fillRect(x,y,w,h);
        int min , max, curr;
        min = this.getMinimum();
        max = this.getMaximum();
        curr = this.getValue();
        //System.out.println("min,max, curr :"+ min + ","+ max + ","+ curr);
        double per =  ( (curr - min) /(double)(max-min)) ;
        //System.out.println("per :"+ per);
        gg.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        gg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);


        if ( this.getOrientation() ==JProgressBar.HORIZONTAL){
            int fx , fy , sx , sy ,cx, cy , lw , radius  , length , lfc;

            length = w  - 2*gap;
            radius = h/2;
            fx = x + gap;
            lw = h/2;
            lfc = length - 2*radius;
            fy = y + h/2 - lw/2;
            sx = fx + (int)(per *  length);
            sy = fy ;
            cx = x + gap + (int)( per* lfc);
            cy = y;
         //   System.out.println("fx, fy :"+ fx + ","+fy);
            gg.setColor(new Color(120,120,0));
           // System.out.println("per * length :"+ (per* length));
            gg.fillRoundRect(fx,fy , cx-fx+ radius, h/2, h/2 , h/2);
            gg.setColor(Color.BLACK);
            gg.drawRoundRect(fx,fy , cx-fx + radius, h/2, h/2 , h/2);

            //System.out.println("sx, sy :"+ sx + ","+ sy);
            //System.out.println("length : "+ length);
            gg.setColor(new Color(120,120,120));
            gg.fillRoundRect(cx +radius ,sy , (int)(((per - 1)* lfc)) + radius , h/2, h/2 , h/2);
            gg.setColor( Color.BLACK);
            gg.drawRoundRect(cx +radius, sy,(int)(((1-per)* lfc)) + radius , h/2, h/2 , h/2);

            gg.setColor( new Color(120,120,0));
            Shape circle = new Ellipse2D.Double(cx,cy,2*radius, 2*radius);
            gg.fill(circle);
            gg.setColor(Color.BLACK);
            gg.draw(circle);
            //System.out.println("Progress Bar drawned");
        }
        else if ( this.getOrientation() == JProgressBar.VERTICAL){
            int fx, fy , sx, sy , cx, cy , radius, length , lw , lfc; // lfc stands for 'length for circle'
            lw = w/2;
            radius = w/2;
            length = h - 2*gap;
            fx = x + w/2 - lw/2;
            fy = y + gap;
            gg.setColor( new Color(120,120,0));
            gg.fillRoundRect(fx,fy,lw,(int)(per * length) , w/2,w/2);
            gg.setColor(new Color(0,0,0));
            gg.drawRoundRect(fx,fy,lw,(int)(per* length) , w/2 , w/2);
            sx = fx;
            sy = fy + (int)( per * length);
            gg.setColor( new Color(120,120,120));
            gg.fillRoundRect(sx,sy,lw, (int)((1-per)*length) , w/2, w/2);
            gg.setColor(new Color(0,0,0));
            gg.drawRoundRect(sx,sy,lw,(int)((1-per)*length), w/2,w/2);
            lfc = length- 2*radius;
            cy = y + gap + (int)(per * lfc);
            cx  = x;
            Shape shape = new Ellipse2D.Double(cx,cy,2*radius,2*radius);
            gg.setColor(new Color(120,120,0));
            gg.fill(shape);
            gg.setColor(Color.BLACK);
            gg.draw(shape);
            //System.out.println("painted");

        }
        else{
            System.out.println("Unknown orientation ");
        }
    }
    static class Handle implements MouseListener , MouseMotionListener{
        @Override
        public void mouseReleased(MouseEvent e) {
            System.out.println("Mouse Realeased Event ");
            if ( !(e.getSource() instanceof CustomProgressBar))
                return;
            CustomProgressBar bar  = (CustomProgressBar)e.getSource();
            if ( bar.isHover())
                bar.setHover(false);

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mousePressed(MouseEvent e) {
            System.out.println("mouse Pressed");
            CustomProgressBar bar = (CustomProgressBar)e.getSource();
            int cx, cy , gap , min, max , curr , radius;
            gap= bar.getGap();
            min  = bar.getMinimum();
            max =bar.getMaximum();
            curr = bar.getValue();
            double per = (curr -min)/(double)(max-min);
            System.out.println("IN mousePressed per :"+ per);
            int x, y , w, h;
            x=   bar.getInsets().left;
            y = bar.getInsets().top ;
            w = (int)bar.getSize().getWidth() - (bar.getInsets().left + bar.getInsets().right);
            h = (int)bar.getSize().getHeight() - (bar.getInsets().top + bar.getInsets().bottom);
            int lfc ; // length for circle
            System.out.println("x,y,w,h" + x + ","+ y + ","+ w + "," + h);
            gap = bar.getGap();
            System.out.println("gap :"+ gap);
            System.out.println("Pressed Point :"+ e.getPoint());
            if ( bar.getOrientation() == JProgressBar.HORIZONTAL){
                // check whether the press occurred on the circle
                radius = h/2;
                lfc= w - 2*gap - 2*radius;
                Shape shape = new Ellipse2D.Double(x+gap + (int)(lfc* per),y,2*radius ,2*radius);
                System.out.println("Shape : "+ shape.getBounds());
                if ( shape.contains(new Point(e.getX(), e.getY()))){
                    System.out.println("on the circle");
                    bar.setHover(true);
                }
                else{
                    System.out.println("Outside the circle");
                    bar.setHover(false);
                }
            }
            else if ( bar.getOrientation() == JProgressBar.VERTICAL){
                radius = w/2;
                lfc = h -2*gap - 2*radius;
                cx = x;
                cy = y + gap + (int)(lfc * per);
                Shape shape = new Ellipse2D.Double(cx, cy , 2*radius, 2*radius);
                System.out.println("shape :"+ shape.getBounds());
                if ( shape.contains(new Point(e.getX(), e.getY()  ))){
                    System.out.println("On the circle ");
                    bar.setHover(true);
                }
                else{
                    System.out.println("outside the circle");
                    bar.setHover(false);
                }
            }
            else{
                System.out.println("Unknown Orientation ");
            }
        }

        @Override
        public void mouseClicked(MouseEvent e) {

        }

        @Override
        public void mouseMoved(MouseEvent e) {
        }

        @Override
        public void mouseDragged(MouseEvent e) {

            if ( !(e.getSource() instanceof CustomProgressBar))
                return;
            CustomProgressBar bar = (CustomProgressBar)e.getSource();
            if ( bar.isHover()) {

                int cx, cy , mx, my, min, max, curr , gap , w, h , sx, ex, sy , ey  , radius , barlength;
                mx = e.getX();
                my = e.getY();
                min = bar.getMinimum();
                max = bar.getMaximum();
                curr = bar.getValue();
                gap = bar.getGap();
                w = (int)bar.getBounds().getWidth()- (bar.getInsets().left + bar.getInsets().right);
                h = (int)bar.getBounds().getHeight()- (bar.getInsets().top + bar.getInsets().bottom);
                cx = bar.getInsets().left;
                cy = bar.getInsets().top;

                double per = (curr -min)/(double)(max-min);
                if ( bar.getOrientation() == JProgressBar.HORIZONTAL){
                    radius = h/2;
                    barlength = w - 2*gap;
                    sx = cx + gap + radius;
                    ex  = sx + barlength - 2*radius;
                    //System.out.println("sx , ex :"+ sx + ","+ ex);
                    if ( mx < sx){
                        bar.setValue(min);
                    }
                    else if ( mx > ex){
                        bar.setValue(max);
                    }
                    else{
                        per= (mx-sx)/(double)(ex-sx);
                        int val = (int)(per *(max-min) );
                        bar.setValue(val);
                    }

                }
                else if ( bar.getOrientation()  == JProgressBar.VERTICAL){
                    System.out.println("Currently not implemented");
                    radius = w/2;
                    barlength = h- 2*gap;
                    sy = cy + gap + radius;
                    ey = sy + barlength - 2*radius;
                    if ( my < sy )
                        bar.setValue(min);
                    else if ( my > ey)
                        bar.setValue(max);
                    else{
                        per  = ( my - sy)/(double)(ey-sy);
                        int val = (int)(per * (max-min));
                        bar.setValue(val);
                    }
                }
                else
                    System.out.println("Unknown orientation.");
            }
        }
    }
    public static void main(String[] args) {
        JFrame frame = new JFrame("Custom Progress Bar Test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        CustomProgressBar bar = new CustomProgressBar(JProgressBar.HORIZONTAL, 0, 100);
        bar.setSize(new Dimension(400,50));
        bar.setLocation(50,50);
        bar.setBorder(BorderFactory.createLineBorder(Color.ORANGE));
        panel.setLayout(null);
        bar.setValue(40);
        panel.add(bar);
        frame.setContentPane(panel);
        JPanel panel2 = new JPanel();
        panel2.setLayout(null);
        CustomProgressBar bar2 = new CustomProgressBar(JProgressBar.VERTICAL, 0, 100);
        bar2.setValue(0);
        bar2.setSize(50,300);
        bar2.setLocation(50,50);
        panel2.add(bar2);
        frame.setContentPane(panel);
        frame.setVisible(true);
    }
}
