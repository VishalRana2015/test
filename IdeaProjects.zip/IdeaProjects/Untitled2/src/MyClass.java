
import retrofit2.*;
import retrofit2.http.*;
public class MyClass {
    public static void main(String[] args) {
        System.out.println("Hello world");
    }
}
