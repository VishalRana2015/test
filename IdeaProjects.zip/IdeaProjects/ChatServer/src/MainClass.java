import javax.crypto.KeyGenerator;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.security.Key;
import java.security.SecureRandom;
import java.sql.*;
import java.util.*;
import java.io.*;
import javax.imageio.*;
import java.awt.image.*;
import javax.crypto.*;
public class MainClass{
    public static void main(String[] args) {

    }
    static void ManipulateImage(){
        ImageIO imageio ;
        String[] format = ImageIO.getReaderFormatNames();
        try {
            File file = new File("C:\\Users\\RANA1947\\IdeaProjects\\ChatServer\\Images\\table.jpeg");
            BufferedImage image = ImageIO.read(file);
            int w,h, nw, nh ;
            w = image.getWidth();
            h = image.getHeight();

            KeyGenerator keygen = KeyGenerator.getInstance("AES");
            keygen.init(new SecureRandom());
            Key key = keygen.generateKey();
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE,key);

            nw = 600;
            nh = (nw*h)/w;
            BufferedImage nimage =new BufferedImage(nw,nh,BufferedImage.TYPE_INT_RGB);
            System.out.println(image.getColorModel());
            int j  = image.getRGB(100,100);
            System.out.println("do here ");
            int alpha, red, green , blue;
            //alpha= image.getColorModel().getAlpha(j);
            red = (j>>16) & 0xff;
            green = ( j>>8)& 0xff;
            blue = (j)&0xff;
            int colorvalue, ox,oy ;
            int ncolorvalue;
            for ( int x =0; x < nw; x++){
                for (int y =0; y < nh ; y++){
                    ox = (x*w)/nw;
                    oy = (y*h)/nh;
                    colorvalue = image.getRGB(ox,oy);
                    red = (colorvalue>>16) & 0xff;
                    ncolorvalue = (red<<8) | 0 | 0;
                    nimage.setRGB(x,y, ncolorvalue);

                }
            }

            File nfile = new File("C:\\Users\\RANA1947\\IdeaProjects\\ChatServer\\Images\\tablegreen.jpeg");
            ImageIO.write(nimage,"jpeg",nfile);
            System.out.println("Object written successfully");
        }
        catch( Exception e){
            System.out.println("Excepton caught : "+ e.getMessage());
        }
    }
    static void writeObject ( Connection conn){
        try{
            //Writing an blob object to the database
            PreparedStatement ps = conn.prepareStatement("insert into aux values ( ? , ? )");
            ps.setString(1,"ranaabhishek1947@gmail.com");
            KeyGenerator keygen = KeyGenerator.getInstance("AES");
            keygen.init(new SecureRandom());
            Key key = keygen.generateKey();

            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            ObjectOutputStream os = new ObjectOutputStream(bo);
            os.writeObject(key);
            System.out.println("key.getFormat() : "+key.getFormat());
            System.out.println("new String(key.getEncoded()) : "+ (new String( key.getEncoded())));
            System.out.println("key.toString() : "+ key.toString());
            os.close();
            ByteArrayInputStream bi = new ByteArrayInputStream( bo.toByteArray());
            ps.setBlob(2,bi);
            ps.executeUpdate();
            System.out.println("values inserted in the database");

        }
        catch( Exception e){
            System.out.println("Exception caught :"+ e.getMessage());
        }
    }



    static void readObject( Connection conn){
        try{
            PreparedStatement ps  = conn.prepareStatement("select * from aux");
            ResultSet rs = ps.executeQuery();
            Key key;
            while( rs.next()){
                System.out.println("UserId: " + rs.getString(1));
                Blob b = rs.getBlob(2);
                System.out.println("Readed Blobl object");
                ObjectInputStream oi = new ObjectInputStream(b.getBinaryStream());
                System.out.println("ObjectStream initialized");
                key = (Key)oi.readObject();
                System.out.println("Object readed from the stream");
                System.out.println("key Algorithm : " + key.getAlgorithm());
                System.out.println("key.toString() : "+ key.toString());
                System.out.println("key.getFormat() : "+ key.getFormat());
                System.out.println("new String( key.getEncoded()) :"+ (new String( key.getEncoded())));
            }
        }catch( Exception e){
            System.out.println("Exception caught : "+ e.getMessage());
        }
    }
}

class A implements Serializable {
    int a, b;
    A(int a, int b){
        this.a = a;
        this.b = b;
    }
    public int getA(){
        return a;
    }
    public void setA(int a){
        this.a= a;
    }
}