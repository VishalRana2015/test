import javax.crypto.KeyGenerator;
import javax.jws.soap.SOAPBinding;
import java.io.ByteArrayOutputStream;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;
import java.net.*;
import java.security.*;
import java.rmi.*;
import java.io.*;
import java.sql.*;
import java.lang.annotation.*;
public class ClientServiceMethodImpl implements Remote{
    public static void main(String[] args) {
        try {
            ClientServiceMethodImpl cl = new ClientServiceMethodImpl();
            UnicastRemoteObject.exportObject(cl, 50000);
            System.out.println("Object exported ");
        }catch( Exception e){
            System.out.println("Exception occurred : "+ e.getMessage());
        }
    }
    public static UserKeys SignUp(String userid , String password)  throws RemoteException,IDAlreadyExistsException, ClassNotFoundException, SQLException{
        UserKeys obj = null;
        Class.forName("oracle.jdbc.driver.OracleDriver");
        Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/XE","system","password");
        PreparedStatement ps = conn.prepareStatement("select userid from users");
        ResultSet rs = ps.executeQuery();
        String id;
        while ( rs.next()){
            id= rs.getString(1);
            if ( id.equals(userid))
                throw ( new IDAlreadyExistsException(id));
        }
        // Signup
        ps= conn.prepareStatement("insert into users values ( ? , ?) ");
        ps.setString(1,userid);
        ps.setString(2,password);
        ps.executeUpdate();
        // Create Database key for this user
        try {
            KeyGenerator keygen = KeyGenerator.getInstance("AES");
            keygen.init(new SecureRandom());
            Key key = keygen.generateKey();

            // Creating RSA key
            KeyPairGenerator keypairgen = KeyPairGenerator.getInstance("RSA");
            keypairgen.initialize(512,new SecureRandom());

            KeyPair keypair = keypairgen.generateKeyPair();
            obj = new UserKeys(key,keypair);


        }catch( Exception e){
            System.out.println("Exception occureed : "+ e.getMessage());
        }


        try {
            ps = conn.prepareStatement("insert into userkey values ( ? , ? )");
            ps.setString(1,userid);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            ObjectOutputStream oo = new ObjectOutputStream(bo);
            oo.writeObject(obj);
            ByteArrayInputStream bi = new ByteArrayInputStream(bo.toByteArray());
            ps.executeUpdate();
            System.out.println("Object written successfully");
            bi.close();
            oo.close();
            bo.close();
        }catch ( Exception e) {
            System.out.println("Exception occurred : " + e.getMessage());
        }

        test t  = new test();
        Annotation[] an = test.class.getAnnotations();
        for ( Annotation a : an){
            System.out.println(a.)
        }
        return obj;
    }

    public UserKeys Login( String userid , String password) throws ClassNotFoundException,SQLException, RemoteException, IDDoesNotExistsException{
        Class.forName("oracle.jdbc.driver.OracleDriver");
        Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/XE","system","password");
        Statement st = conn.createStatement();
        java.rmi.server.RMIClassLoader.getClassAnnotation(this.getClass());
    }
}

class UserKeys{
    Key DBkey;
    KeyPair RSAkeypair;
    public UserKeys(Key key , KeyPair keypair){
        this.DBkey = key;
        this.RSAkeypair = keypair;
    }
    public Key getKey(){
        return DBkey;
    }
    public KeyPair getRSAkeypair(){
        return RSAkeypair;
    }
}

class IDAlreadyExistsException extends Exception {
    IDAlreadyExistsException(String s){
        super(s);
    }
    @Override
    public String getMessage() {
        return super.getMessage() + "Already Exists";
    }
}

class IDDoesNotExistsException extends Exception {
    public IDDoesNotExistsException( String s){
        super(s);
    }

    @Override
    public String getMessage() {
        return super.getMessage() + "Does not exists ";
    }
}