import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.util.Vector;
// JLayeredPane has default null layout manager means to add a element to it you must have to specify its location and size
// abosoluty( useing setLocation and setSize or using setBounds) .For other non-null layout managers the preferredSize, minimumSize and
// maximumSize is hint to them how to layout the components of that container when the container is first laid out and validated
// every time ( e.g during resizing ).

public class LayeredPaneExample implements MouseMotionListener , ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
            System.out.println("Action Performed :"+ e.getSource());
            if ( "dukesetlayer".equalsIgnoreCase(e.getActionCommand()) == true){
                int index = box.getSelectedIndex();
                layeredpane.setLayer(dukelabel,index);
            }
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        int x , y;
        x = e.getX();
        y = e.getY();
        dukelabel.setLocation( new Point(x,y));
    }

    @Override
    public void mouseDragged(MouseEvent e) {

    }



    public static void main(String[] args) {
        new LayeredPaneExample();

    }
    JLayeredPane layeredpane ;
    JComboBox box;
    JCheckBox isonTop;
    JLabel dukelabel;
    Color[] colors;
    JLabel[] labels;
    public JLabel createColoredJLabel( Color color, int offset){
        JLabel label = new JLabel ();
        label.setVerticalAlignment(JLabel.TOP);
        label.setHorizontalAlignment(JLabel.CENTER);
        label.setOpaque(true);
        label.setPreferredSize(new Dimension(100,100));
        label.setMinimumSize(new Dimension(100,100));
        label.setMaximumSize(new Dimension(100,100));
        label.setLocation(offset+10,offset+20);

        label.setSize(new Dimension(200,200));
        //label.setBounds(offset+10,offset+20,100,100);
        label.setText(color.toString());
        label.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label.setBackground(color);

        //label.setLocation( new Point( 30 + offset, 30  + offset));
        return label;
    }
    LayeredPaneExample(){
        String [] list = {"Cyan 0","Yellow 1","RED 2", "Green 3" , "Blue 5"};
        colors = new Color[]{Color.CYAN,Color.YELLOW,Color.RED,Color.GREEN,Color.BLUE };
        labels = new JLabel[5];
        layeredpane =new JLayeredPane();
        layeredpane.setLayout(null);
        layeredpane.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK),"Move your mouse to move the duke."));
        layeredpane.setPreferredSize(new Dimension(550,550));
        layeredpane.addMouseMotionListener(this);
        for (int i =0; i < 5; i++){
            labels[i] = createColoredJLabel(colors[i],35*i);
            layeredpane.add(labels[i], new Integer(i));
        }
        System.out.println("Default layeredpane layout manager : "+ layeredpane.getLayout());
        ImageIcon duke = new ImageIcon("C:\\Users\\RANA1947\\IdeaProjects\\MyProject\\Images\\horse2.png");
        if ( duke == null){
            System.out.println("duke is null");
        }
        dukelabel = new JLabel(duke);
        dukelabel.setLocation(new Point(105,100));
        dukelabel.setSize(new Dimension(duke.getIconWidth(), duke.getIconHeight()));
        layeredpane.add(dukelabel,3);
        layeredpane.moveToFront(dukelabel);
        box = new JComboBox(list);
        isonTop= new JCheckBox();
        isonTop.setText("IsOnTOP");
        isonTop.setEnabled(true);
        isonTop.setSelected(true);
        JPanel panel1 = new JPanel();
        panel1.add(box);
        box.addActionListener(this);
        box.setActionCommand("dukesetlayer");
        panel1.add(isonTop);
        JPanel panel2= new JPanel();
        panel2 = new JPanel();
        layeredpane.setOpaque(true);
        layeredpane.setVisible(true);
        panel2.add(layeredpane);
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700,700);
        frame.setLocation(50,0);
        frame.setVisible(true);
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel,BoxLayout.PAGE_AXIS));
        panel.add(panel1);
        panel.add(panel2);
        frame.setContentPane(panel);
    }

}