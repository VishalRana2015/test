import javax.swing.*;
import java.awt.*;
import java.sql.Time;
import java.util.Calendar;


public class VLoginAndSignupControl {
    VLoginAndSignupControl(){
        JFrame frame =new JFrame();
        frame.setSize( 500, 500);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Creating top level tabpane
        JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
        // Creating Login Window
        JPanel loginPanel = createLoginPanel();
        tabbedPane.add(loginPanel,"Login",0);
        JPanel signupPanel = createSignupPanel();
        tabbedPane.add(signupPanel,"Signup", 1);
        frame.setContentPane(tabbedPane);
        frame.repaint();
        frame.setVisible(true);

         Calendar date;
    }
    JPanel createLoginPanel ( ){
        JPanel loginPanel = new JPanel();
        loginPanel.setBackground(new Color(88,112,134)); // Violet blue mix


        JLabel loginHeaderLabel = new JLabel("LOGIN");
        Font font = new Font(null,Font.BOLD,20);
        loginHeaderLabel.setFont( font);
        loginHeaderLabel.setForeground(Color.WHITE);
        loginHeaderLabel.setOpaque(false);

        JPanel loginHeaderPanel = new JPanel();
        loginHeaderPanel.setLayout(new FlowLayout());
        loginHeaderPanel.add(loginHeaderLabel);

        loginHeaderLabel.setHorizontalAlignment(JLabel.CENTER);
        loginHeaderLabel.setVerticalAlignment(JLabel.CENTER);
        loginHeaderLabel.setVerticalTextPosition(JLabel.CENTER);
        loginHeaderLabel.setHorizontalTextPosition(JLabel.CENTER);
        loginHeaderPanel.setBackground(new Color(242,158,57));
        loginHeaderPanel.setMaximumSize(new Dimension(500,100));
        loginHeaderPanel.setMinimumSize(new Dimension(500,100));
        loginHeaderPanel.setPreferredSize(new Dimension( 500,100));

        loginPanel.add(loginHeaderPanel);

        GridLayout layout = new GridLayout(2,2,5,10);
        // creating control panel
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout( layout);

        JLabel loginIDLabel = new JLabel("Login :");
        loginIDLabel.setForeground(new Color(255,255,255));
        loginIDLabel.setOpaque(true);
        loginIDLabel.setFont(new Font(null,Font.PLAIN,14));
        loginIDLabel.setHorizontalTextPosition(JLabel.CENTER);
        loginIDLabel.setHorizontalAlignment(JLabel.CENTER);
        loginIDLabel.setVerticalAlignment(JLabel.CENTER);
        loginIDLabel.setVerticalTextPosition(JLabel.CENTER);
        loginIDLabel.setMinimumSize(new Dimension(150,50));
        loginIDLabel.setPreferredSize(new Dimension(150,50));
        loginIDLabel.setMaximumSize(new Dimension(150, 50));
        loginIDLabel.setOpaque(false);

        JLabel passwordLabel = new JLabel("Password :");
        passwordLabel.setForeground(new Color(255,255,255));
        passwordLabel.setOpaque(true);
        passwordLabel.setFont(new Font(null,Font.PLAIN,14));
        passwordLabel.setHorizontalTextPosition(JLabel.CENTER);
        passwordLabel.setHorizontalAlignment(JLabel.CENTER);
        passwordLabel.setVerticalAlignment(JLabel.CENTER);
        passwordLabel.setVerticalTextPosition(JLabel.CENTER);
        passwordLabel.setMinimumSize(new Dimension(150,50));
        passwordLabel.setPreferredSize(new Dimension(150,50));
        passwordLabel.setMaximumSize(new Dimension(150, 50));
        passwordLabel.setOpaque(false);

        JTextField loginText = new JTextField();
        loginText.setMinimumSize(new Dimension(250,30));
        loginText.setPreferredSize(new Dimension(250,30));
        loginText.setMaximumSize(new Dimension(250,30));
        loginText.setHorizontalAlignment(JTextField.LEFT);


        JTextField passwordText = new JTextField();
        passwordText.setMinimumSize(new Dimension(250,30));
        passwordText.setPreferredSize(new Dimension(250,30));
        passwordText.setMaximumSize(new Dimension(250,30));
        passwordText.setHorizontalAlignment(JTextField.LEFT);

        controlPanel.add(loginIDLabel);
        controlPanel.add(loginText);
        controlPanel.add(passwordLabel);
        controlPanel.add(passwordText);
        controlPanel.setOpaque(false);
        loginPanel.add(controlPanel);
        return loginPanel;
    }
    private JPanel createSignupPanel(){
        JPanel signupPanel = new JPanel();
        signupPanel.setBackground(new Color(88,112,134)); // Violet blue mix


        JLabel signupHeaderLabel = new JLabel("SIGNUP");
        Font font = new Font(null,Font.BOLD,20);
        signupHeaderLabel.setFont( font);
        signupHeaderLabel.setForeground(Color.WHITE);
        signupHeaderLabel.setOpaque(false);

        JPanel signupHeaderPanel = new JPanel();
        signupHeaderPanel.setLayout(new FlowLayout());
        signupHeaderPanel.add(signupHeaderLabel);

        signupHeaderLabel.setHorizontalAlignment(JLabel.CENTER);
        signupHeaderLabel.setVerticalAlignment(JLabel.CENTER);
        signupHeaderLabel.setVerticalTextPosition(JLabel.CENTER);
        signupHeaderLabel.setHorizontalTextPosition(JLabel.CENTER);
        signupHeaderPanel.setBackground(new Color(242,158,57));
        signupHeaderPanel.setMaximumSize(new Dimension(500,100));
        signupHeaderPanel.setMinimumSize(new Dimension(500,100));
        signupHeaderPanel.setPreferredSize(new Dimension( 500,100));

        signupPanel.add(signupHeaderPanel);
        return signupPanel;
    }

    public static void main(String[] args) {
        new VLoginAndSignupControl();
    }
}
