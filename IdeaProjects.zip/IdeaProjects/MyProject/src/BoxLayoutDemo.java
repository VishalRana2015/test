import javax.swing.*;
import javax.swing.event.*;
import java.util.*;
import java.awt.*;
public class BoxLayoutDemo {
    public static void main(String[] args) {
        BoxLayoutDemo2();
        BoxLayoutDemo1();
    }
    public static void BoxLayoutDemo1(){
        JFrame frame = new JFrame("Name Choose");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(200, 300);
        frame.setLocation(50,0);
        String[] list = {"Arlo", "Cosmo", "Alno", "Hugo","Jethro","Laszlo", "milo", "Nemo", "Otto", "Ringo", "Rocco", "Rollo"};
        JLabel label1 = new JLabel();
        label1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label1.setText("Baby names ending in O:");
        label1.setAlignmentX(JComponent.LEFT_ALIGNMENT);
        label1.setAlignmentX(JComponent.RIGHT_ALIGNMENT);
        label1.setHorizontalAlignment(JLabel.LEFT);
        JPanel paneltop = new JPanel();
        paneltop.setLayout( new BoxLayout(paneltop,BoxLayout.PAGE_AXIS));
        JScrollPane pane = new JScrollPane();
        JViewport viewport = pane.getViewport();
        System.out.println(viewport.getLayout());

        JPanel scrollpanel = new JPanel();
        scrollpanel.setMaximumSize( new Dimension(100,300));
        scrollpanel.setMinimumSize(new Dimension(100,300));
        scrollpanel.setPreferredSize( new Dimension(100,300));
        for ( int i =0; i < list.length; i++){
            scrollpanel.add( "what" + i,new JLabel(list[i]));


        }
        viewport.add(scrollpanel);
        System.out.println(viewport.getComponentCount());
        paneltop.add(label1);
        paneltop.add(pane);
        JPanel panelbottom = new JPanel();
        panelbottom.setLayout(new BoxLayout(panelbottom,BoxLayout.LINE_AXIS));
        panelbottom.add(Box.createHorizontalGlue());
        panelbottom.add(new JButton("Button1"));
        panelbottom.add(new JButton("Button2"));

        paneltop.add( Box.createRigidArea(new Dimension(100,5)));
        paneltop.add(panelbottom);
        frame.setContentPane(paneltop);
        frame.setVisible(true);
    }
    public static void BoxLayoutDemo2(){
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel = new JPanel();
        panel.setFocusable(true);
        panel.setLayout( new BoxLayout(panel,BoxLayout.PAGE_AXIS));
        MLabel redlabel = new MLabel(Color.RED,100,100);
        MLabel greenlabel = new MLabel(Color.GREEN,100,100);
        MLabel bluelabel = new MLabel(Color.BLUE,100,100);
        MLabel cyanlabel = new MLabel(Color.CYAN,300,100);
        cyanlabel.setAlignmentX(JComponent.LEFT_ALIGNMENT);
        redlabel.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        greenlabel.setAlignmentX(JLabel.RIGHT_ALIGNMENT);
        bluelabel.setAlignmentX(JLabel.CENTER_ALIGNMENT);
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        panel.getLayout().preferredLayoutSize(panel);
        redlabel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        bluelabel.setBorder( BorderFactory.createLineBorder(Color.BLACK));
        greenlabel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        cyanlabel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        panel.add(redlabel);
        panel.add(greenlabel);
        panel.add(bluelabel);
        panel.add(cyanlabel);
        frame.setContentPane(panel);
        frame.setVisible(true);


    }
    static class MLabel extends JLabel{
        Color color;
        MLabel( Color color , int width, int height){
            this.color = color;
            this.setMinimumSize(new Dimension(width, height));
            this.setMaximumSize(new Dimension( width, height));
            this.setMaximumSize( new Dimension(width, height));
        }
        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Rectangle rect = g.getClipBounds();
            String s = " "+ this.getAlignmentX();
            g.setColor(this.color);
            g.fillRect(rect.x, rect.y, rect.width, rect.height);
            g.setColor(Color.BLACK);
            g.drawString(s, (rect.x + rect.width)/2, ( rect.y + rect.height)/2);

        }
    }
}

