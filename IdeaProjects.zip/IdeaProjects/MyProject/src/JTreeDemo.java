import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.util.Enumeration;
import javax.swing.border.*;
import javax.swing.tree.*;
public class JTreeDemo {
    public static void main(String[] args) {
        JTreeDemo1();
    }
    public static void JTreeDemo1(){
        JFrame frame = new JFrame("JTreeDemo1");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocation(50,0);
        frame.setSize(500,500);
        MyTree tree = new MyTree();
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("Books");
        tree = new MyTree(root);
        DefaultMutableTreeNode node = new DefaultMutableTreeNode("Java Books");
        root.add(node);
        node.add(new DefaultMutableTreeNode("Java. The complete referece"));
        node.add(new DefaultMutableTreeNode(("Java For beginners")));
        node.add(new DefaultMutableTreeNode("Servelets from beginning"));
        node.add(new DefaultMutableTreeNode("Advance Java"));
        root.add(node = new DefaultMutableTreeNode("Computer Graphics Books"));
        //node.setAllowsChildren(true);
        System.out.println(node.getParent());
        TreeNode[] path = node.getPath();
        for ( int i =0; i < path.length; i++){
            System.out.print(path[i] + "/");
        }

        TreeNode treenode = (TreeNode)node;
        System.out.println("\n"+node.getPath());
        System.out.println("User object path:"+ node.getUserObjectPath());
        tree.setCellRenderer(new MyRenderer());
        System.out.println(root.getLeafCount());
        System.out.println("Right Alignment :"+ JComponent.RIGHT_ALIGNMENT);
        root.add(new DefaultMutableTreeNode("ASP. NET"));
        tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
  /*      tree.addTreeSelectionListener(new TreeSelectionListener() {
            @Override
            public void valueChanged(TreeSelectionEvent e) {
                System.out.println("\n Tree SelectionListener");
                JTree tree = (JTree)e.getSource();
                TreeSelectionModel model = tree.getSelectionModel();

                System.out.println("max selection row :"+ model.getMaxSelectionRow());
                System.out.println("min selection row : "+model.getMinSelectionRow());
                System.out.println("lead selection row :"+ model.getLeadSelectionRow());
                System.out.println("selection count "+ model.getSelectionCount());
                System.out.println("Selection mode"+ model.getSelectionMode());
                TreePath[] paths = model.getSelectionPaths();
                System.out.println("selection path:"+ model.getSelectionPath());
                for( int i =0; i < paths.length; i++){
                    System.out.print("path["+i+"] : "+ path[i]);
                }

            }
        });
*/
        JComponent component;
        
        System.out.println("is tree instance of JComponent : "+ ( tree instanceof JComponent));
        tree.setShowsRootHandles(true);
        JPanel panel = new JPanel();
        panel.setBorder( BorderFactory.createLineBorder(Color.BLACK,10));
        panel.setLayout(new GridLayout(1,1));
        panel.add(tree);
        Border border= BorderFactory.createLineBorder(Color.GREEN,5);
        tree.setBorder(BorderFactory.createTitledBorder(border,"tree"));
        tree.setAlignmentY(JTree.BOTTOM_ALIGNMENT);

        tree.setAlignmentX(JComponent.RIGHT_ALIGNMENT);
        frame.setContentPane(panel);
        //tree.addTreeExpansionListener(new MyListener());
        frame.setVisible(true);
    }
    static class MyTree extends JTree{
        MyTree(){
            super();

        }
        MyTree(TreeNode node){
            super(node);
        }

        @Override
        public void setAlignmentX(float alignmentX) {
            super.setAlignmentX(alignmentX);
            System.out.println("\n in setAlignment X function :" + this.getAlignmentX());
        }

        @Override
        public void setAlignmentY(float alignmentY) {
            //super.setAlignmentY(alignmentY);
            System.out.println("\n In setAlignmentY ");
            System.out.println("Vertical Alignment : " + this.getAlignmentY());
            System.out.println("Botttom Alignment :"+ JComponent.BOTTOM_ALIGNMENT);

        }
    }
    static class MyListener implements TreeExpansionListener{
        //MyListener(){}
        @Override
        public void treeExpanded(TreeExpansionEvent event) {
            System.out.println("Tree expanded");
            TreePath path = event.getPath();
            System.out.println("Path :"+ path);
            System.out.println("source :"+ event.getSource());

        }

        @Override
        public void treeCollapsed(TreeExpansionEvent event) {
            System.out.println("\n Tree Colllapsed");
            TreePath path = event.getPath();
            System.out.println("path :"+ path);
            System.out.println("souce :" + event.getSource());

        }
    }
    static class MyRenderer extends DefaultTreeCellRenderer{
        MyRenderer(){

        }
        @Override
        public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus) {
            System.out.println("\n CellRendered Called");
            this.setAlignmentX(JComponent.RIGHT_ALIGNMENT);
            super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
            this.setAlignmentX(JComponent.RIGHT_ALIGNMENT);
            this.setBorder(BorderFactory.createLineBorder(Color.ORANGE,4));
            System.out.println(this.getBounds());
            System.out.println("size :"+ this.getSize());
            //this.setPreferredSize(new Dimension(300,30));
            //this.setMinimumSize(new Dimension(300,30));
            //this.setMaximumSize(new Dimension(300,30));
            this.setHorizontalAlignment(JLabel.RIGHT);
            System.out.println("minimum Size :"+ this.getMinimumSize());
            System.out.println("max size :" + this.getMaximumSize());
            return this;
        }
    }
}
