/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RANA1947
 */
//hsi class demostrate the uses of viewport of JScrollPane.
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.util.*;
import java.awt.*;
public class scrollPaneExample {
    public static void main(String[] args){
        scrollPaneDemo3();
    }

    public static JPanel createPanelMessage(String message, Calendar calendar){
        JPanel panel = new JPanel ();
        JLabel label = new JLabel();
        Font messageFont = new Font(null,Font.ITALIC,14);
        label.setFont(messageFont);
        label.setText(message);
        panel.add(label);
        JLabel timeLabel  = new JLabel();
        Font timeFont = new Font(null,Font.ITALIC,6);
        timeLabel.setFont(timeFont);
        timeLabel.setText(calendar.getTime().toString());
        timeLabel.setAlignmentY(-1);
        panel.add(timeLabel);
        return panel;
    }
    public static void scrollPaneDemo(){
        JFrame frame =new JFrame("ScrollPane Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,40);
        Icon icon = new ImageIcon("C:\\Users\\RANA1947\\Documents\\NetBeansProjects\\ChatClient\\Images\\lion.jpg");
        JScrollPane pane = new JScrollPane();
        pane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        pane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        JViewport viewport = pane.getViewport();
        JLabel label = new JLabel();
        label.setIcon(icon);
        viewport.add(label);

        System.out.println(Toolkit.getDefaultToolkit().getScreenResolution());
        Container container = frame.getContentPane();
        Rule   columnView = new Rule(Rule.HORIZONTAL, true);
        Rule  rowView = new Rule(Rule.VERTICAL, true);
        rowView.setPreferredWidth(30);
        columnView.setPreferredHeight(30);
        JPanel panel = new JPanel();
        panel.add(new JLabel("What is this all about"));
        panel.add(pane);
        pane.setColumnHeaderView(columnView);
        pane.setRowHeaderView(rowView);
        frame.setContentPane(pane);
        pane.getRowHeader().setSize(100,-1);
        JViewport port = pane.getViewport();
        port.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                JViewport port = (JViewport)e.getSource();
                System.out.println("Change Viewport Event for the pane occurred.");
                System.out.println(port.getViewRect());
                System.out.println(port.getView());
                System.out.println("Bounds : "+ port.getBounds());
                System.out.println("View Size : "+ port.getViewSize());
            }
        });

        JScrollBar bar = new JScrollBar();

        frame.setContentPane(pane);
        frame.setVisible(true);
    }
    public static void scrollPaneDemo3(){
        JFrame frame = new JFrame("ScrollPanelDemo3");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation( 50, 0);
        JScrollPane pane = new JScrollPane();
        pane.setHorizontalScrollBarPolicy( JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        pane.setVerticalScrollBarPolicy( JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        JLabel label = new JLabel();
        label.setIcon( new ImageIcon("C:\\Users\\RANA1947\\Documents\\NetBeansProjects\\ChatClient\\Images\\lion.jpg"));
        JViewport viewport = pane.getViewport();
        viewport.add(label);
        Ruler horizontalruler = new Ruler(Ruler.HORIZONTAL,pane);
        Ruler verticalruler = new Ruler(Ruler.VERTICAL, pane);
        pane.setRowHeaderView(verticalruler);
        pane.setColumnHeaderView(horizontalruler);
        frame.setContentPane(pane);
        frame.setVisible(true);
        viewport.addChangeListener(horizontalruler);
        label.scrollRectToVisible(new Rectangle(300,300,100,100));
    }
}
