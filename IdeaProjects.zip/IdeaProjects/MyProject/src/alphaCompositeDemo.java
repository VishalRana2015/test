import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.security.AlgorithmParameterGenerator;

public class alphaCompositeDemo {
    JPanel sliderpanel,controlpanel;
    JSlider slidersrc , sliderdes;
    MyPanel imagePanel;
    JComboBox combobox;
    alphaCompositeDemo(){
        JFrame frame = new JFrame("AlphaComposite Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocation(50,0);
        frame.setSize(500,500);
        JPanel sliderpanel = createSliderPanel();
        JPanel controlpanel = new JPanel();
        controlpanel.setLayout(new FlowLayout(FlowLayout.LEFT,10,5));

        String[] list  = {"Clear","Dst","DstAtTop","DstIn","DstOut","DstOver","Src","SrcAtTop","SrcIn","SrcOut","SrcOver","Over"};
        combobox = new JComboBox(list);
        combobox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JComboBox box = (JComboBox)e.getSource();
                String type = (String)box.getSelectedItem();
                System.out.println("type :"+ type);
                if ( type.equalsIgnoreCase("Clear"))
                    imagePanel.setType(AlphaComposite.Clear);
                if ( type.equalsIgnoreCase("Dst"))
                    imagePanel.setType(AlphaComposite.Dst);
                if ( type.equalsIgnoreCase("DstAtop"))
                    imagePanel.setType(AlphaComposite.DstAtop);
                if ( type.equalsIgnoreCase("DstIn"))
                    imagePanel.setType(AlphaComposite.DstIn);
                if ( type.equalsIgnoreCase("DstOut"))
                    imagePanel.setType(AlphaComposite.DstOut);
                if ( type.equalsIgnoreCase("DstOver"))
                    imagePanel.setType(AlphaComposite.DstOver);
                if ( type.equalsIgnoreCase("Src"))
                    imagePanel.setType(AlphaComposite.Src);
                if ( type.equalsIgnoreCase("SrcAtop"))
                    imagePanel.setType(AlphaComposite.SrcAtop);
                if ( type.equalsIgnoreCase("SrcIn"))
                    imagePanel.setType(AlphaComposite.SrcIn);
                if ( type.equalsIgnoreCase("SrcOut"))
                    imagePanel.setType(AlphaComposite.SrcOut);
                if ( type.equalsIgnoreCase("SrcOver"))
                    imagePanel.setType(AlphaComposite.SrcOver);
                if ( type.equalsIgnoreCase("XOR"))
                    imagePanel.setType(AlphaComposite.Xor);
            }
        });

        controlpanel.add(combobox);
        controlpanel.add(sliderpanel);

        imagePanel = new MyPanel();
        imagePanel.setBorder( BorderFactory.createLineBorder(Color.BLACK,4));
        JPanel container = new JPanel();
        container.setLayout(new BoxLayout(container,BoxLayout.PAGE_AXIS));
        container.add(imagePanel);
        container.add(controlpanel);

        frame.setContentPane(container);
        frame.setVisible(true);
    }
    public JPanel createSliderPanel(){
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
        JSlider slidersrc = new JSlider(JSlider.HORIZONTAL,0,100,70);
        JSlider sliderdes = new JSlider(JSlider.HORIZONTAL,0,100,70);
        BoxLayout bl = (BoxLayout)panel.getLayout();
        slidersrc.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                JSlider slider= (JSlider)e.getSource();
                int val = slider.getValue();
                float a = val/100.0f;
                //System.out.println("a : "+a);
                imagePanel.setSrcalpha(a);

            }
        });
        sliderdes.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                JSlider slider = (JSlider)e.getSource();
                int val = slider.getValue();
                float a = val/100.0f;
               // System.out.println(" a : "+ a);
                imagePanel.setRectalpha(a);
            }
        });
        panel.add(slidersrc);
        panel.add(sliderdes);
        return panel;
    }
    public static void main(String[] args) {
        new alphaCompositeDemo();
    }

    class MyPanel extends JPanel{
        float rectalpha, srcalpha;
        AlphaComposite type;
        MyPanel(){
            super();
            rectalpha  = 0.7f;
            srcalpha = 0.7f;
            type = AlphaComposite.SrcAtop;
            this.setBackground( new Color(255,0,0,0));
        }
        public void setRectalpha(float rectalpha){
            this.rectalpha = rectalpha ;
            this.repaint();
        }
        public void setSrcalpha(float srcalpha){
            this.srcalpha = srcalpha;
            this.repaint();
        }
        public void setType(AlphaComposite type){
            this.type = type;
            repaint();
        }

        @Override
        public void paintComponent(Graphics g) {

            int width, height , length;
            Color color;
            Graphics2D gg = (Graphics2D)g.create();

            Rectangle rect = gg.getClipBounds();
            gg.clearRect(rect.x + this.getInsets().left , rect.y + this.getInsets().top,rect.width + (this.getInsets().left + this.getInsets().right) , rect.height + (this.getInsets().top + this.getInsets().bottom));
            height = rect.height - ( this.getInsets().top + this.getInsets().bottom  + 100);
            width = rect.width - (this.getInsets().top + this.getInsets().bottom + 100);
            if ( height > width){
                length = width;
            }
            else
                length = height;

            int cx, cy;
            cx  = this.getInsets().top + 50 + width/2;
            cy = this.getInsets().top + 50 + height/2;
            color = new Color(0,0,255,(int)(255*rectalpha));
            gg.setColor(color);
            gg.fillRect(cx-length/2 , cy-length/2 , length , length);
            // drawing oval shape
            color = new Color(255,0,0,(int)(255*srcalpha));
            gg.setColor(color);
            int ow , oh;
            ow = (int)(length*1.33);
            oh = (int)(length* (1-0.33));
            gg.setComposite(type);

           // gg.clipRect(cx-length/2,cy-length/2,length,length);
            gg.fillOval(cx-ow/2,cy-oh/2,ow, oh);
            gg.dispose();

            System.out.println("Drawing operation completed");
            super.paintComponent(g);
        }
    }
}
