import javax.swing.*;
import java.awt.event.MouseAdapter;

public class UserButton {
    private JPanel panel1;
    private JTabbedPane LoginAndSingupForm;
    private JTextField textField1;
    private JTextField textField2;
    private JButton REGISTERButton;
    private JTextField textField3;
    private WButton WButto323;

    public UserButton() {
        WButto323.addMouseListener(new MouseAdapter() {
        });
    }

    public void createUIComponents(){

    }
}
