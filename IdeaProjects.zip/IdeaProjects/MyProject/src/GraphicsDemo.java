import javafx.scene.transform.Affine;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.geom.*;
import java.awt.geom.Ellipse2D;

public class GraphicsDemo {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        MyPanel panel = new MyPanel();
        frame.setContentPane(panel);


        frame.setVisible(true);
    }
    static class MyPanel extends JPanel{
        MyPanel(){
            super();
        }
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int cx, cy;
            Rectangle rect = g.getClipBounds();
            cx = rect.x+ rect.width/2;
            cy = rect.y + rect.height/2;
            Paint p = new GradientPaint(cx- 25 , cy - 25, Color.RED,cx-50,cy-50,Color.BLUE,true);
            Shape s = GraphicsDemo2(cx,cy,50,100);

            Graphics2D gg = (Graphics2D)g.create();
            gg.setPaint(p);
            gg.drawLine(cx,cy,cx+10,cy+10);
            gg.fill(s);
            gg.dispose();

        }
        public Shape GraphicsDemo2(int x, int y , int innerradius , int outerradius){
            Area a1 = new Area(new Ellipse2D.Double(x-outerradius/2,y-outerradius/2,outerradius, outerradius));
            Area a2 = new Area( new Ellipse2D.Double(x-innerradius/2,y-innerradius/2,innerradius,innerradius));
             a1.subtract(a2);
             return a1;
        }
        public void GraphicsDemo(Graphics g){
            Rectangle rect = g.getClipBounds();
            Graphics2D gg = (Graphics2D)g.create();
            int cx, cy;
            cx = rect.x+ rect.width/2;
            cy = rect.y + rect.height/2;
            gg.translate(cx,cy);
            gg.fillRect(-50,-50,100,100);
            gg.drawLine(-rect.width/2,0,rect.width,0);
            gg.drawLine(0,rect.height/2,0,-rect.height/2);
            AffineTransform at = gg.getTransform();
            gg.scale(1,-1);
            gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
            gg.rotate(Math.toRadians(15));
            gg.setColor(Color.RED);
            gg.drawLine(150,150,151,151);
            gg.fillRect(-50,-50,100,100);
            gg.setTransform(at);
            // gg.scale(1,-1);
            gg.rotate(Math.toRadians(45),100,100);
            gg.setColor(Color.BLUE);
            gg.scale(2,2);
//            gg.fillRect(-50,-50,100,100);
            //gg.setTransform(at);
            gg.setColor(Color.BLACK);
            gg.setStroke(new BasicStroke(10,BasicStroke.CAP_ROUND,BasicStroke.JOIN_BEVEL));
            gg.setColor(Color.GREEN);
            gg.drawLine(150,150,160,161);
            gg.drawLine(0,0,0,5);
            gg.drawLine(0,0,5,0);
            gg.dispose();
        }
    }
}
