import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

public class VButton  extends JButton{
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel =new JPanel();
        panel.add( new VButton());

        frame.setVisible(true);
    }
   Icon userSuppliedIcon;
   int iconWidth;
   Color pressedColor = new Color( 255, 50, 120);
   Color backgroundColor = new Color( 1, 50 , 67);

   VButton(){
       iconWidth = 100;// default Value
       this.setRolloverEnabled(false);
       this.setContentAreaFilled(false);
       this.setFocusPainted(false);
       this.setBackground(backgroundColor);
       this.setForeground( Color.WHITE);
       Insets insets  = new Insets(8,4,8,4);
       this.getInsets(insets);
        this.setOpaque(true);
       this.setMargin( new Insets(2,2,2,2));

   }

    @Override
    public void paintComponent(Graphics g) {
        ButtonModel m = this.getModel();
        if ( m.isPressed()){
            this.setBackground(pressedColor);
        }
        else{
            this.setBackground(backgroundColor);

        }
        super.paintComponent(g);
    }

    @Override
    public void setIcon(Icon defaultIcon) {

           userSuppliedIcon = defaultIcon;
           ImageIcon imageIcon = (ImageIcon) userSuppliedIcon;


           Icon icon = toDisplayableIcon(imageIcon);

           super.setIcon(icon);

    }

    @Override
    public void setBackground(Color bg) {
       if ( !this.getModel().isPressed())
        backgroundColor = bg;
        super.setBackground(bg);
        if ( userSuppliedIcon != null)
            setIcon( this.userSuppliedIcon);
    }

    private Icon toDisplayableIcon(ImageIcon icon){

       int width, height;
       width = icon.getIconWidth();
       height = icon.getIconHeight();
       BufferedImage bimage  = new BufferedImage (width, height, BufferedImage.TYPE_INT_RGB);
       Graphics2D g = bimage.createGraphics();
       g.drawImage(icon.getImage(), 0 ,0,null);
       g.drawImage()
       g.dispose();
       int colorValue;
       int ax, ay;
       BufferedImage nbimage = new BufferedImage(iconWidth , iconWidth, BufferedImage.TYPE_INT_RGB);
       for ( int i =0; i < iconWidth ; i++){
           for ( int j =0; j < iconWidth; j++){
               ax = width*i/iconWidth;
               ay = height*j/iconWidth;
               colorValue = bimage.getRGB(ax,ay);
               nbimage.setRGB(i,j,colorValue);
           }
       }



       VButtonIcon vicon = new VButtonIcon(nbimage);

       return vicon;
    }

    public void setIconWidth(int iconWidth) {
        this.iconWidth = iconWidth;
    }

    public int getIconWidth() {
        return iconWidth;
    }


  private  class VButtonIcon extends ImageIcon {
       VButtonIcon(Image image){
           super(image);
       }

        @Override
        public synchronized void paintIcon(Component c, Graphics g, int x, int y) {
           // This method starts painting the icon on the component c starting from x and y position of the component graphics context.
            // x and y values depends upon the current Insets of the component for the Button x equals this.getInsets().left , y equals this.getInsets().top;
            this.getIconWidth();
            super.paintIcon(c, g, x, y);
            Color backgroundColor = c.getBackground();
            int length;

            VButton button = (VButton) c;
            length = button.getIconWidth();
            int radius  = length/2;

            Insets insets = button.getInsets();


            g.setColor( button.getBackground());
            for (int i = 0; i < length; i++) {
                for (int j = 0; j < length; j++) {
                    if ((i-radius) * (i-radius) + (j-radius) * (j-radius) - (radius) * (radius) <= 0){
                        // do nothing
                    }
                    else{
                        g.drawRect(i+x,j+y,1,1);
                    }

                }
            }
        }
    }

}
