import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;

public class ScrollBarDeo {
    public static void main(String[] args) {
        JFrame f = new JFrame("ScrollBar Demo");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setSize(500,500);
        f.setLocation(50,0);
        MyScrollBar bar= new MyScrollBar(JScrollBar.VERTICAL,40,4,0,100);
        JScrollPane pane = new JScrollPane();
        pane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        pane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        JViewport viewport = pane.getViewport();
        ImageIcon icon = new ImageIcon("C:\\Users\\RANA1947\\IdeaProjects\\MyProject\\Images\\thumb.jpg");
        if ( icon == null){
            System.out.println("icon is null");
        }
        JLabel label = new JLabel(icon);
        label.setText("hello world");
        label.setIcon(icon);
        viewport.add(label);
        pane.setVerticalScrollBar(bar);
        pane.setViewport(viewport);

        f.setContentPane(pane);
        f.setVisible(true);
    }
    static class MyScrollBar extends JScrollBar{
        MyScrollBar(int orientation, int value , int extent, int min , int max){
            super(orientation,value,extent ,min,max);
        }

        @Override
        public void paint(Graphics g) {
            super.paint(g);
            Graphics2D gg = (Graphics2D)g;
            int width = this.getWidth();
            BasicStroke stroke = new BasicStroke(width,BasicStroke.CAP_ROUND,BasicStroke.JOIN_BEVEL,0.01f);
            int cv = this.getValue();
            //gg.setStroke(stroke);
            //gg.setColor(Color.ORANGE);
            if ( this.orientation == JScrollBar.VERTICAL){
                Rectangle rect = new Rectangle();
                rect= g.getClipBounds();
                int x1=  ( (int)rect.getX() + (int)rect.getWidth()/2);
                //g.drawLine(x1,cv,x1,cv+this.getModel().getExtent());
                System.out.println("Extent :+ "+ this.getModel().getExtent());
                System.out.println("(width,height) : ("+this.getWidth() +","+this.getHeight()+")");
                System.out.println("(x1,cv,x2,cv+extent) :(" + x1+ ","+cv+","+x1 + ","+(x1+this.getModel().getExtent())+")");
            }
            System.out.println(cv);
        }
    }
}
