public class NewClassTextFiled {
    private String textField;

    public NewClassTextFiled() {
    }

    public String getTextField() {
        return textField;
    }

    public void setTextField(final String textField) {
        this.textField = textField;
    }
}