import javax.swing.*;
import java.util.Iterator;
import java.util.List;

public class SwingWorkerExample {
        static class MyTask extends SwingWorker<Boolean,Integer>{
            @Override
            protected Boolean doInBackground() throws Exception {
                setProgress(0);
                System.out.println("doInBackground thread "+Thread.currentThread().getName());
                for ( int i =1; i <= 20; i++){
                    setProgress((i*100)/20);

                    if ( (i%2) == 0)
                        publish(i);
                    try{
                        Thread.sleep(250);
                    }
                    catch(Exception e){
                        System.out.println("Exception thrown ");
                        return true;
                    }
                   // System.out.println("In the loop");
                }

                System.out.println("Progress done in doInBackgroundThread .");
                return true;
            }

            @Override
            protected void done() {
                //super.done();
                System.out.println("done thread : "+ Thread.currentThread().getName());
                System.out.println("Process Finished :"+ getState().toString());
            }

            @Override
            protected void process(List<Integer> chunks) {
                //super.process(chunks);
                System.out.println("Process Thread :"+ Thread.currentThread().getName());
                Iterator itr = chunks.listIterator();
                while( itr.hasNext()){
                    System.out.println((Integer)itr.next());
                }
            }
        }
        public static void main(String[] args){
            System.out.println("In main thread ");
            System.out.println("Main Method Thread :"+ Thread.currentThread());
            System.out.println("Executing and dispathing the task.");
            MyTask task = new MyTask();
            task.execute();
            System.out.println("Task dispatched.");
            while(!task.isDone()){
                System.out.println("Progress : "+ task.getProgress());
                try{
                    Thread.sleep(500);
                }catch( Exception e){
                    System.out.println("Exception caught :"+ e.getMessage());
                }
            }
            System.out.println("Exiting from the main method");
        }
}
