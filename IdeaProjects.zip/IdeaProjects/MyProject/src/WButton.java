import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.*;
import java.io.*;
public class WButton extends JButton  {
    File imageFile;
    Icon wicon;
    int iconWidth;
    int iconHeight;
    Color pressedColor = new Color( 1, 120 , 120);
    Color backgroundColor = new Color( 1, 50, 67);
    // Implementing MouseMotion Listener
    WButton(){
        super();
        this.iconWidth = 60;
        this.iconHeight = 60; // default

        this.setHorizontalTextPosition(SwingConstants.LEFT);
        this.setVerticalTextPosition(SwingConstants.CENTER);
        this.setContentAreaFilled(false);
        this.setRolloverEnabled(false);

    }

    public void setIconWidthHeight( int width ){
        this.iconWidth = width;
        this.iconHeight = width;
    }
    @Override
    public void setBackground(Color bg) {
        //System.out.println("Backgourd color changed ");
        super.setBackground(bg);
        if (wicon != null) {
            {
                setIcon(wicon);
            }
        }
    }

    @Override
    public void setSize(Dimension d) {
        int width , height;
        width = (iconWidth/32) * 100;
        height = iconWidth;
        d = new Dimension( width , height);
        this.setPreferredSize(d);
        this.setMaximumSize(d);
        this.setMinimumSize(d);
        System.out.println("Size Setted to (w,h) : (" + width + ","+ height + ").");

    }

    @Override
    public void repaint() {
        super.repaint();
       // System.out.println("repaint called. iconWidth :"+ iconWidth);
    }

    public int getIconWidthHeight ( ){
        return iconWidth;
    }

    // creating a custom JButton





    @Override
    protected void paintComponent(Graphics g) {
        ButtonModel m = this.getModel();
        if ( m.isPressed()){
            System.out.println("Button is Pressed.");
            this.setBackground(pressedColor);
        }
        else{
            this.setBackground(backgroundColor);
        }

        super.paintComponent(g);

        this.setOpaque(true);

    }

    public void setCustomIcon(BufferedImage image){
        int aw, ah  ;

        aw = image.getWidth();
        ah =image.getHeight();

        int ax, ay;

        BufferedImage tempImage = new BufferedImage(iconWidth,iconHeight,BufferedImage.TYPE_INT_ARGB);
        Color backgroundColor = this.getBackground();
        Graphics2D gg = tempImage.createGraphics();
        int backgroundColorValue = backgroundColor.getRGB();


        int red, green , blue;
        double alpha  = backgroundColor.getAlpha();
        red = (backgroundColorValue >> 16) & (0xff);
        green = (backgroundColorValue >>8) & (0xff);
        blue = (backgroundColorValue )& 0xff;
        //backgroundColor = new Color(red,green,blue,0.3f);

        int colorValue;
        for ( int x =0; x < iconWidth; x++){
            for ( int y =0; y < iconHeight; y++){
                if ( (x-(iconWidth/2))*(x-(iconWidth/2)) + (y-(iconWidth/2))*(y-(iconWidth/2)) - (iconWidth/2)*(iconWidth/2) > 0 ) {
                   // tempImage.setRGB(x, y, backgroundColorValue);
                    gg.setBackground( new Color(255,255,255, 0));
                }
                else{
                   ax = aw*x / iconWidth;
                   ay = ah*y/iconHeight;
                   colorValue = image.getRGB(ax,ay);
                   red = (colorValue >> 16) & 0xff;
                   green = (colorValue >> 8) & 0xff;
                   blue = colorValue & 0xff;

                   gg.setColor(new Color(colorValue));
                   gg.drawRect(x,y,1,1);

                }

            }
        }
        gg.dispose();

        ImageIcon icon  = new ImageIcon(tempImage);
        super.setIcon(icon);
    }
    public void createUIComponents(){

    }

    @Override
    public void setText(String text) {
        super.setText(text);
        System.out.println("Set Text Called");
    }

    @Override
     public void setIcon(Icon defaultIcon) {

        wicon = defaultIcon;
        Image im = ((ImageIcon)wicon).getImage();
        BufferedImage image = toBufferedImage(im);
        setCustomIcon(image);
    }

    private static BufferedImage toBufferedImage( Image img){
        if ( img instanceof BufferedImage ){
            return (BufferedImage) img;
        }
        BufferedImage bimage = new BufferedImage ( img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_4BYTE_ABGR);
        //Draw the image on the buffered image
        Graphics2D bGr = bimage.createGraphics();
        bGr.drawImage(img,0,0,null);

        bGr.dispose();
        return bimage;
    }


}
