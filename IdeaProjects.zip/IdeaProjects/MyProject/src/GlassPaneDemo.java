import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;

public class GlassPaneDemo  implements ItemListener{

    JFrame frame;
    JButton b1,b2;
    JPanel container;
    JCheckBox checkbox;
    MyGlassPane myglasspane;
    GlassPaneDemo(){
        frame  = new JFrame("RootPane Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setSize(500,200);
        frame.setLocation(50,0);
        JMenuBar menubar = new JMenuBar();
        JMenu menu = new JMenu("Menu");
        JMenuItem m1  = new JMenuItem("M1");
        JMenuItem m2 = new JMenuItem("M2");
        JMenuItem m3 = new JMenuItem("M3");
        menu.add(m1);
        menu.add(m2);
        menu.add(m3);

        menubar.add(menu);

        container = new JPanel();
        container.setLayout(new FlowLayout());
        checkbox = new JCheckBox("set Glass Pane Visible");
        checkbox.setSelected(false);
        container.add(checkbox);
        b1 = new JButton("Button 1");
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Action Performed by Button 1");
            }
        });
        b2 = new JButton("Button 2");
        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Action Performed by Button 2");
            }
        });
        container.add(b1);
        container.add(b2);
        FlowLayout fl = (FlowLayout)container.getLayout();
        fl.setHgap(10);
        fl.setVgap(10);
        checkbox.addItemListener(this);
        frame.setContentPane(container);
        frame.setJMenuBar(menubar);
        frame.setVisible(true);
        frame.repaint();
    }
    public static void main(String[] args) {
        new GlassPaneDemo();
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        System.out.println("Item state changed event occureed. "+ e.getStateChange());
        if ( e.getStateChange() == 1){
            MyGlassPane myglasspane = new MyGlassPane(container);
            frame.setGlassPane(myglasspane);
            frame.getGlassPane().setVisible(true);
        }
    }

    class MyGlassPane extends JComponent implements MouseListener{
        Point point;
        JPanel container;

        MyGlassPane(JPanel container){
            this.container = container;
            this.addMouseListener(this);

        }

        @Override
        public void mouseClicked(MouseEvent e) {

        }

        @Override
        public void mouseEntered(MouseEvent e) {
            //System.out.println("Intercepted mouse Entered Event by the rootpane");
        }

        @Override
        public void mouseExited(MouseEvent e) {
            //System.out.println("Intercepted Mouse Exited event by the rootpane");
        }

        @Override
        public void mousePressed(MouseEvent e) {
            //System.out.println("Intercepted MousePressedEvent by the rootpane");
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            System.out.println("Intercepted mouse Clicked Event by the root pane");
            point = new Point(e.getX(),e.getY());
            this.repaint();
            Point cp = SwingUtilities.convertPoint(this,point,container);
            System.out.println("cp : "+ cp + " when point : "+ point);
            if ( cp.x > 0 && cp.y > 0){
                Component component = SwingUtilities.getDeepestComponentAt(container,cp.x,cp.y);
                if ( component != null){
                    System.out.println("Component :"+component);
                    Point cpp  = SwingUtilities.convertPoint(container,cp,component);
                    System.out.println("cpp: "+ cpp);
                    component.dispatchEvent(new MouseEvent(component,e.getID(),e.getWhen(),e.getModifiers(),cpp.x,cpp.y,e.getClickCount(),e.isPopupTrigger(),e.getButton()));
                    System.out.println("Event dispatched");


                }
            }

        }

        @Override
        protected void paintComponent(Graphics g) {
            System.out.println(g.getClipBounds());
            System.out.println("In paint method");
            if ( point != null){
                System.out.println("p : "+point);
                g.setColor(Color.RED);
                g.fillOval((int)point.x-10,(int)point.y-10,20,20);
            }
            else{
                System.out.println("point isnull");
            }
        }
    }

}
