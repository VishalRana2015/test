import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MyFrame  {
    private JButton button1;
    private JButton button3;
    private JButton buttonEqualTo;
    private JButton buttonMinus;
    private JButton buttonPlus;
    private JButton button6;
    private JButton button2;
    private JButton button5;
    private JButton button4;
    private JButton buttonDot;
    private JButton button8;
    private JButton button9;
    private JButton button7;
    private JButton buttonDiv;
    private JButton buttonMul;
    private JButton buttonAC;
    private JTextField result;
    private JPanel calculatorView;
    private JButton button0;
    private ButtonGroup buttonGroup1;


    public static void main(String[] args) {
        JFrame frame = new JFrame ("Calculator");
        frame.setContentPane((new MyFrame()).calculatorView);
        frame.setUndecorated(true);
        
        frame.setSize(500,500);
        frame.setLocation(50,0);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    public MyFrame() {

        button0.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                result.setText( result.getText() + String.valueOf(0));
            }
        });

        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                result.setText( result.getText() + String.valueOf(1));
            }
        });
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                result.setText( result.getText() + String.valueOf(2));

            }
        });
        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                result.setText( result.getText() + String.valueOf(3));
            }
        });
        button4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                result.setText( result.getText() + String.valueOf(4));
            }
        });
        button5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                result.setText( result.getText() + String.valueOf(5));
            }
        });
        button6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                result.setText( result.getText() + String.valueOf(6));
            }
        });
        button7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                result.setText( result.getText() + String.valueOf(7));
            }
        });
        button8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                result.setText( result.getText() + String.valueOf(8));
            }
        });
        button9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                result.setText( result.getText()  + String.valueOf(9));
            }
        });

    }


    public void setData(NewClassTextFiled data) {
        result.setText(data.getTextField());
    }

    public void getData(NewClassTextFiled data) {
        data.setTextField(result.getText());
    }

    public boolean isModified(NewClassTextFiled data) {
        if (result.getText() != null ? !result.getText().equals(data.getTextField()) : data.getTextField() != null)
            return true;
        return false;
    }
}
