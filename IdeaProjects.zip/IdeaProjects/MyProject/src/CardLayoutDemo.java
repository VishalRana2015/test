import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CardLayoutDemo implements ActionListener {
    JPanel card1;
    JPanel card2;
    JComboBox box;
    JPanel containerpanel;
    CardLayoutDemo(){
        JFrame frame = new JFrame();
        frame.setSize(500,500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setLocation(50,0);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel,BoxLayout.PAGE_AXIS));
        card1 = new JPanel ();
        card1.setLayout(new FlowLayout());
        JButton b1 = new JButton("Button 1");
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Button 1 pressed.");
            }
        });
        JButton b2 = new JButton("Button 2");
        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Button 2 pressed.");
            }
        });
        card1.add(b1);
        card1.add(b2);
        JLabel label = new JLabel("This is the label is second card.");
        card2 = new JPanel();
        card2.add(label);
        String [] list = { "Select Card1", "Select Card2"};
        box  =new JComboBox(list);

        //box.addItem(list[0]);
        //box.addItem(list[1]);
        box.setActionCommand("CardSelected");
        containerpanel = new JPanel();
        containerpanel.setLayout( new CardLayout());
        containerpanel.add("card1",card1);
        containerpanel.add("card2",card2);
        panel.add(box);
        panel.add(containerpanel);
        frame.setContentPane(panel);
        panel.repaint();
        frame.setVisible(true);
        box.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if ( "cardselected".equalsIgnoreCase(command)){
            System.out.println("Card Selected.");
            int index = box.getSelectedIndex();
            CardLayout c = (CardLayout)containerpanel.getLayout();
            String s = "card" + (box.getSelectedIndex() + 1);
            c.show(containerpanel,s);
            FlowLayout fl;

        }
    }

    public static void main(String[] args) {
        new CardLayoutDemo();
    }
}
