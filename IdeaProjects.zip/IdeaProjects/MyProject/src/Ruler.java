import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
public class Ruler extends JComponent implements ChangeListener {
    // We have drived this class from JComponent class so that it can inherit the properties that JComponent has so that is can be drawn
    // like regular JComponent objects
    int orientation;
    int width, height;
    int size = 35;
    public static final int HORIZONTAL = 0;
    public static final int VERTICAL = 1;
    JScrollPane parent ;
    Ruler(int orientation , JScrollPane pane){
        this.parent = pane;
        this.orientation = orientation;
        if (orientation == HORIZONTAL ){
            // set preferred height
            try {
                this.setPreferredHeight(50);
            }catch( Exception e){
                System.out.println("Exception caught :" + e.getMessage());
            }
        }
        else{
            // set Prefeffed Width
            try{
                this.setPreferredWidth(50);
            }catch( Exception e){
                System.out.println("Exception caught : "+ e.getMessage());
            }
        }
    }

    public void setPreferredWidth ( int width) throws Exception {
        // this method is only valid for rowHeader
        if ( orientation == VERTICAL) {
            this.width = width;
            this.setPreferredSize(new Dimension(width, size));
            this.setMinimumSize(new Dimension(width, size));
        }
        else
            throw new Exception("Not a rowHeader");
    }
    public void setPreferredHeight( int height) throws Exception {

        // this method is only valid for columnHeader
        if ( orientation == HORIZONTAL) {
            this.height = height;
            this.setPreferredSize(new Dimension(height, size));
            this.setMinimumSize(new Dimension(height, size));
        }
        else{
            throw new Exception("Not a columnHeader");
        }
    }
    public int getPreferredHeight(){
        return height;
    }
    public int getPreferredWidth(){
        return width;
    }

    @Override
    protected void paintComponent(Graphics g) {
        int cmsize ;
        int temp ;
        temp = Toolkit.getDefaultToolkit().getScreenResolution();
        cmsize = (int) (temp/2.54);
        //System.out.println("Paint method called of the Ruler's instance");
        Rectangle rectBounds = parent.getBounds();
        Rectangle viewrect =parent.getViewport().getViewRect();
        int startx, starty, startxcount , startycount;
        double viewx, viewy;
        viewx = viewrect.getX() ;
        viewy = viewrect.getY() ;
        Rectangle cliparea = g.getClipBounds();
      //  System.out.println("cliparea :"+ cliparea);
        //System.out.println("viewrect : "+ viewrect);
        //System.out.println("rectBounds :"+ viewrect);
        g.setColor ( new Color( 234, 120, 4));
        g.fillRect( (int)cliparea.getX(), (int)cliparea.getY(), (int)cliparea.getWidth(), (int)cliparea.getHeight());
        g.setColor(Color.BLACK);
        if ( this.orientation == HORIZONTAL ){

            startxcount =  (int) ( viewx/cmsize)  + 1;
            startx = startxcount*cmsize % ( cmsize);
            while ( startx <= cliparea.getWidth()){
                g.drawLine(startx,10,startx,20);
                String s = new String();
                s = startxcount + "";
                g.drawString(s,startx, 7);
                startxcount ++;
                startx = startx + cmsize;
            }

        }
        else{

            // The Ruler is Vertical
            startycount = ( int) ( viewy/cmsize) +1;
            starty = startycount * cmsize % (cmsize);
            while ( starty <= cliparea.getHeight()){
                g.drawLine( 10,starty,20,starty);
                g.drawString(startycount + "",7, starty);
                starty = starty+ cmsize;
                startycount ++;
            }
        }
    }

    @Override
    public void stateChanged(ChangeEvent e) {
     System.out.println("State Changed Event Occurred.");
     JViewport viewport = parent.getViewport();
     System.out.println("component count :"+ viewport.getComponentCount());
     JLabel label = (JLabel)viewport.getComponent(0);
     System.out.println("Visible rect of label : "+ label.getVisibleRect());
     Rectangle rect = viewport.getBounds();
     System.out.println(label.isShowing());
     Rectangle rect1 = new Rectangle( 25, 25, 50 , 50);
     Rectangle rect2 = new Rectangle( 30, 30, 100, 100);
     System.out.println(rect1.intersects(rect2));
    }
}
