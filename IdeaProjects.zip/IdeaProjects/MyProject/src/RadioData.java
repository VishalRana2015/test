public class RadioData {
    private String resultText;

    public RadioData() {
    }

    public String getResultText() {
        return resultText;
    }

    public void setResultText(final String resultText) {
        this.resultText = resultText;
    }
}