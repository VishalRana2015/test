import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.plaf.ButtonUI;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
public class Test {
    public static void main(String[] args) throws IOException {
        VButton button = new VButton();
        button.setText("This is  my new Button what are you doing here tell me right now.");
        JFrame frame = new JFrame("Test Frame");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300,300);
        frame.setLocation(50,0);
        try {
            Image image = ImageIO.read(new File("C:\\Users\\RANA1947\\IdeaProjects\\MyProject\\Images\\userIcon.png"));
            frame.setIconImage(image);
        }catch( Exception e){
            System.out.println("Exception caught : "+ e.getMessage());
        }
        button.setBackground(Color.yellow);

        button.setHorizontalAlignment(JButton.NORTH_EAST);

       ImageIcon icon = new ImageIcon("C:\\Users\\RANA1947\\IdeaProjects\\MyProject\\Images\\userIcon.jpg");
       button.setIconWidth(200);
       button.setIcon(icon);
       ButtonUI wbuttonui = button.getUI();
        button.setFocusPainted(false);

       //button.setImageFile( new File("C:\\Users\\RANA1947\\IdeaProjects\\MyProject\\Images\\userIcon.jpg"));
       button.setIconWidth(150);
       button.setBackground(new Color(1,50,67));
       button.setForeground( Color.WHITE);
        ImageIcon imageicon;
        BufferedImage bimage = new BufferedImage(30,30,BufferedImage.TYPE_INT_RGB);
        Graphics2D g  = bimage.createGraphics();
        Dimension d  = new Dimension(300,160);
        button.setSize(d);
        button.setFocusPainted(false);
       JPanel panel = new JPanel(){

           @Override
           public void paintComponent(Graphics g) {
               Graphics2D gg = (Graphics2D)g.create();
               int width, height ;
               width = this.getWidth();
               height = this.getHeight();

               gg.setColor(Color.BLUE);
               gg.fillRect( 0, 0, width, height);
               int cs  = 6;
               gg.setColor(Color.RED);

               for ( int i =0; i*cs < width;  i ++){
                   for ( int j =0; j*cs < height ;  j++){
                      if ( ( (i+j)%2 ) == 0) {
                          gg.setColor(new Color(197,239,247));
                          gg.fillRect(i * cs, j * cs, cs, cs);
                      }else{
                          gg.setColor( new Color( 228,241,254));
                          gg.fillRect(i*cs, j*cs, cs, cs);
                      }
                   }
               }
           }
       };
       panel.add(button);
       panel.add(new JButton("New Button"));
       frame.setContentPane(panel);
       VButton button2 = new VButton();
       button2.setBackground(Color.ORANGE);
       button2.getInsets( new Insets(10,10,10,10));
       panel.add(button2);
       button2.setText("Button2");
       button2.setIcon(icon);
       button2.setRolloverEnabled(false);
        frame.setVisible(true);
    }
}
