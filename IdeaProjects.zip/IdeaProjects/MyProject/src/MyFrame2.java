import javax.swing.*;

public class MyFrame2 {
    private JPanel calculatorView;
    private JTextField result;
    private JRadioButton radioButton1;
    private JButton button1;
    private JButton button3;
    private JButton buttonEqualTo;
    private JButton buttonMinus;
    private JButton buttonPlus;
    private JButton button6;
    private JButton button2;
    private JButton button5;
    private JButton button4;
    private JButton buttonDot;
    private JButton button8;
    private JButton button9;
    private JButton button7;
    private JButton buttonDiv;
    private JButton buttonMul;
    private JButton buttonAC;
    private JButton button0;

    public MyFrame2() {
    }
}
