import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Random;
import java.util.Vector;

public class ProgressBarDemo implements ActionListener, PropertyChangeListener {
    JProgressBar progressbar;
    JButton startbutton;
    MyTask task;
    JTextArea textarea;
    Vector<String> list;
    ProgressBarDemo(){
        JFrame frame= new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        startbutton = new  JButton("Start");
        progressbar = new JProgressBar(0,100);
        progressbar.setOrientation(JProgressBar.HORIZONTAL);
        progressbar.setStringPainted(true);

        progressbar.setMaximumSize(new Dimension(500,30));
        progressbar.setPreferredSize(new Dimension(500,30));
        progressbar.setMinimumSize(new Dimension(500,30));

        startbutton.addActionListener(this);
        task  = new MyTask();
        task.addPropertyChangeListener(this);
        textarea = new JTextArea(5,20);
        textarea.setEditable(false);
        list = new Vector<String>();
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3,1));

        JScrollPane pane = new JScrollPane();
        pane.getViewport().add(progressbar);
        panel.add(startbutton);
        panel.add(progressbar);
        panel.add(pane);

        frame.setContentPane(panel);

        frame.setVisible(true);
    }
    public static void main(String[] args) {
        new ProgressBarDemo();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("Action Performed thread "+ Thread.currentThread());
        progressbar.setIndeterminate(true);
        System.out.println("progress bar setIndeterminate true");
        try{
            Thread.sleep(2000);
        }catch(Exception exp){
            System.out.println("Exception caught : "+exp.getMessage());
        }
        progressbar.setValue(0);
        task.execute();
        System.out.println("Process initialized");
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        System.out.println("Property Change Event thread :"+ Thread.currentThread().getName());
        if ( "progress".equalsIgnoreCase(evt.getPropertyName())){
            progressbar.setIndeterminate(false);
            System.out.println("Progress event generated, it's value get changed");
            int p= (int)evt.getNewValue();
            progressbar.setValue(p);
            textarea.append("Completed "+ p + "%\n");
        }

    }
    class MyTask extends SwingWorker<Void,Void>{
       @Override
       protected Void doInBackground() throws Exception {
           setProgress(0);
           Random random = new Random();
           System.out.println("doInBackground thread :"+ Thread.currentThread().getName());
           int p =0;
            textarea.setText("Initiazed\n");
           while( getProgress() < 100){
               p = p+ random.nextInt(10);
               try{
                   Thread.sleep(1000 + random.nextInt(2000));
               }catch (Exception e){
                   System.out.println("Exception caught :"+ e.getMessage());
               }
               setProgress((p>100)?100:p);
           }
           System.out.println("Returning from doInBackground method");
           return null;
       }

       @Override
       protected void done() {
           System.out.println("done Method thread : "+ Thread.currentThread());
           startbutton.setEnabled(true);
           textarea.append("DONE.\n");
       }
   }
}
