import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import javax.swing.filechooser.FileSystemView;
import java.awt.event.*;
import java.awt.geom.AffineTransform;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.File;
import java.net.Socket;
import java.util.Random;
import java.io.*;
import java.util.Vector;

public class ProgressBarDemo  {


    static class MyTask extends  SwingWorker<Void,Void> implements PropertyChangeListener {

        MyTask(File file){
            Document d;
        }

        @Override
        public void propertyChange(PropertyChangeEvent evt) {
                if ( evt.getPropertyName().equalsIgnoreCase("uploadProgress")){

                }
        }

        @Override
        protected Void doInBackground() throws Exception {
                        return null;
        }

        @Override
        protected void done() {
            System.out.println("Done method called");
            System.out.println("Thread name :"+ Thread.currentThread().getName());
            super.done();
        }
    }

    public static void main(String [] args){
        try{
            File filetoread = new File("C:\\Users\\RANA1947\\IdeaProjects\\Graphics\\src\\file2.txt");
            File filetowrite = new File("C:\\Users\\RANA1947\\IdeaProjects\\Graphics\\src\\file.txt");
            if ( !filetowrite.exists()){
                filetowrite.createNewFile();
            }
	    FileOutputStream fo = new FileOutputStream(filetowrite);
	    ObjectOutputStream oo = new ObjectOutputStream(fo);

	    Document d = new Document(filetoread);
	    oo.writeObject(d);
	    oo.writeObject(d);
	    System.out.println("Written two times");
	    oo.close();
	    fo.close();
	}
         catch( Exception e){
            System.out.println("Exception cuaght :"+ e.getMessage());
        }

    }

    static class Document implements Serializable{
	    transient File file ;
	    transient Vector < PropertyChangeListener> propertyChangeListeners;
	    transient PropertyChangeSupport pcs;
	    Document(File file){
		    this.file = file;
		    propertyChangeListeners = new Vector<PropertyChangeListener>();
		    pcs = new PropertyChangeSupport(this);
	    }
	 
	    public void addPropertyChangeListener( PropertyChangeListener l){
		    if( !propertyChangeListeners.contains(l)){
		    	propertyChangeListeners.add(l);
		    }
	    }
	    public void removePropertyChangeListeners( PropertyChangeListener l){
		    if ( propertyChangeListeners.contains(l)){
			    propertyChangeListeners.remove(l);
		    }
	    }
	    
	    private void writeObject ( ObjectOutputStream output){
		    System.out.println("writeObject method of Document");
		    int count = 0;
		    byte[] buf = new byte[20];
		    int arraysize , filesize;
		   
		    arraysize = 0;
		   
		    try{
			filesize = (int)file.length();
			System.out.println("filesize : "+ filesize);
		    	FileInputStream fi  = new FileInputStream(file);
		    /*	while( fi.available() != 0){
			   	 System.out.println(" count : "+ ++count);
			   	  
			    	arraysize = fi.read(buf);
			    	output.write(buf,0,arraysize);
			    	// String s = new String(buf);
			    	// System.out.print(s);
		    	}
		    	System.out.println("arraysize : " + arraysize);
		    	System.out.println("Written successfully");
		    	fi.close();
		    	output.writeUTF("SUCCESS");
			*/
		    }catch( Exception e){
			    System.out.println("Exception caught : "+ e.getMessage());
		    }

	    }
    }

	    




    static class MyProgressBar extends JProgressBar implements PropertyChangeListener{
        MyProgressBar(int low, int high){
            super(low,high);
        }

        @Override
        public void propertyChange(PropertyChangeEvent evt) {
            if ( "progress".equalsIgnoreCase(evt.getPropertyName())){
                int value = (int)evt.getNewValue();
                setValue(value);
            }
        }


        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D gg = (Graphics2D)g.create();
            BasicStroke s = new BasicStroke(5.0f,BasicStroke.CAP_ROUND,BasicStroke.JOIN_BEVEL);
            gg.setStroke(s);
            int cx, cy ;
            int x, y , w,h;
            x = gg.getClipBounds().x;
            y = gg.getClipBounds().y;
            w = (int)gg.getClipBounds().width;
            h = (int)gg.getClipBounds().height;
            cx = x+ w/2;
            cy = y = w/2;
            int l ;
            l = (w < h) ? w: h;
            gg.translate(cx,cy);
            gg.setColor(Color.BLACK);
            //gg.drawRect(0,0,10,10);
            AffineTransform t = new AffineTransform(1,0,0,-1,0,0);

            gg.transform(t);
            gg.rotate(3.14/2);
            gg.setColor(Color.RED);
            //gg.drawRect(0,0,10,10);
            int ea ;
            ea =  (int)(3.6f * this.getValue());
            //gg.drawLine(l,0,0,0);
            l = l-10;

            if ( ea != 0 ) {
                gg.drawArc(-l / 2, -l / 2, l, l, 0, ea);
            }
            gg.dispose();
        }
    }
}
