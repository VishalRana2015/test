import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDateTime;


public class MyButton extends JComponent{
    Color backgroundColor ;
    String name ;
    String lastMessage;
    Icon imageIcon;
    LocalDateTime timestamp;
    Icon userSuppliedIcon;
    Icon displayableIcon;
    int bwidth , bheight;
    int iconWidth;
    static int i = 0;
    @Override
    public void paint(Graphics g) {
        System.out.println("Paint method called i :" + i++);
        super.paint(g);
    }

    public int getBheight() {
        return bheight;
    }



    @Override
    protected void paintComponent(Graphics g) {
        System.out.println("Paint component called clip area : "+ g.getClipBounds() + " i : "+ i++);
        super.paintComponent(g);

        Graphics2D gg = (Graphics2D)g;
        gg.setColor(Color.YELLOW);
        int left, right , top , bottom;
        int width, height;
        left = g.getClipBounds().x;
        top = g.getClipBounds().y;
        width =  g.getClipBounds().width;
        height = g.getClipBounds().height;

        gg.fillRoundRect(left,top,width, height, 10,10);

    }
    static class MyBorder extends EmptyBorder {
        MyBorder(int top , int left, int bottom, int right){
            super(top,left,bottom,right);
        }
        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            System.out.println("paint border method called : i : "+ i++);
            super.paintBorder(c, g, x, y, width, height);
        }
    }


    class MyIcon extends ImageIcon{
        @Override
        public synchronized void paintIcon(Component c, Graphics g, int x, int y) {
            System.out.println("Paint Icon called i :"+ i++);
            super.paintIcon(c, g, x, y);
            int length, r ;
            length = this.getIconWidth();
            r= length/2;
            Color color =  ((JComponent)c).getBackground();
            g.setColor(color);
            for ( int i =0; i < r ; i++){
                for ( int j = 0; j < r ; j++){
                    if ( (i-r)*(i-r) + (y-r)*(y-r) - r*r < 0 ){
                        g.drawRect(i+x,j+y, 1,1);
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("MyButton Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        MyButton button  = new MyButton();
        button.setBorder(new MyBorder(0,0,0,10));
        JPanel panel = new JPanel();
        button.setMaximumSize(new Dimension(100,100));
        button.setMinimumSize(new Dimension(100,100));
        button.setPreferredSize( new Dimension(100,100));
        panel.setLayout(new FlowLayout());
        panel.add(button);
        frame.setContentPane(panel);
        frame.setVisible(true);
    }

}
