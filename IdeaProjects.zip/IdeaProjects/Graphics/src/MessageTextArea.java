
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.*;

public class MessageTextArea {
    static class MyBorder extends EmptyBorder{


        public MyBorder(int top, int left , int bottom, int right){
            super(top ,left, bottom , right);

        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            super.paintBorder(c,g,x,y,width,height);
            System.out.println("PiantBorder called");
            System.out.println("x + "+ x+ " y  = "+y + " width = "+ width + " height = "+ height);
            Graphics2D gg = (Graphics2D)g;
            gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int right, top, thick;

            right = this.getBorderInsets(c).right;
            top = this.getBorderInsets(c).top;
            System.out.println("top : "+ top + " right :"+ right  );
            int[] xa= new int[5];
            int[] ya = new int[5];
            xa[0] = width-right;
            ya[0] = top+ 5;
            xa[1]= width;
            ya[1]= top+ 5;
            xa[2]= width - right;
            ya[2] = top + 25;
            xa[3]=width - right;
            ya[3] = top + 25;
            xa[4] = width- right;
            ya[4] = top+ 5;
            gg.setColor(Color.YELLOW);
            gg.fillPolygon(xa,ya,5);

        }
    }
    static class MyTextArea extends JTextArea{

        public MyTextArea(){
            super();
        }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D gg = (Graphics2D)(g.create());
            gg.setColor(Color.YELLOW);
            int left, top, bottom , right, width, height;
            width = this.getWidth();
            height = this.getHeight();
            System.out.println("Wdith : "+ width + "height :"+ height);
            top = this.getInsets().top;
            left = this.getInsets().left;
            bottom = this.getInsets().bottom;
            right = this.getInsets().right;
            gg.fillRoundRect(left,top,width-right, height-bottom,10,10);
            gg.dispose();
            this.setBackground(new Color(0,0,0,0));
            this.setOpaque(true);
            super.paintComponent(g);
            System.out.println("Paint componenet called ");


        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Message Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(new Dimension(500,500));
        frame.setLocation(50,0);
        JPanel panel =new JPanel();
        //panel.setLayout(null);
        MyTextArea msg = new MyTextArea();
        msg.setText("This is my messageI don't know what will be my future but I know I should do what I can I should not think about my future because it is too mysterious the more I think about it. The worse it becomes");
        msg.setSize(new Dimension(100,100));
        msg.setBorder(new MyBorder(0,0,0,10));
        msg.setLocation(new Point(50,50));
        JPanel msgpanel = new JPanel();
        msgpanel.setBorder(new MyBorder(0,0,0,10));
        msgpanel.setSize(new Dimension(100,100));
        msgpanel.getInsets(new Insets(0,0,0,20));
        msgpanel.setLocation(new Point(50,50));
        panel.add(msg);
        msg.setWrapStyleWord(true);
        msg.setLineWrap(true);

        frame.setContentPane(panel);

        frame.setVisible(true);

    }
}
