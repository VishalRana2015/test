import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class test2 {
    public static void main(String[] args) {
        test5Demo();
    }
    static public  void test1Demo(){
        JFrame frame =new JFrame("Viewport Area");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(new Dimension(500,500));
        frame.setLocation(new Point(50,0));
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
        JLabel[] labels= new JLabel[50];
        for ( int i =0; i < 50 ; i++){
            labels[i] = new JLabel("This is new String " + i);
            labels[i].setBorder( new LineBorder(Color.BLUE));
            panel.add(labels[i]);
        }
        JScrollPane pane = new JScrollPane();
        pane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        pane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        JViewport viewport = new JViewport();
        viewport.setView(panel);
        pane.setViewport(viewport);
        labels[49].scrollRectToVisible(labels[49].getVisibleRect());
        System.out.println(labels[49].getVisibleRect());

        frame.setContentPane(pane);

        frame.setVisible(true);
        pane.getVerticalScrollBar().setValue(labels[20].getY());
        System.out.println("labels[9].x : " + labels[49].getX() + " labels[9].y : "+ labels[49].getY());
        System.out.println("labels[1].isShowing :"+ labels[1].isVisible());
    }
    static public void test3Demo(){
        JFrame frame = new JFrame("Using GridBagLayout");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel =new JPanel();
        panel.setLayout(new GridBagLayout());
        JButton one =new JButton("One");
        JButton two = new JButton("Two");
        JButton three = new JButton("Three");
        JButton four = new JButton("Four");
        JButton five = new JButton("Five");
        JButton six =new JButton("Six");
        GridBagConstraints cons = new GridBagConstraints();
        cons.gridx =0;
        cons.gridy =0;
        cons.gridwidth =1;
        cons.gridheight =2 ;
        cons.weightx = 1;
        cons.weighty =1;
        cons.anchor= GridBagConstraints.CENTER;
        cons.fill = GridBagConstraints.NONE;
        panel.add(one,cons);

        cons.gridx = 1;
        cons.gridy =0;
        cons.gridwidth = 1;
        cons.gridheight =2;
        cons.fill = GridBagConstraints.VERTICAL;
        cons.anchor = GridBagConstraints.EAST;
        cons.weightx = 1;
        cons.weighty = 2;
        panel.add(two,cons);

        cons.gridx =2;
        cons.gridy =0;
        cons.gridwidth =2;
        cons.gridheight = 2;
        cons.weightx =1;
        cons.weighty=2;
        cons.anchor = GridBagConstraints.NORTH;
        cons.fill = GridBagConstraints.HORIZONTAL;
        panel.add(three,cons);

        cons.gridx =0;
        cons.gridy = 1;
        cons.gridwidth =1;
        cons.gridheight = 1;
        cons.fill =GridBagConstraints.BOTH;
        cons.anchor = GridBagConstraints.PAGE_END;
        cons.weightx = 1;
        cons.weighty = 1;
        panel.add(four,cons);

        cons.gridx = 1;
        cons.gridy = 2;
        cons.fill = GridBagConstraints.NONE;
        cons.anchor = GridBagConstraints.SOUTHWEST;
        panel.add(five , cons);

        cons.gridx = 2;
        cons.gridy =2;
        cons.gridwidth =1;
        cons.gridheight = 1;
        cons.fill = GridBagConstraints.BOTH;
        cons.anchor = GridBagConstraints.CENTER;
        cons.weighty=1;
        cons.weightx = 2;
        panel.add(six,cons);
        frame.setContentPane(panel);
        frame.setVisible(true);

    }
    public static void test4Demo(){
        JFrame frame = new JFrame("Arc Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JPanel panel = new JPanel(){
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D gg = (Graphics2D)g.create();
                gg.drawRect(10,10,100,100);
                gg.setStroke( new BasicStroke(5.0f,BasicStroke.CAP_ROUND,BasicStroke.JOIN_BEVEL));
                gg.setColor(Color.RED);
                gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                gg.drawArc(100,100,50,50,0,130);
                gg.dispose();

            }
        };
        panel.setLayout(null);
        frame.setContentPane(panel);

        frame.setVisible(true);
    }
    public static void test5Demo(){
        JFrame frame =new JFrame("test4Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLocation(50,0);
        JFileChooser fc = new JFileChooser();
        fc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Action performed on filechooser"+ e.getActionCommand());
                System.out.println("source :"+e.getSource() + "\n");

            }
        });
        JButton show = new JButton("Show");
        show.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fc.showOpenDialog(show);
            }
        });
        frame.setContentPane(show);
        frame.setVisible(true);
    }
}
