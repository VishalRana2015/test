import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.awt.event.*;

public class test extends JComponent implements MouseListener {
    ImageIcon icon;
    Color bgColor , prColor; // pr stands for pressed Color
    int iconWidth;
    int bwidth;
    int bheight;
    int length;
    int xoffset,yoffset;
    MyIcon displayableIcon;
    JLabel name;
    MyLabel lastMessage;
    test(){
        bwidth = 250;
        xoffset = 10;
        yoffset= 10;
        bheight = 100;
        iconWidth = (int)(250*0.3);
        this.setBgColor(Color.CYAN);
        this.setPrColor(Color.BLUE);
        this.addMouseListener(this);
        name = new MyLabel();
        name.setText("Unknown");
        this.add(name);
        int x,y ,w,h;
        x = this.iconWidth + xoffset*2;
        y = yoffset;
        w = (int)(this.bwidth * 0.7 - xoffset)- this.getInsets().right;
        h = 20;
        name.setLocation(x,y);
        name.setSize(w,h);
    }

    public void setName(String name) {
        this.name.setText(name);
        repaint();
    }

    private void setIconWidth(int iconWidth) {
        this.iconWidth= iconWidth;
        this.setIcon(icon);
        repaint();
    }

    @Override
    public void setBackground(Color bg) {
        super.setBackground(bg);
        repaint();
    }
    public void setBgColor(Color bg){
        this.bgColor = bg;
        this.setBackground(bgColor);
        repaint();
    }
    public void setPrColor(Color prColor) {
        this.prColor = prColor;
        repaint();
    }

    @Override
    public void setSize(Dimension d) {
        super.setSize(d);
        int w, h , iw ;
        w = (int)d.getWidth();
        h = (int)d.getHeight();
        this.bheight = h;
        if ( w < 2*h){
             this.bwidth = 2*h;
             System.out.println("Button width was lesser than 2*h");
        }
        else
            this.bwidth = w;
        iw =  (int) (this.bwidth*0.3); // 30 percent
        xoffset = (int)( this.bwidth*0.05);
        xoffset = (xoffset < 10)? xoffset :10;
        yoffset = (int)(this.bheight*0.1);
        yoffset = (yoffset < 10) ? yoffset:10;
        this.setIconWidth(iw);
        int x,y ;
        x = this.iconWidth + xoffset*2;
        y = yoffset;
        w = (int)(this.bwidth * 0.7 - xoffset)- this.getInsets().right;
        h = 20;
        name.setSize(w,h);
        name.setLocation(x,y);
        System.out.println("Icon width has been set.");
    }

    private int getIconWidth() {
        return iconWidth;
    }



    public void setIcon(ImageIcon icon) {
        this.icon = icon;
        BufferedImage bi = new BufferedImage(iconWidth,iconWidth,BufferedImage.TYPE_INT_RGB);
        Graphics2D g = bi.createGraphics();
        g.drawImage(icon.getImage(),0,0,iconWidth,iconWidth,0,0,icon.getIconWidth(),icon.getIconHeight(),null);
        displayableIcon = new MyIcon(bi);
        g.dispose();
        repaint();
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        // printing the icon on the button
        Graphics2D gg = (Graphics2D)g.create();
        gg.setClip(xoffset,yoffset,iconWidth,iconWidth);
        displayableIcon.paintIcon(this,gg,xoffset, yoffset);

        // Drawing the name Component
        int x,y ,w,h;
        x = this.iconWidth + xoffset*2;
        y = yoffset;
        w = (int)(this.bwidth * 0.7 - xoffset)- this.getInsets().right;
        h = 20;
        gg= (Graphics2D)g.create();
        gg.setColor(Color.BLACK);
        gg.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        gg.setClip(x,y,w,h);
        name.paint(gg);
        System.out.println("MyButtn layout : "+ this.getLayout());
        System.out.println("Painted name");

    }

    @Override
    protected void paintComponent(Graphics g) {

        int x,y, width, height;
        x = g.getClipBounds().x;
        y = g.getClipBounds().y;
        width = (int)g.getClipBounds().getWidth();
        height = (int)g.getClipBounds().getHeight();
        g.setColor(this.getBackground());
        g.fillRoundRect(x,y,width,height,10,10);
        System.out.println("this.isShowing : " + this.isShowing()); // true
        super.paintComponent(g);
    }
    class MyLabel extends JLabel{
        MyLabel(){
            super();
            super.setOpaque(false);
            super.setBorder( new EmptyBorder(0,0,0,0));
            super.setAlignmentX(JLabel.LEADING | JLabel.LEFT);
        }

        @Override
        public void paint(Graphics g) {
            super.paint(g);
            g.setColor(Color.RED);
            //g.fillRect(g.getClipBounds().x, g.getClipBounds().y, g.getClipBounds().width, g.getClipBounds().height);

            System.out.println("g. clip area : " + g.getClipBounds());
            System.out.println(" thi.size() : "+ this.size());
            System.out.println("this.minimumSize() : "+ this.getMinimumSize());
            System.out.println("this.preferredSize() : "+ this.getPreferredSize());
            System.out.println("this.parnet :"+ this.getParent());


            System.out.println("Paint called on MyLabel");
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            System.out.println("PaintComponent called on MyLabel");
        }
    }
    public static void main(String[] args) {
        JFrame frame = new JFrame("Test Frame");
        frame.setSize(500,500);
        frame.setLocation(50,0);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        test t = new test();
        ImageIcon icon = new ImageIcon("C:\\Users\\RANA1947\\IdeaProjects\\Graphics\\Images\\batman.jpg");
        t.setIcon(icon);
        t.setLocation(new Point(200,200));
        t.setSize(new Dimension(250,100));
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.add(t);
        System.out.println("t.parent :"+ t.getParent());
        frame.setContentPane(panel);
        frame.setVisible(true);
    }
    class MyIcon extends ImageIcon{
        MyIcon(Image image){
            super(image);
        }
        MyIcon (String filename){
            super(filename);
        }

        @Override
        public synchronized void paintIcon(Component c, Graphics g, int x, int y) {
            super.paintIcon(c, g, x, y);
            System.out.println("x : " + x + " y : "+ y);
            System.out.println("Paint Icon called clipArea : "+ g.getClipBounds());
            int length, r;
            length = (int)g.getClipBounds().getWidth();
            r = length/2;
            Color color = c.getBackground();
            System.out.println("Background Color :"+ color);
            Graphics2D gg = (Graphics2D)g.create();
            gg.setColor(color);
            gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            for ( int i =0; i < length; i++){
                for ( int j =0; j < length; j++)
                if ( (i-r)*(i-r) + (j-r)*(j-r) -r*r > 0 ){
                    gg.fillRect(x+i,y+j,1,1);
                }
            }
        }
    }

    // IMplementing mouseListener methods

    @Override
    public void mouseReleased(MouseEvent e) {
        this.setBackground( bgColor);
        repaint();
        System.out.println("Mouse Released");
    }

    @Override
    public void mousePressed(MouseEvent e) {
        this.setBackground(prColor);
        repaint();
        System.out.println("Mouse Pressed");
    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

}
