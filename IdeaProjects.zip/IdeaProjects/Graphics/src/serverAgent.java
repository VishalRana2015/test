import java.net.*;
import javax.swing.*;
import java.io.*;

public class serverAgent {
    public static void main(String[] args) {
        try{
            ServerSocket ss = new ServerSocket(20000,50);
            Socket s = ss.accept();
        }
        catch(Exception e){
            System.out.println("Exception caught :"+ e.getMessage());
        }
    }
    class MyThread extends Thread{
        Socket s ;
        public MyThread(Socket s){
            super();
            this.s = s;
        }

        @Override
        public void run() {
            System.out.println("s.localIP Address : "+ s.getLocalSocketAddress());
            System.out.println("s. : "+ s.getRemoteSocketAddress());

        }
    }
}
