import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
public class ScanLineDemo {
    public static void main(String[] args) {
        
    }
    public void JScanLineDemo(JPanel panel, Vector points){

    }

}
