import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class CompositeTextField extends JComponent{
    MyLabel label;
    CompositeTextField(){
        label = new MyLabel();
        label.setText("Composite Text Filed MyLabel extending from label");
        System.out.println("layout : "+ this.getLayout());
        label.setSize(new Dimension(100,100));
        label.setLocation(new Point(100,50));
        this.add(label);
        label.setBackground(Color.BLUE);
        label.setOpaque(true);
        label.setBorder(BorderFactory.createLineBorder(Color.RED));
    }

    @Override
    public void paintComponents(Graphics g) {
        System.out.println("Calling super.paintComponents(g) method :");
        super.paintComponents(g);

    }

    @Override
    protected void paintChildren(Graphics g) {
        System.out.println("Calling super.paintChildren(g) : ");
        super.paintChildren(g);
    }

    @Override
    protected void paintComponent(Graphics g) {
        System.out.println("calling super.paintComponent(g) method ");
        super.paintComponent(g);
        //System.out.println("Paint Component of panel called");
        System.out.println("g.cliparea :"+ g.getClipBounds());

    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("CompositeTextField");
        frame.setSize(500,500);
        frame.setLocation(50,0);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CompositeTextField panel = new CompositeTextField();
        frame.setContentPane(panel);

        frame.setVisible(true);
    }

    class MyLabel extends JLabel{
        MyLabel(){
            super();
        }

        @Override
        public void paint(Graphics g) {
            super.paint(g);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            System.out.println("Paint Called on MyLabel object. clip area :"+ g.getClipBounds() + " preferredSize: "+ this.getPreferredSize());
            System.out.println("width : " + this.getWidth() + " this.getHeight() : "+ getHeight());
        }
    }
}
