// This is here you  have to write your code
fun main(args : Array<String>){
    /*println("Hello world") // you don't need to write semicolon to end the statement
    var edureka = Kotlin();// look at the difference between creating a language
    // Here you donot use the new keyword to create an instance of a class,
    // You declare a variable starting with var keyword followed by the name of the indentifier = and then the name of the class
    // with constructor i guess.
    edureka.name = "Edureka Kotlin"
    // printing the variable is same like jsp.
    // val is like a final in java. once initialized cannot be changed. ( like a constant) Immutable in kotlin and only can
    // be initialized once
    println("This given name is : ${edureka.name} " );


     */
    /*
    var a : Int =100; // Remember this the representation of numbers in memory is same as java.
    var d : Double = 10.00;
    var f : Float = 1000.00f;
    var l : Long = 100000000000;
    var s : Short = 24;
    var b : Byte = 2
    println("The value of a is ${a}");
    println("The value of d is ${d}");
    println("The value of f is ${f}");
    println("The value of l is ${l}");
    println("The value of s is ${s}");
    println("This value of b is  ${b}");
    */
    /*
    var write : Char
    write = 'E'
    println( " The value of wirte is ${write}");

     */

    var flag : Boolean = false
    println("${flag}")
    // operators in Kotlin
}