class Kotlin {
    var name : String = "" // This is defualt string that the 'name' variable will take.
}