import java.util.*;
import java.io.*;
public class problem4 {
    static int N , K;
    static String [ ] s;
    public static void main(String[] args) {
        int T;
        Scanner read = new Scanner ( System.in);
        T  = read.nextInt();
        for ( int t = 1; t <= T ; t++){
            N = read.nextInt();
            K = read.nextInt();
            s = new String[N];
            // reading strings
            // READING THE NEXT EMPTY LINE
            read.nextLine();
            for ( int i =0; i < N ; i++){
                s[i] = read.nextLine();
            }


            mergeSort(s,0,N-1 );
            int score;
            int groups = N/K;
            int sum =0;
            for (int i =0; i <groups ; i ++){
                sum += getScore(i*K+0,i*K + K-1);

            }
            System.out.println("Case #"+t+": "+sum);
            /*for ( int i =0; i < N; i++)
                System.out.println(i+"th string : "+s[i] + "length : "+s[i].length());
*/

        }
    }

    static int getScore(int min, int max){
     int score = s[min].length();
     int temp;
     for ( int i = min+1; i <= max; i++){
         temp = commonChars(s[i],s[min]);
         if( temp < score){
             score= temp;
             if ( score == 0 )
                 return score;
         }
     }
     return score;

    }

    static int commonChars( String s1,String s2){
        int cc = 0;
        int minlength;
        minlength = (s1.length() < s2.length())?s1.length():s2.length();
        for ( int i =0; i < minlength; i++){
            if ( s1.charAt(i) == s2.charAt(i)){
                cc = cc +1;
            }
            else
                break;
        }
        return cc;
    }
    static void mergeSort( String[] a, int left ,int right ){
        if ( left == right ) {
            return ;
        }
        int mid;
        mid = ( right + left ) /2;
        mergeSort(a,left,mid);
        mergeSort(a,mid+1,right);
        merge(a,left,mid,right);
        return ;
    }

    static void merge(String []a, int left , int mid , int right ){
        String []aux;
        aux = new String[right-left+1];
        int rightSP;
        int i,j;
        int index=0,leftP;

        rightSP=mid+1;
        for ( leftP=left; leftP <= mid; leftP++){

            for ( j=rightSP; j<= right; j++){
                if ( a[leftP].compareTo(a[j]) > 0 ){

                    aux[index++]=a[j];
                    rightSP++;
                }
                else
                    break;
            }
            aux[index++]=a[leftP];
        }

        for ( j=rightSP; j<=right ; j++)
            aux[index++]=a[j];

        // paste elements of auxillary array in original array
        for ( i=0 ; i<index; i++)
            a[left+i]=aux[i];
        return ;
    }

}
