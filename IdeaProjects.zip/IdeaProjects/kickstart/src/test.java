import java.util.*;
import java.net.URL;

public class test{
	public static void main(String[] args){
		test t = new test();
		String path =t.getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
		//String decodedPath= URLDecoder.decode(path,"UTF-8");
		System.out.println(path);
	}
}
