import java.lang.annotation.Repeatable;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.*;
import java.lang.reflect.*;
public class MyClass {
    @Retention(RetentionPolicy.RUNTIME)
    @interface MyAnnotationContainer {
        MyAnnotation[] value();
    }

    @Repeatable(MyAnnotationContainer.class)
    @interface MyAnnotation{
        String name();
        int age();
    }
    @MyAnnotation(name="Abhishek",age=23)
    @MyAnnotation(name="vishal",age=24)
    int val ;
    public static void main(String[] args) throws Exception{
       /* MyClass obj = new MyClass();
        Field field = obj.getClass().getDeclaredField("val");
        if ( field == null){
            System.out.println("field is null");
            return ;
        }

        Annotation[] ans = field.getAnnotations();
        for ( Annotation an : ans) {
            if (an instanceof MyAnnotationContainer) {
                MyAnnotation[] mans = ((MyAnnotationContainer) an).value();
                for (MyAnnotation man : mans) {
                    System.out.println("name : " + man.name() + " age : " + man.age());
                }
            }
            if (an instanceof MyAnnotation) {
                MyAnnotation man = (MyAnnotation) an;
                System.out.println("name : " + man.name() + " age : " + man.age());
            }
            System.out.println(an.toString());

        }


        B obj = new B();
        Field field = obj.getClass().getDeclaredField("val");
        if (field == null){
            System.out.println("field is null");
            return ;
        }
        Annotation[] ans = field.getAnnotations();
        for( Annotation an : ans){
            System.out.println(an.toString());
        }

        */
        System.out.println("Hello world");
    }
    @Inherited
    @interface MyAnnotation2{
        String name();
    }
    static class A{
        @MyAnnotation2(name="valFromA")
        public  int val;
    }

    static class B extends A{

    }
}
