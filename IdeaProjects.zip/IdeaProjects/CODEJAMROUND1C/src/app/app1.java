package app;
import java.sql.*;
import javax.swing.*;

public class app1 {
    private JPanel panel1;
    private JButton button1;
    public Connection conn;

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
