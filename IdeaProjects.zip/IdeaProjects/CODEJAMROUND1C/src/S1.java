import java.net.*;
import java.io.*;
import java.util.*;
class ClientHandler implements Runnable {
    Socket socket;
    ClientHandler(Socket socket ){
        this.socket = socket;
    }
    public void run(){
        System.out.println("run method executing");
        DataInputStream input  ;
        DataOutputStream output;
        try {
            input = new DataInputStream(socket.getInputStream());
            output = new DataOutputStream(socket.getOutputStream());
            int m1, m2, m3;

            while (  input.readBoolean()  ){

                m1 = input.readInt();
                m2  = input.readInt();
                m3 = m1*m2;
                System.out.println("Sending output to Client : ");
                output.writeInt(m3);
                System.out.println("Waiting for client : ");

            }
        }catch( Exception e){
            System.out.println("Exception caught : "+ e.getMessage());
        }
        System.out.println("read all inputs from client ");
        System.out.println("Taking exit from run method of this thread : "+ this);
    }

}
public class S1 {
    public static void main(String[] args) {
        ServerSocket ss;

        try{
            ss = new ServerSocket(20000);
            while( true) {
                System.out.println("Server Listening ...");
                (new Thread(new ClientHandler(ss.accept()))).start();
            }
        }
        catch ( Exception e){
            System.out.println("Exception caught "+ e.getMessage());
        }
    }
}
