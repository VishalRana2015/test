import java.net.*;
import java.io.*;
import java.util.*;
public class C1 {
    public static void main(String[] args) {
        Socket socket ;
        try{
            InetAddress address = InetAddress.getByName("localhost");
            socket = new Socket("localhost",20000);
            System.out.println(socket.getLocalPort());
            System.out.println(socket.getLocalAddress());
            DataInputStream input= new DataInputStream(socket.getInputStream());
            DataOutputStream output = new DataOutputStream(socket.getOutputStream());
            Scanner in = new Scanner(System.in);
            int m1, m2, m3;
            char ch ='Y';
            while( ch == 'Y' || ch == 'y' ) {
                System.out.println("Reading ...");
                m1 = in.nextInt();
                m2 = in.nextInt();
                output.writeBoolean(true);
                output.writeInt(m1);
                output.writeInt(m2);

                output.flush();
                System.out.println("Waiting for input from server ...");
                m3 = input.readInt();
                System.out.println(" m3 = "+ m3);
                System.out.println("Do you want to again to send values for m1 and m2 to server (Y/N): ");
                ch = in.next().charAt(0);
            }
            System.out.println("Out of while loop");
        }catch(Exception e){
            System.out.println("Exception caught : "+ e.getMessage());
        }
    }
}
