import com.sun.glass.events.KeyEvent;

import java.net.*;
import java.io.*;
import java.util.*;
public class ClientExample {
    public static void main(String[] args) {
        try{
            InetAddress address = InetAddress.getByName("localhost");
            Socket socket = new Socket(address,20000);
            if ( socket != null){
                System.out.println("Connection established");
            }
            else
                System.out.println("Connection not established");
            OutputStream output = socket.getOutputStream();
            Scanner sc = new Scanner( System.in);
            int i ;
            String line = sc.nextLine();
            while ( !line.equalsIgnoreCase("exit")){
                output.write(line.getBytes());
                output.write("\n".getBytes());
                line = sc.nextLine();
            }

            output.write("exit\n".getBytes());
            socket.close();
            System.out.println("Readed from the stream successfully");
            System.out.println("is connection colsed " + socket.isClosed());
            System.out.println(" is connected "  + socket.isConnected());

        }
        catch(Exception e){
            System.out.println("Exception caught : "+ e.getMessage());
        }
    }
}
