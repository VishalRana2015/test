import javax.rmi.*;
import  java.sql.*;
import java.util.Date;
import java.util.TimerTask;
import java.time.*;
import java.text.*;
import java.util.*;

public class DerbyExample {
    static Calendar globaltime;
    public static void main(String[] args) {
        Task task = new Task();
        globaltime = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        System.out.println("Global Thread name : " + Thread.currentThread().getName());
        Timer timer = new Timer("Timer");
        timer.schedule(task,4000);


    }
}
class Task extends TimerTask{
    public void run(){
        try {
            Thread.sleep(500);
        }catch( Exception e){
            System.out.println("Exception caught  : " + e.getMessage());
        }
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        System.out.println("Task Executed after : " + (calendar.getTimeInMillis()- DerbyExample.globaltime.getTimeInMillis()));
        System.out.println("By the Thread : " + Thread.currentThread().getName());
    }
}
