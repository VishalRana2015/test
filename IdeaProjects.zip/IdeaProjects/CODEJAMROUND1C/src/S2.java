

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.util.concurrent.Executor;
import java.util.concurrent.*;
import java.net.*;
public class S2 {
    public static void main(String[] args) {
        Executor executor = Executors.newFixedThreadPool(5);
        ServerSocket ss ;
        try{
            ss= new ServerSocket(20000);
            System.out.println("ServerSocket Instantiated ");
            while ( true){
                System.out.println("Listining ...");
               executor.execute (new ClientHandler(ss.accept()));
               System.out.println("Added one task .");
            }
        }   catch ( Exception e){
            System.out.println("Exception caught : "+ e.getMessage());
        }

    }
}
