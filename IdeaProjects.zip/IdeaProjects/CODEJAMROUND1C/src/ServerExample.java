import java.util.*;
import java.net.*;
import java.io.*;
public class ServerExample {
    public static void main(String[] args) {
        ServerSocket serverSocket ;
        try {
            serverSocket = new ServerSocket(20000);
            System.out.println("ServerSocket instantiated");
            Socket socket = serverSocket.accept();
            System.out.println("socket = "+ socket);
            InputStream input = socket.getInputStream();
            OutputStream output = socket.getOutputStream();
            Scanner in = new Scanner(input);
            System.out.println("No input Available");
            System.out.println("Is connection terminated "+ socket.isClosed());
            String line;
            int i;
            PushbackInputStream pinput = new PushbackInputStream(input);
            while( (i = pinput.read()) != -1){
                System.out.print((char)i);
                line = in.nextLine();
                System.out.println("Client : "+ line);
                System.out.println("Server : Waiting for input from Client ");
            }
            System.out.println("Taken Exit from the loop");
        }catch( Exception e){
            System.out.println("Exception caught : "+ e.getMessage() + e.toString() + e.getStackTrace());

        }
    }
}
