import javax.crypto.*;
import java.security.*;

public class Solution{
    public static void main(String[] args) {
        try {
            KeyGenerator keyg = KeyGenerator.getInstance("AES");
            SecureRandom random = new SecureRandom();
            SecretKey key = keyg.generateKey();
            System.out.println("Algorithmm : "+ keyg.getAlgorithm());
            System.out.println("key  = "+ key);

            System.out.println("key2 = "+ keyg.generateKey());
            System.out.println("Provider :"+ keyg.getProvider());

        }catch(Exception e ){
            System.out.println("NoSuchAlgorithmException + "+e.getMessage());
        }

    }
}
