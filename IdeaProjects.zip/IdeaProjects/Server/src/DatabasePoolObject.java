import java.sql.*;
import java.util.concurrent.*;
import java.util.*;
public class DatabasePoolObject {
    int min , max, available , active;
    String driver , username , password ;
    ConcurrentLinkedQueue queue ;
    public DatabasePoolObject(   String driver , String username, String password, int min , int max) throws ClassNotFoundException,SQLException{
        this.driver = driver;
        this.username = username;
        this.password = password;
        this.min  = min;
        this.max = max;
        initialize();
    }
    private void initialize()  throws SQLException, ClassNotFoundException{
        Class.forName(driver);
        queue  = new ConcurrentLinkedQueue(); // This is an unbounded queue
        available = 0;
        active = 0;
    }
    public Connection getResource() throws SQLException{
        if ( available < min){
            // create a new connection
            Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/XE",username, password);
            active = active + 1;
            available = available+ 1;
            return conn;
        }
        else{
            // There are already more than min connection have been supplied
            if ( queue.isEmpty()){
                // If there are no more connection available in the queue then create a new one and return that only if available < max
                if ( available < max){
                    Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/XE",username, password);
                    active = active +1;
                    available = available +1;
                    return conn;
                }
                else{
                    // do nothing
                }
            }
            else{
                Connection conn = (Connection)queue.poll();
                active = active + 1;
                return conn;
            }
        }
        System.out.println("Returning null");
        return null;
    }
    public void returnResource(Connection conn){
        queue.add(conn);
        active = active - 1;
    }
}
