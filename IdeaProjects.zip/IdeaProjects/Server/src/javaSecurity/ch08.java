package javaSecurity;
import java.security.*;
import java.util.*;
public class ch08 {
    public static void main(String[] args) {
        ch08code();
    }
    public static void ch08code(){
        // This example demostrate all the providers that are by defalult provided by the jdk
        Provider[] providers = Security.getProviders();
        for ( int i =0; i < providers.length; i++){
            System.out.println(providers[i].getInfo());
            Enumeration e = providers[i].keys();
            while( e.hasMoreElements() ){
                Object key= e.nextElement();
                System.out.println("key: "+ key.toString()  + " value : " + providers[i].get(key));
            }
        }
    }
}
