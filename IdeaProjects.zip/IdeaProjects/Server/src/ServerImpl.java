import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.*;
import java.rmi.server.*;
import java.rmi.*;
import java.sql.*;
import java.util.concurrent.TimeoutException;

// This class is default implementation of the server interface
public class ServerImpl implements Server {
    transient  private  DatabaseResourcePool pool;
    public ServerImpl() throws ClassNotFoundException , SQLException{
        pool  = new DatabaseResourcePool("oracle.jdbc.driver.OracleDriver","system","openoracle",5,25);
    }
    @Override
    public UserObject login(String userID, String password) throws SQLException, TimeoutException, UserNameOrPasswordIsInvalidException, RemoteException {
        Connection conn = pool.getResource(50000);
        Statement st = conn.createStatement();
        ResultSet set = st.executeQuery("select * from users");
        UserObject object = null ;
       while ( set.next()){
            if ( set.getString(1).equalsIgnoreCase(userID) && set.getString(2).equals(password)){
                // create a user object and return it
                object = new UserObject(userID , null, null, null);
                break;
            }
       }
       pool.returnResource(conn);
        if (object == null) {
            throw new UserNameOrPasswordIsInvalidException(userID);
        }
       return object;
    }

    @Override
    public UserObject signup(String userID, String userName, String password) throws EmaiIDAlreadyRegisteredException,SQLException, TimeoutException,  RemoteException {
        UserObject object = null;
        Connection conn;
       conn = pool.getResource(50000);
       System.out.println("connection object has been get in signup method");
       Statement st = conn.createStatement();
       ResultSet set= st.executeQuery("select * from users");
       while ( set.next()){
           if ( userID.equalsIgnoreCase(set.getString(1))){
               throw new EmaiIDAlreadyRegisteredException(userID);
           }
       }
       // create a new one
        st = conn.createStatement();

        String s = "insert into users values ('"+ userID + "','" + password + "')";
        System.out.println(s);
        st.executeUpdate(s);
        System.out.println("New User created");
        object = new UserObject(userID,null, null, null);
        return object;
    }
}
