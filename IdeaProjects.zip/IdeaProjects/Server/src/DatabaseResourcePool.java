import java.sql.*;
import java.util.*;
import java.util.concurrent.*;

public class DatabaseResourcePool {
    Semaphore sem;
    private DatabasePoolObject resources;
    public DatabaseResourcePool(String driver , String username, String password , int min , int max) throws SQLException , ClassNotFoundException{
        sem = new Semaphore(max, true);
        resources = new DatabasePoolObject(driver, username, password, min , max);
    }

    public Connection getResource(long timeWaitMillis) throws SQLException , TimeoutException{
        Connection conn = null;
        try {
            if (sem.tryAcquire(timeWaitMillis, TimeUnit.MILLISECONDS)) {
                conn = resources.getResource();
            }
            else
                throw new TimeoutException("Server TimeOut Exception ");
        }
        catch( InterruptedException e ){
            System.out.println("Interrupted Exception thrown :"+ e.getMessage());
        }
        return conn;
    }


    public void returnResource(Connection conn){
        resources.returnResource(conn);
        sem.release();
        System.out.println("Released resource");
    }
}
