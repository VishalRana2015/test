import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.rmi.*;
import java.rmi.server.*;

public class startServer {
    public static void main(String[] args) {
        startRMIServer();
    }
    public static void startRMIServer(){
        try{
            ServerImpl server = new ServerImpl();
            Remote stub = UnicastRemoteObject.exportObject(server, 20001);
            System.out.println("Object exported");

            System.out.println("Server created");
            Naming.rebind("rmi://localhost:20000//object", stub);
            System.out.println("rebinded to rmi server");
        }
        catch( Exception e){
            System.out.println("Server might not have initialized");
            System.out.println("Exception thrown : "+ e.getMessage());
        }
    }
}
