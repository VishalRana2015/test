package test;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.security.*;
import javax.crypto.*;
import java.security.spec.RSAPrivateKeySpec;
import java.sql.*;

public class SymmetricKeyTest {
    public static void main(String[] args) {
        dbTest();
    }

    public static void final1(){
        try{
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBEWithMD5AndTripleDES");
            if ( factory == null)
                System.out.println("factory is null");
            else
                System.out.println("factory is not null");


        }
        catch(Exception e){
            System.out.println("Exception caught :"+ e.getMessage());

        }
    }
    public static void final2(){
        String s= "hello world";
        try {
            KeyGenerator gen = KeyGenerator.getInstance("AES");
            System.out.println("algorithm :"+ gen.getAlgorithm());
            System.out.println("provider :"+ gen.getProvider());
            Key key = gen.generateKey();
            System.out.println("key : "+ key.toString());
            System.out.println("key algorithm :"+ key.getAlgorithm());
            System.out.println("key format :"+ key.getFormat());
            SecretKey key1 = (SecretKey)key;
            gen.init(new SecureRandom());
            String ss = new String(key.getEncoded());
            System.out.println("ss :"+ ss);
        }
        catch( Exception e){
            System.out.println("Exception caught while getting instance of AES " + e.getMessage());
        }
    }
    public static void dbTest(){
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            System.out.println("Class Loaded");
            Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/XE","system","openoracle");
            if (conn == null)
                System.out.println("Conn is null");
            else
                System.out.println("Connection is not null");
            Statement st = conn.createStatement();
            ResultSet set1   = st.executeQuery("select userid from users");
            //ResultSet set2 =st.executeQuery("select password from users");

            while( set1.next()){
                System.out.println(set1.getString(1) + set1.getString(1));
            }


        }
        catch( ClassNotFoundException e){
            System.out.println("ClassNotFoundExcepton thrown : "+ e.getMessage());
        }
        catch( SQLException e){
            System.out.println("SqlException thrown :"+ e.getMessage());
        }
    }
}
