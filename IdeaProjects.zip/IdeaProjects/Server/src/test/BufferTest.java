package test;
import java.net.InetSocketAddress;
import java.nio.*;
import java.io.*;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;

public class BufferTest {
    public static void main(String[] args) {
        final3();
    }
    public static void final1(){
        String s= "Hello world";
        CharBuffer buffer = CharBuffer.allocate(2*s.length());
        System.out.println("size :"+ buffer.length());
        System.out.println("string length; : " + s.length());
        for  ( int i = s.length() - 1 ; i >= 0; i--){
            buffer.put(s.charAt(i));
        }
        System.out.println("buffer.limit () : + "+ buffer.limit());
        System.out.println("buffer.position() :" + buffer.position());
        System.out.println("buffer.capacity() : "+ buffer.capacity());
        System.out.println(buffer.get(20));
        buffer.flip();
        System.out.println("buffer.position() : " + buffer.position());
        System.out.println("buffer.limit () : " + buffer.limit());
        while( buffer.hasRemaining()){
            System.out.print(buffer.get());
        }
    }
    public static void final2(){
        // A file channel is used for reading, wriing, maping a d manipulating a file.
        // A file channel can be used to transfer data to and from a file.
        // A file channel can map its content to main memory
        // MappedByteBuffer is a segment in the memory is byte by byte mirroring the contents of the file, which makes it faster to read
        // in fact the memory that is mapped to the file is often kernal's cache.
        // some importnt methods
        try{
            FileInputStream stream = new FileInputStream(new File("C:\\Users\\RANA1947\\Desktop\\vishal.txt"));
            FileChannel channel = stream.getChannel();
            System.out.println("channel size :  " + channel.size());
            MappedByteBuffer buffer = channel.map(FileChannel.MapMode.READ_ONLY,0,channel.size());
            WritableByteChannel out = Channels.newChannel(System.out);
            // You can also use System.out.printChannel but this one is blocking
            while( buffer.hasRemaining()){
                out.write(buffer);
            }
        }
        catch( Exception e){
            System.out.println("Exception cuaght : + " + e.getMessage());
        }

    }
    public static void final3(){
        // TCP Socket Channels
        // Reads from and write to a TCP socket
        // Each SocketChannel is associated with a Socket object
        String get_request = "GET / HTTP/1.1\n";
        String host ="www.google.com";
        int port = 80;
        String hostHeader = "Host: " + host + "\n\n";
        try{
            SocketChannel channel = SocketChannel.open( new InetSocketAddress(host,port));
            ByteBuffer buf = ByteBuffer.wrap(get_request.getBytes());
            channel.write(buf);
            buf = ByteBuffer.wrap(hostHeader.getBytes());
            channel.write(buf);
            WritableByteChannel out = Channels.newChannel(System.out);
            buf = ByteBuffer.allocate(1024);
            while ( buf.hasRemaining() && channel.read(buf) != -1){
                buf.flip();
                out.write(buf);
                buf.clear();
            }
            System.out.println("\n\nDone \n\n");
        }
        catch( Exception e  ){
            System.out.println("Exception cuaght : "+ e.getMessage());
        }
    }
    public static void final4(){
        //  A selectable channel for TCP listening sockets.
        // EachServerSocktChannel is associated with a ServerSocket object

    }
}
