package NIOExamples;
import java.nio.*;
public class BufferTest {
    public static void main(String[] args) {
        ByteBuffer buffer= ByteBuffer.allocate(1024);
        String s = "Dil Bechara is a very nice movie. This movie generally revolves about Kizma Ruzma a cancer patient. "+
                " She is struggling with life and bored. At the same there is another person Manny lead by Shushant Singh Ranjput";
        buffer.put(s.getBytes());
        System.out.println("buffer.remaining() :"+ buffer.remaining());
        System.out.println("position :" + buffer.position() + " limit :"+ buffer.limit());
        buffer.flip();
        System.out.println("position :" + buffer.position() + " limit :"+ buffer.limit());
        byte[] buf = new byte[100];
        while( buffer.hasRemaining()){
            int i = buffer.remaining();
            System.out.println("buffer.remaining : " + buffer.remaining());
            buffer.get(buf ,0, (int)Math.min( i , buf.length));
            System.out.println("readed");
            String ss = new String(buf , 0, (int) Math.min(i,buf.length));
            System.out.println("ss :"+ ss);

        }
    }
}
