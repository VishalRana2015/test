import java.sql.*;
import java.io.*;
// In this program I just learned that we should not use setObject method to serialize the object to the database.
// Although the object is stored in the database and it's toString() value is visible from the column ( ) but we should not
public class test3 {
    public static void main(String[] args) {
        try{
            boolean read = true;
            Connection conn = DriverManager.getConnection("jdbc:sqlite:C://Users//RANA1947//Desktop//mydb.db");
            System.out.println("Connection made");
            if ( ! read) {
                String s = "insert into mytable2 values (?);";
                PreparedStatement st = conn.prepareStatement(s);
                System.out.println("Statement prepared");
                A object = new A(10, 20);
                st.setObject(1, object);
                System.out.println("Object set");
                st.executeUpdate();
                System.out.println("datebase updated");
            }
            else{
                String s= "select * from mytable";
                PreparedStatement st =conn.prepareStatement(s);
                ResultSet set = st.executeQuery();
                A obj = new A(10,20);
                while( set.next()){
                    Object object = set.getObject(1);
                    A obj3 ;
                    System.out.println("Before getting the object");

                    obj3 = set.getObject(1,A.class);
                    System.out.println("obj3 :" + obj3);
                    System.out.println("Object readed  : "+ ((byte[])object).toString());
                    byte[] buf = (byte[])object;
                    System.out.println("buf.length : " + buf.length);
                    ByteArrayInputStream stream = new ByteArrayInputStream(buf);
                    ObjectInputStream oi =  new ObjectInputStream(stream);
                    obj = new A(10,20);
                    String sq = obj.toString();
                    byte[] buf2 = sq.getBytes();
                    if ( buf2.equals(buf))
                        System.out.println("buf2 equals buf");
                    else
                        System.out.println("buf2 not equals to buf");
                    System.out.println("buf2.length : "+ buf2.length);
                    ByteArrayOutputStream bo = new ByteArrayOutputStream(1024);
                    ObjectOutputStream oo = new ObjectOutputStream(bo);
                    oo.writeObject(obj);
                    System.out.println("obj written to bo");
                    oo.close();
                    bo.close();
                    byte[] buf3 = new byte[1024];
                    for (int i = 0; i < buf.length; i++){
                        System.out.print(buf[i] + " ");
                    }
                    System.out.println();
                    byte[] buf4 = bo.toByteArray();
                    for (int i = 0; i < buf.length; i++){
                        System.out.print(buf4[i] + " ");
                    }

                    System.out.println(object.getClass().getName());
                    System.out.println("obj : " + obj);
                }
                System.out.println("whole set read");
            }
        }
        catch( Exception e){
            System.out.println("Exception caugth :"+ e.getMessage());
        }
    }

    public static class A implements Serializable{
        int a , b;
        A(int a, int b){
            this.a  = a;
            this.b = b;
        }

        public int getA() {
            return a;
        }

        public int getB() {
            return b;
        }

        @Override
        public String toString() {
            return "A{" +
                    "a=" + a +
                    ", b=" + b +
                    '}';
        }
    }

}
