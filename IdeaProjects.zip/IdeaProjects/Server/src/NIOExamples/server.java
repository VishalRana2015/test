//package NIOExamples;
import java.net.InetSocketAddress;
import java.nio.*;
import java.io.*;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.channels.*;
public class server {
    public static void main(String[] args) {
        ServerSocketChannel serverChannel = null;
        try {
            serverChannel = ServerSocketChannel.open();
            System.out.println("serverSocket initialzed");

            serverChannel.bind(new InetSocketAddress(20000), 100);
            System.out.println("serverChannel binded");
            System.out.println("CAlling blocking method accept...");
            SocketChannel client = serverChannel.accept(); // representing client
            Selector sel = Selector.open();
            client.configureBlocking(false);
            client.register(sel,SelectionKey.OP_READ);
            System.out.println( sel.select());
            System.out.println("Selected");
            System.out.println(" a Chanel created");
            System.out.println("Cannel local address :"+ client.getLocalAddress());
            System.out.println("Channel remote Address :"+ client.getRemoteAddress());
            ByteBuffer buffer = ByteBuffer.allocate(1024);
            File file = new File("C:\\Users\\RANA1947\\Desktop\\client1.jpg");
            FileOutputStream stream = new FileOutputStream (file);
            BufferedOutputStream output = new BufferedOutputStream(stream);
            while( client.read(buffer) > 0){
                buffer.flip();
                int i = buffer.remaining();
                byte[] buf = new byte[1024];
                buffer.get( buf , 0 , (int)Math.min(  i , buf.length));
                output.write(buf,0,(int)Math.min( i , buf.length));

                buffer.flip();

            }
            output.close();
            stream.close();
        }
        catch ( Exception e){
            System.out.println("Exceptio caught :" + e.getMessage());
        }

    }
}
