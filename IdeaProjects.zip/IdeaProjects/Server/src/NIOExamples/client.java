//package NIOExamples;
import java.net.InetSocketAddress;
import java.nio.*;
import java.io.*;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.*;
import java.net.*;
public class client {
    public static void main(String[] args) {
        try{
            Socket socket  ;
            socket = new Socket("localhost",20000);
            System.out.println("Socket created");
            File file = new File("C:\\Users\\RANA1947\\Desktop\\msg.jpg");
            FileInputStream stream = new FileInputStream(file);
            BufferedInputStream input = new BufferedInputStream(stream);
            OutputStream output = socket.getOutputStream();
            while ( input.available() > 0 ){
                System.out.println("reading ...");
                byte[] buf = new byte[4096];
                int i = input.available();
                input.read(buf,0,(int)Math.min(buf.length,i));
                //input.read(buf);
                System.out.println("readed");
                output.write(buf,0, (int)Math.min(buf.length,i));
                //output.write(buf);
                System.out.println("written once");
            }
            System.out.println("file sent");
            output.close();
            socket.close();

        }
        catch (Exception e){
            System.out.println("Exception cuaght " + e.getMessage());
        }
    }
}
