import java.util.concurrent.*;
import java.util.*;
import java.sql.*;
// Pool is working successfully

public class pooltest {
    public static void main(String[] args) {
        try {
            DatabaseResourcePool pool = new DatabaseResourcePool("oracle.jdbc.driver.OracleDriver", "system", "openoracle", 5, 10);
            Connection conn = pool.getResource(10);
            if ( conn != null){
                System.out.println("connection is not null");
            }
            else
                System.out.println("Connection is null");
            Statement st = conn.createStatement();
            ResultSet set = st.executeQuery("select * from users");
            while( set.next()){
                System.out.println(set.getString(1));
            }

            ServerImpl s = new ServerImpl();
            UserObject object = s.signup("ranavishaal20155@gmail.com","password","password");

            if ( object == null)
                System.out.println("object is null");
            else
                System.out.println("Object is not null");
            // signup test
            object = s.login("ranavishal2015@gmail.com","password");
            if ( object == null)
                System.out.println("object is null");
            else
                System.out.println("Object is not null");

        }
        catch( EmaiIDAlreadyRegisteredException e){
            System.out.println("emailIDAlreadyRegisteredException :");
        }
        catch( Exception e){
            System.out.println("Exception thrown :" + e.getMessage());
        }
    }
}
