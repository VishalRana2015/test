import com.sun.javaws.exceptions.InvalidArgumentException;

import java.io.Serializable;
import java.net.*;
import java.rmi.*;
import java.rmi.server.*;
import java.sql.*;
import java.util.concurrent.TimeoutException;


public interface Server extends Remote , Serializable {
        public UserObject login( String userID , String password )throws SQLException, TimeoutException , UserNameOrPasswordIsInvalidException , RemoteException;
        public UserObject signup ( String userID , String userName , String password ) throws SQLException, TimeoutException,  EmaiIDAlreadyRegisteredException , RemoteException;
}

class UserNameOrPasswordIsInvalidException extends Exception {
    private String userID;
    private String password;
    public UserNameOrPasswordIsInvalidException(String userID){
        this.userID =userID;
    }

    public String getUserID() {
        return userID;
    }

    //@Override
    public String tooString(){

        return "UserNameOrPasswordIsInvalidException{" +
                "userID='" + userID + '\'' +
                '}';

    }

}


class EmaiIDAlreadyRegisteredException extends Exception{
    private String emailID;
    public EmaiIDAlreadyRegisteredException(String emailID){
        this.emailID =emailID;
    }

    public String getEmailID() {
        return emailID;
    }

    @Override
    public String toString() {
        return "EmaiIDAlreadyRegisteredException{" +
                "emailID='" + emailID + '\'' +
                '}';
    }
}