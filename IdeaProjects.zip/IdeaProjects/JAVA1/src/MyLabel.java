public class MyLabel {
}
