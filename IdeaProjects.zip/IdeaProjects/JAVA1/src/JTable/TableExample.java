import javax.swing.*;
import java.util.*;
import java.swing.event.*;
import java.awt.*;
import java.awt.event.*;
public class TableExample{
	public static void main(String[] args){
		File sourceFile = new File("C:\\Users\\RANA1947\\IdeaProjects\\JAVA1");
		JFrame frame = new JFrame("JTable Example");
		frame.setDeafultCloseOperation(JFrame.EXIT_ON_CLOSE);
		System.out.println("Hello world");
		
		frame.setVisible(true);
		
	}
}
